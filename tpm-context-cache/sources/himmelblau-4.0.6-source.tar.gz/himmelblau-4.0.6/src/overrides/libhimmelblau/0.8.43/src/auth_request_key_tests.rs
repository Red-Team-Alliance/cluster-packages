use super::*;
use compact_jwt::{
    crypto::{JweA256GCMEncipher, JweRSAOAEPEncipher},
    jwe::JweBuilder,
    traits::JweEncipherInnerA256,
};
use crypto_glue::{
    aes256,
    rsa::RS256PrivateKey,
    traits::Pkcs1DecodeRsaPrivateKey,
};
use kanidm_hsm_crypto::provider::TpmRS256;
use openssl::{rsa::Rsa, sign::Signer};
use std::{
    io::{Read, Write},
    net::{TcpListener, TcpStream},
    thread,
    time::{Duration, Instant},
};

const AES_KEY: [u8; 32] = [0x37; 32];
const FIRST_NONCE: &str = "synthetic-prt-nonce";
const SECOND_NONCE: &str = "synthetic-authorization-nonce";

#[derive(Clone, Copy)]
enum Outcome {
    Success,
    Denied,
    WrongTransport,
}

struct Request {
    target: String,
    headers: HashMap<String, String>,
    body: String,
}

fn request(stream: &mut TcpStream) -> Request {
    stream.set_read_timeout(Some(Duration::from_secs(5))).unwrap();
    let mut data = Vec::new();
    let header_end = loop {
        let mut byte = [0];
        stream.read_exact(&mut byte).unwrap();
        data.push(byte[0]);
        assert!(data.len() < 65536, "unexpected fixture request size");
        if data.ends_with(b"\r\n\r\n") {
            break data.len();
        }
    };
    let text = std::str::from_utf8(&data).unwrap();
    let mut lines = text.lines();
    let target = lines.next().unwrap().to_string();
    let headers: HashMap<_, _> = lines
        .filter_map(|line| line.split_once(':'))
        .map(|(name, value)| (name.to_ascii_lowercase(), value.trim().to_string()))
        .collect();
    let length = headers
        .get("content-length")
        .map(|value| value.parse::<usize>().unwrap())
        .unwrap_or(0);
    assert!(length < 65536);
    data.resize(header_end + length, 0);
    stream.read_exact(&mut data[header_end..]).unwrap();
    Request {
        target,
        headers,
        body: String::from_utf8(data[header_end..].to_vec()).unwrap(),
    }
}

fn serve(
    listener: TcpListener,
    responses: Vec<(u16, String)>,
) -> thread::JoinHandle<Vec<Request>> {
    thread::spawn(move || {
        listener.set_nonblocking(true).unwrap();
        responses
            .into_iter()
            .map(|(status, body)| {
                let deadline = Instant::now() + Duration::from_secs(10);
                let mut stream = loop {
                    match listener.accept() {
                        Ok((stream, _)) => break stream,
                        Err(error) if error.kind() == std::io::ErrorKind::WouldBlock => {
                            assert!(Instant::now() < deadline, "missing fixture request");
                            thread::sleep(Duration::from_millis(5));
                        }
                        Err(error) => panic!("fixture accept failed: {error}"),
                    }
                };
                let received = request(&mut stream);
                write!(stream,
                    "HTTP/1.1 {status} Fixture\r\nContent-Length: {}\r\nContent-Type: {}\r\nConnection: close\r\n\r\n{}",
                    body.len(), if body.starts_with('<') { "text/html" } else { "application/json" }, body
                ).unwrap();
                received
            })
            .collect()
    })
}

fn form(request: &Request) -> HashMap<String, String> {
    serde_urlencoded::from_str(&request.body).unwrap()
}

fn jwt_parts(value: &str) -> (Value, Value, Vec<u8>, String) {
    let (signed, signature) = value.rsplit_once('.').unwrap();
    let (header, payload) = signed.split_once('.').unwrap();
    (
        serde_json::from_slice(&URL_SAFE_NO_PAD.decode(header).unwrap()).unwrap(),
        serde_json::from_slice(&URL_SAFE_NO_PAD.decode(payload).unwrap()).unwrap(),
        URL_SAFE_NO_PAD.decode(signature).unwrap(),
        signed.to_string(),
    )
}

fn verify_device(value: &str, cert_der: &[u8], nonce: &str, negative_checks: bool) -> Value {
    let (header, payload, signature, signed) = jwt_parts(value);
    assert_eq!(header["alg"], "RS256");
    assert_eq!(header["typ"], "JWT");
    assert!(header["kid"].as_str().is_some_and(|kid| !kid.is_empty()));
    assert_eq!(header["x5c"], json!([base64::engine::general_purpose::STANDARD.encode(cert_der)]));
    assert_eq!(payload["request_nonce"], nonce);
    let public = X509::from_der(cert_der).unwrap().public_key().unwrap();
    let mut verifier = Verifier::new(MessageDigest::sha256(), &public).unwrap();
    verifier.update(signed.as_bytes()).unwrap();
    assert!(verifier.verify(&signature).unwrap());
    if negative_checks {
        let wrong_public = PKey::from_rsa(Rsa::generate(2048).unwrap()).unwrap();
        let mut verifier = Verifier::new(MessageDigest::sha256(), &wrong_public).unwrap();
        verifier.update(signed.as_bytes()).unwrap();
        assert!(!verifier.verify(&signature).unwrap());
    }
    payload
}

fn verify_session(value: &str) {
    let (header, payload, signature, signed) = jwt_parts(value);
    assert_eq!(header["alg"], "HS256");
    assert_eq!(payload["request_nonce"], SECOND_NONCE);
    assert_eq!(payload["refresh_token"], "synthetic-prt-refresh");
    let ctx = base64::engine::general_purpose::STANDARD.decode(header["ctx"].as_str().unwrap()).unwrap();
    assert_eq!(ctx.len(), 32);
    let key = crypto_glue::nist_sp800_108_kdf_hmac_sha256::derive_key_aes256(
        &AES_KEY, b"AzureAD-SecureConversation", &ctx,
    ).unwrap();
    let key = PKey::hmac(key.as_slice()).unwrap();
    let mut signer = Signer::new(MessageDigest::sha256(), &key).unwrap();
    signer.update(signed.as_bytes()).unwrap();
    assert_eq!(signer.sign_to_vec().unwrap(), signature);
}

async fn run(outcome: Outcome) {
    let (mut tpm, machine_key) = test_tpm();
    let device_private = PKey::from_rsa(Rsa::generate(2048).unwrap()).unwrap();
    let cert_der = self_signed_cert(&device_private, &[]);
    let private = RS256PrivateKey::from_pkcs1_der(
        &device_private.rsa().unwrap().private_key_to_der().unwrap(),
    ).unwrap();
    let device_blob = tpm.rs256_import(&machine_key, private).unwrap();
    let device = LoadableMsDeviceEnrolmentKey::Rsa2048V1 {
        loadable_rs256_key: device_blob,
        x509_der: cert_der.clone(),
    };
    let transport = tpm.msoapxbc_rsa_key_create(&machine_key).unwrap();
    let encrypted_for = if matches!(outcome, Outcome::WrongTransport) {
        tpm.msoapxbc_rsa_key_create(&machine_key).unwrap()
    } else {
        transport.clone()
    };
    let loaded = tpm.msoapxbc_rsa_key_load(&machine_key, &encrypted_for).unwrap();
    let public = tpm.rs256_public(&loaded).unwrap();
    let encryption = JweA256GCMEncipher::from(aes256::key_from_slice(&AES_KEY).unwrap());
    let jwe = encryption.encipher_inner(
        &JweRSAOAEPEncipher::from(public), &JweBuilder::from(Vec::new()).build(),
    ).unwrap();
    let mut prt = test_prt("synthetic-prt-refresh");
    prt.session_key_jwe = Some(jwe.to_string());
    prt.client_info.uid = Some(Uuid::from_u128(0x1234));
    prt.client_info.utid = Some(Uuid::from_u128(0x5678));
    exercise(&mut tpm, &machine_key, &device, &transport, &cert_der, &prt, outcome, true).await;
}

// The measured boundary is only the original end-to-end library operation.
// Provisioning, HTTP fixture setup, and cryptographic assertions are outside it.
async fn exercise(
    tpm: &mut BoxedDynTpm,
    machine_key: &StorageKey,
    device: &LoadableMsDeviceEnrolmentKey,
    transport: &LoadableMsOapxbcRsaKey,
    cert_der: &[u8],
    prt: &PrimaryRefreshToken,
    outcome: Outcome,
    negative_checks: bool,
) -> u128 {
    let mut responses = vec![
        (200, json!({"Nonce": FIRST_NONCE}).to_string()),
        (200, serde_json::to_string(&prt).unwrap()),
        (200, json!({"Nonce": SECOND_NONCE}).to_string()),
    ];
    if !matches!(outcome, Outcome::WrongTransport) {
        responses.push((200, "<script>document.location.replace(\"https://fixture.invalid/callback?code=synthetic-code\")</script>".into()));
        responses.push(if matches!(outcome, Outcome::Denied) {
            (400, json!({"error": "access_denied", "error_description": "synthetic denial"}).to_string())
        } else {
            (200, json!({"token_type": "Bearer", "expires_in": 3600, "ext_expires_in": 3600,
                "access_token": "synthetic-access", "refresh_token": "synthetic-token-refresh"}).to_string())
        });
    }
    let listener = TcpListener::bind("127.0.0.1:0").unwrap();
    let authority = format!("http://{}/tenant", listener.local_addr().unwrap());
    let server = serve(listener, responses);
    let mut app = test_broker_app(&authority);
    app.set_cert_key(Some(device.clone()));
    app.set_transport_key(Some(transport.clone()));
    // Only this loopback fixture bypasses ambient HTTP proxies.
    app.app.app.client = reqwest::Client::builder().no_proxy()
        .redirect(Policy::none()).timeout(Duration::from_secs(5)).build().unwrap();
    let started = Instant::now();
    let result = app.acquire_token_by_refresh_token_internal(
        "synthetic-input-refresh", vec![], Some("https://graph.microsoft.com".into()),
        #[cfg(feature = "on_behalf_of")]
        None,
        true, tpm, machine_key,
    ).await;
    let elapsed_us = started.elapsed().as_micros();
    let requests = server.join().unwrap();
    assert_eq!(requests.len(), if matches!(outcome, Outcome::WrongTransport) { 3 } else { 5 });
    assert!(requests[0].target.starts_with("POST /tenant/oauth2/token "));
    assert_eq!(form(&requests[0])["grant_type"], "srv_challenge");
    assert!(requests[1].target.starts_with("POST /tenant/oauth2/token "));
    let first = form(&requests[1]);
    assert_eq!(first["grant_type"], "urn:ietf:params:oauth:grant-type:jwt-bearer");
    let payload = verify_device(&first["request"], cert_der, FIRST_NONCE, negative_checks);
    assert_eq!(payload["refresh_token"], "synthetic-input-refresh");
    assert_eq!(form(&requests[2])["grant_type"], "srv_challenge");
    if matches!(outcome, Outcome::WrongTransport) {
        assert!(matches!(result, Err(MsalError::CryptoFail(_))));
        return elapsed_us;
    }
    assert!(requests[3].target.starts_with("GET /tenant/oauth2/authorize?"));
    let url = Url::parse(&format!("http://fixture.invalid{}", requests[3].target.split_whitespace().nth(1).unwrap())).unwrap();
    let query: HashMap<_, _> = url.query_pairs().into_owned().collect();
    assert_eq!(query["amr_values"], "ngcmfa");
    assert_eq!(query["resource"], "https://graph.microsoft.com");
    let device_payload = verify_device(&requests[3].headers["x-ms-devicecredential"], cert_der, SECOND_NONCE, negative_checks);
    assert_eq!(device_payload["grant_type"], "device_auth");
    verify_session(&requests[3].headers["x-ms-refreshtokencredential"]);
    let last = form(&requests[4]);
    assert_eq!(last["grant_type"], "authorization_code");
    assert_eq!(last["code"], "synthetic-code");
    if matches!(outcome, Outcome::Denied) {
        assert!(matches!(result, Err(MsalError::AcquireTokenFailed(error)) if error.error == "access_denied"));
    } else {
        let token = result.unwrap();
        assert_eq!(token.access_token.as_deref(), Some("synthetic-access"));
        assert_eq!(token.client_info.uid, prt.client_info.uid);
        assert_eq!(token.client_info.utid, prt.client_info.utid);
        let sealed = token.prt.as_ref().expect("PRT must remain protected");
        let loaded_transport = app.transport_key(tpm, machine_key).unwrap();
        let legacy_cek = tpm.rs256_yield_cek(&loaded_transport);
        let sealing_key = legacy_cek.as_ref().unwrap_or(machine_key);
        let decoded = app.unseal_user_prt(sealed, tpm, sealing_key).unwrap();
        assert_eq!(decoded.refresh_token, prt.refresh_token);
        assert_eq!(decoded.session_key_jwe, prt.session_key_jwe);
        assert_eq!(decoded.client_info.uid, prt.client_info.uid);
        if negative_checks {
            let (_, wrong_machine) = test_tpm();
            assert!(app.unseal_user_prt(sealed, tpm, &wrong_machine).is_err());
        }
    }
    elapsed_us
}

#[tokio::test]
async fn request_key_reuse_full_refresh_finalization() {
    run(Outcome::Success).await;
}

#[tokio::test]
async fn request_key_reuse_denial_does_not_issue_token() {
    run(Outcome::Denied).await;
}

#[tokio::test]
async fn request_key_reuse_wrong_transport_fails_closed() {
    run(Outcome::WrongTransport).await;
}


fn benchmark_tpm() -> BoxedDynTpm {
    match std::env::var("CORE_TPM_BENCH_TCTI") {
        Ok(tcti) => {
            assert!(!tcti.is_empty(), "CORE_TPM_BENCH_TCTI must not be empty");
            #[cfg(feature = "tpm")]
            {
                BoxedDynTpm::new(kanidm_hsm_crypto::provider::TssTpm::new(&tcti).unwrap())
            }
            #[cfg(not(feature = "tpm"))]
            {
                panic!("CORE_TPM_BENCH_TCTI requires the libhimmelblau tpm feature")
            }
        }
        Err(std::env::VarError::NotPresent) => BoxedDynTpm::new(SoftTpm::new()),
        Err(error) => panic!("invalid CORE_TPM_BENCH_TCTI: {error}"),
    }
}

fn benchmark_certificate(device_public_der: &[u8]) -> Vec<u8> {
    let ca = PKey::from_rsa(Rsa::generate(2048).unwrap()).unwrap();
    let public = PKey::public_key_from_der(device_public_der).unwrap();
    let mut subject = X509NameBuilder::new().unwrap();
    subject.append_entry_by_text("CN", "synthetic-benchmark-device").unwrap();
    let mut issuer = X509NameBuilder::new().unwrap();
    issuer.append_entry_by_text("CN", "synthetic-benchmark-ca").unwrap();
    let mut cert = X509Builder::new().unwrap();
    cert.set_version(2).unwrap();
    cert.set_serial_number(BigNum::from_u32(1).unwrap().to_asn1_integer().unwrap().as_ref()).unwrap();
    cert.set_subject_name(&subject.build()).unwrap();
    cert.set_issuer_name(&issuer.build()).unwrap();
    cert.set_pubkey(&public).unwrap();
    cert.set_not_before(Asn1Time::days_from_now(0).unwrap().as_ref()).unwrap();
    cert.set_not_after(Asn1Time::days_from_now(1).unwrap().as_ref()).unwrap();
    cert.sign(&ca, MessageDigest::sha256()).unwrap();
    let cert = cert.build();
    assert!(cert.verify(&ca).unwrap());
    assert!(cert.public_key().unwrap().public_eq(&public));
    cert.to_der().unwrap()
}

#[tokio::test]
#[ignore = "opt-in synthetic benchmark; CORE_TPM_BENCH_TCTI selects a physical TPM"]
async fn request_key_reuse_positive_benchmark() {
    let physical = std::env::var_os("CORE_TPM_BENCH_TCTI").is_some();
    let auth = AuthValue::ephemeral().unwrap();
    let mut provisioning = benchmark_tpm();
    let root_blob = provisioning.root_storage_key_create(&auth).unwrap();
    let root = provisioning.root_storage_key_load(&auth, &root_blob).unwrap();
    let device_blob = provisioning.rs256_create(&root).unwrap();
    let device_key = provisioning.rs256_load(&root, &device_blob).unwrap();
    let cert_der = benchmark_certificate(&provisioning.rs256_public_der(&device_key).unwrap());
    let device = LoadableMsDeviceEnrolmentKey::Rsa2048V1 {
        loadable_rs256_key: device_blob,
        x509_der: cert_der.clone(),
    };
    let transport = provisioning.msoapxbc_rsa_key_create(&root).unwrap();
    let transport_key = provisioning.msoapxbc_rsa_key_load(&root, &transport).unwrap();
    let public = provisioning.rs256_public(&transport_key).unwrap();
    let encryption = JweA256GCMEncipher::from(aes256::key_from_slice(&AES_KEY).unwrap());
    let jwe = encryption.encipher_inner(
        &JweRSAOAEPEncipher::from(public), &JweBuilder::from(Vec::new()).build(),
    ).unwrap();
    let mut prt = test_prt("synthetic-prt-refresh");
    prt.session_key_jwe = Some(jwe.to_string());
    prt.client_info.uid = Some(Uuid::from_u128(0x1234));
    prt.client_info.utid = Some(Uuid::from_u128(0x5678));
    // Discard all provisioning-client contexts and any experimental HSM cache.
    drop(transport_key);
    drop(device_key);
    drop(root);
    drop(provisioning);
    let mut tpm = benchmark_tpm();
    let machine_key = tpm.root_storage_key_load(&auth, &root_blob).unwrap();
    let mut samples = Vec::new();
    for index in 0..4 {
        let elapsed_us = exercise(
            &mut tpm, &machine_key, &device, &transport, &cert_der, &prt,
            Outcome::Success, false,
        ).await;
        samples.push(json!({
            "state": if index == 0 { "cold_new_client" } else { "warm_same_client" },
            "index": index, "elapsed_us": elapsed_us,
        }));
    }
    println!("CORE_TPM_FULL_PATH_BENCHMARK {}", json!({
        "schema": 1,
        "variant": std::env::var("CORE_TPM_BENCH_VARIANT").unwrap_or_else(|_| "unspecified".into()),
        "backend": if physical { "tpm" } else { "soft" },
        "boundary": "acquire_token_by_refresh_token_internal_including_loopback_http",
        "cold": "fresh_client_after_provisioning_client_drop_and_root_reload",
        "warm": "same_client_after_prior_verified_request",
        "positive_only": true,
        "samples": samples,
    }));
}
