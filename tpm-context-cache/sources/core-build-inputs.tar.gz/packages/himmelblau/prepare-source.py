#!/usr/bin/env python3
"""Apply hash-pinned downstream patches and archive the source actually built."""
import hashlib, json, subprocess, sys
from pathlib import Path


def prepare(source_dir, config_path, output):
    config = json.loads(config_path.read_text())
    actual = subprocess.check_output(['git', '-C', str(source_dir), 'rev-parse', 'HEAD'], text=True).strip()
    assert actual == config['commit'], 'Unexpected upstream source commit'
    subprocess.run(['git', '-C', str(source_dir), 'diff', '--exit-code', 'HEAD'], check=True)
    for patch in config.get('patches', []):
        name = patch['file']
        assert Path(name).name == name and name.endswith('.patch')
        path = config_path.parent / 'patches' / name
        assert hashlib.sha256(path.read_bytes()).hexdigest() == patch['sha256']
        subprocess.run(['git', '-C', str(source_dir), 'apply', '--check', str(path)], check=True)
        # Include new vendored files without staging unrelated untracked files.
        subprocess.run(['git', '-C', str(source_dir), 'apply', '--index', str(path)], check=True)
    tree = subprocess.check_output(['git', '-C', str(source_dir), 'write-tree'], text=True).strip()
    output.mkdir(parents=True, exist_ok=True)
    subprocess.run(['git', '-C', str(source_dir), 'archive', '--format=tar.gz',
                    '--prefix=himmelblau-4.0.6/', '-o', str(output / 'himmelblau-4.0.6-source.tar.gz'), tree], check=True)
    (output / 'source-tree.json').write_text(json.dumps({'upstream_commit': actual, 'patched_tree': tree,
        'source_config_sha256': hashlib.sha256(config_path.read_bytes()).hexdigest()}, indent=2) + '\n')
    return tree


if __name__ == '__main__':
    print(prepare(*(Path(arg).resolve() for arg in sys.argv[1:])))
