#!/usr/bin/env python3
"""Run the library regressions with the daemon's unified dependency features."""
import json
import subprocess
from pathlib import Path

compiled = subprocess.run([
    'cargo', 'test', '--release', '--locked', '-p', 'libhimmelblau',
    '-p', 'himmelblau_unix_common', '--features',
    'libhimmelblau/tpm,himmelblau_unix_common/tpm', '--lib', '--no-run',
    '--message-format=json',
], text=True, stdout=subprocess.PIPE, check=True)
records = [json.loads(line) for line in compiled.stdout.splitlines()]
executables = {r['executable'] for r in records
               if r.get('reason') == 'compiler-artifact' and r.get('executable')
               and r['profile']['test'] and r['target']['name'] == 'himmelblau'}
assert len(executables) == 1, executables
result = subprocess.run([executables.pop(), '--test-threads=1'], text=True,
                        stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
print(result.stdout, end='')
Path('/core-artifacts/library-regression-tests.txt').write_text(result.stdout)
raise SystemExit(result.returncode)
