# Stable 4.0.6 startup backports

These are downstream patches from the unmerged proposals in upstream issue
https://github.com/himmelblau-idm/himmelblau/issues/1809.

1. `0001-nss-dynamic-identities.patch` follows commit
   `8531f6dd4b3a241a3d7b743dcff01f18202b1d7c`. Only source and Rust regression
   tests are included; the unrelated NixOS service-test commentary is omitted.
   The guard rejects systemd's reserved dynamic UID/GID range before a daemon
   call and excludes the exact local service name, preserving neighboring names.
2. `0002-lazy-password-calibration.patch` backports commit
   `90a4e31d9c819b30836aa03afa8210bbb66cc860`. Stable 4.0.6 has only `Db::new`,
   so the newer `from_connection` and read-only API are not introduced.
   `OnceLock` retains the same Argon2id/HSM operation and 250 ms calibration
   target. Tests cover no calibration on opening/migration, one policy reused
   for updates, and successful/failed persisted-password verification after a
   real database close/reopen without calibration.

The first new password-verifier update after restart still pays calibration
cost. These patches address startup; they do not claim to remove the measured
post-MFA online-authentication delay. No TPM or MFA policy is weakened.

`candidate.json` pins both patch hashes and the immutable upstream commit.
GitHub builds and tests the candidate natively on ARM64. Its source archive
contains the patched tree, not just the upstream tag. Build inputs, source-tree
metadata and regression results accompany the packages. The stable manifest
and stable APT feed remain separate until a pilot passes.
