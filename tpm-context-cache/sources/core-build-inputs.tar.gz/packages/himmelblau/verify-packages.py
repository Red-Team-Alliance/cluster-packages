#!/usr/bin/env python3
"""Record only packages built for the pinned source, distro, and architecture."""
import hashlib,json,os,subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parents[2]
source=json.loads((root/os.environ.get('HIMMELBLAU_SOURCE','packages/himmelblau/source.json')).read_text())
packages=[]
for path in sorted(Path(sys.argv[1]).glob('*.deb')):
    def field(name):
        return subprocess.check_output(['dpkg-deb','-f',str(path),name],text=True).strip()
    name,version,arch=field('Package'),field('Version'),field('Architecture')
    assert name in {'himmelblau','pam-himmelblau','nss-himmelblau','himmelblau-sshd-config','himmelblau-apparmor'}
    assert version == source['version']+'-ubuntu26.04'+source['revision']
    assert arch=='arm64'
    packages.append({'name':name,'version':version,'architecture':arch,'filename':path.name,
        'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'size':path.stat().st_size})
assert {'himmelblau','pam-himmelblau','nss-himmelblau','himmelblau-sshd-config'} <= {p['name'] for p in packages}
manifest={'schema':1,'source':source,'packages':packages}
Path(sys.argv[1],'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'verified_packages':len(packages),'source_commit':source['commit']}))
