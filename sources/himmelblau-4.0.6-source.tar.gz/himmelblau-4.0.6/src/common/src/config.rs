use crate::constants::DEFAULT_HELLO_TOTP_ENABLED;
/*
   Unix Azure Entra ID implementation
   Copyright (C) David Mulder <dmulder@samba.org> 2024

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
use crate::i18n::tr;
use crate::unix_passwd::parse_etc_passwd;
use configparser::ini::Ini;
use oauth2::url;
use std::collections::BTreeMap;
use std::ffi::{OsStr, OsString};
use std::fmt;
use std::fs::{self, File};
use std::io::Error;
use std::io::Read;
use std::path::{Path, PathBuf};
use std::process::Command;
use tracing::{debug, error};

use crate::constants::{
    CN_NAME_MAPPING, DEFAULT_ALLOW_REMOTE_HELLO, DEFAULT_AUTHORITY_HOST, DEFAULT_BROKER_SOCK_PATH,
    DEFAULT_CACHE_TIMEOUT, DEFAULT_CONFIG_PATH, DEFAULT_CONN_TIMEOUT,
    DEFAULT_CONSOLE_PASSWORD_ONLY, DEFAULT_DB_PATH, DEFAULT_FIDO_TIMEOUT, DEFAULT_HELLO_ENABLED,
    DEFAULT_HELLO_PIN_MIN_LEN, DEFAULT_HELLO_PIN_RETRY_COUNT, DEFAULT_HOME_ALIAS,
    DEFAULT_HOME_ATTR, DEFAULT_HOME_PREFIX, DEFAULT_HSM_PIN_PATH, DEFAULT_ID_ATTR_MAP,
    DEFAULT_JOIN_TYPE, DEFAULT_LOCAL_GROUPS_RECONCILE_INTERVAL, DEFAULT_LOGON_SCRIPT_TIMEOUT,
    DEFAULT_MFA_POLL_PROMPT_SERVICES, DEFAULT_ODC_PROVIDER, DEFAULT_OFFLINE_BREAKGLASS_TTL,
    DEFAULT_ORCHESTRATOR_SOCK_PATH, DEFAULT_PASSWORD_ONLY_REMOTE_SERVICES_DENY_LIST,
    DEFAULT_POLICIES_DB_DIR, DEFAULT_REQUEST_TIMEOUT, DEFAULT_SELINUX,
    DEFAULT_SFA_FALLBACK_ENABLED, DEFAULT_SHELL, DEFAULT_SOCK_PATH, DEFAULT_TASK_SOCK_PATH,
    DEFAULT_TPM_TCTI_NAME, DEFAULT_USER_MAP_FILE, DEFAULT_USE_ETC_SKEL, MAPPED_NAME_CACHE,
    NSS_IGNORE_EXACT, NSS_IGNORE_PREFIX, RUNTIME_CONFIG_PATH, SERVER_CONFIG_PATH,
    VENDOR_CONFIG_PATH,
};
use crate::mapping::{MappedNameCache, Mode};
use crate::unix_config::{HomeAttr, HsmType};
use himmelblau::auth::IpVersion;
use himmelblau::error::MsalError;
use idmap::{DEFAULT_IDMAP_RANGE, DEFAULT_SUBID_RANGE};
use reqwest::Url;
use serde::Deserialize;
use std::env;
use std::time::Duration;

#[derive(Debug, Copy, Clone, PartialEq)]
pub enum IdAttr {
    Uuid,
    Name,
    Rfc2307,
}

#[derive(Debug, Copy, Clone, PartialEq)]
pub enum JoinType {
    Join,
    Register,
}

#[derive(Debug, Copy, Clone, PartialEq)]
pub enum IpVersionSelection {
    Both,
    Ipv4Only,
    Ipv6Only,
}

/// Which supplementary groups NSS initgroups publishes.
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub enum InitgroupsMode {
    /// Only groups that resolve to an NSS name.
    Named,
    /// Every cached group GID, including ones getgrgid cannot name.
    Full,
}

impl From<JoinType> for u32 {
    fn from(val: JoinType) -> Self {
        // Microsoft Entra ID enrollment join types:
        // 0 = Device Join (standard join)
        // 4 = Device Registration (register only)
        match val {
            JoinType::Join => 0,     // Device Join
            JoinType::Register => 4, // Device Registration
        }
    }
}

pub fn split_username(username: &str) -> Option<(&str, &str)> {
    let tup: Vec<&str> = username.split('@').collect();
    if tup.len() == 2 {
        return Some((tup[0], tup[1]));
    }
    None
}

/// Parse a TTL string into seconds.
///
/// Returns an `Option<u64>` representing the number of seconds parsed from the TTL string,
/// or `None` if parsing fails.
///
/// Supported suffixes:
/// - 'm' for minutes
/// - 'h' for hours
/// - 'd' for days
///
/// If no suffix is provided, the value is treated as seconds.
pub fn parse_ttl_to_seconds(ttl_str: &str) -> Option<u64> {
    let ttl_str = ttl_str.trim().to_lowercase();

    // Directly check if last character is alphabetic and extract suffix
    let (num_part, suffix) = match ttl_str.chars().last() {
        Some(last_char) if last_char.is_ascii_alphabetic() => {
            (&ttl_str[..ttl_str.len() - 1], last_char)
        }
        Some(_) => (ttl_str.as_str(), 's'),
        None => {
            error!("TTL string is empty");
            return None;
        }
    };

    let number: u64 = match num_part.parse() {
        Ok(number) => number,
        Err(e) => {
            error!("Invalid TTL number: {}", e);
            return None;
        }
    };

    let seconds = match suffix {
        's' => number,
        'm' => number * 60,
        'h' => number * 3600,
        'd' => number * 86400,
        _ => {
            error!("Invalid TTL unit '{}'", suffix);
            return None;
        }
    };

    Some(seconds)
}

#[derive(Debug, Deserialize)]
struct FederationProvider {
    #[serde(rename = "tenantId")]
    tenant_id: String,
    authority_host: String,
    graph: String,
}

async fn request_federation_provider(
    odc_provider: &str,
    domain: &str,
    request_timeout_secs: u64,
) -> Result<(String, String, String), MsalError> {
    let request_timeout = Duration::from_secs(request_timeout_secs);
    let connect_timeout = std::cmp::min(request_timeout / 2, Duration::from_secs(3));
    let client = reqwest::Client::builder()
        .connect_timeout(connect_timeout)
        .timeout(request_timeout)
        .build()
        .map_err(|e| MsalError::RequestFailed(format!("{:?}", e)))?;

    let url = Url::parse_with_params(
        &format!("https://{}/odc/v2.1/federationProvider", odc_provider),
        &[("domain", domain)],
    )
    .map_err(|e| MsalError::RequestFailed(format!("{:?}", e)))?;

    let resp = client
        .get(url)
        .send()
        .await
        .map_err(|e| MsalError::RequestFailed(format!("{:?}", e)))?;
    if resp.status().is_success() {
        let json_resp: FederationProvider = resp
            .json()
            .await
            .map_err(|e| MsalError::InvalidJson(format!("{:?}", e)))?;
        debug!("Discovered tenant_id: {}", json_resp.tenant_id);
        debug!("Discovered authority_host: {}", json_resp.authority_host);
        debug!("Discovered graph: {}", json_resp.graph);
        Ok((
            json_resp.authority_host,
            json_resp.tenant_id,
            json_resp.graph,
        ))
    } else {
        Err(MsalError::RequestFailed(format!(
            "Federation Provider request failed: {}",
            resp.status(),
        )))
    }
}

#[derive(Clone)]
pub struct HimmelblauConfig {
    config: Ini,
    filename: String,
    effective_config_paths: Vec<PathBuf>,
}

fn str_to_home_attr(attrib: &str) -> HomeAttr {
    if attrib.to_lowercase() == "uuid" {
        return HomeAttr::Uuid;
    } else if attrib.to_lowercase() == "spn" {
        return HomeAttr::Spn;
    } else if attrib.to_lowercase() == "cn" {
        return HomeAttr::Cn;
    }
    HomeAttr::Uuid // Default to Uuid if the attrib can't be parsed
}

fn match_bool(val: Option<String>, default: bool) -> bool {
    match val {
        Some(val) => match val.to_lowercase().as_str() {
            "true" => true,
            "false" => false,
            "1" => true,
            "0" => false,
            _ => {
                error!("Unrecognized response for apply_policy '{}'", val);
                default
            }
        },
        None => default,
    }
}

fn path_exists(path: &Path) -> Result<bool, String> {
    match fs::symlink_metadata(path) {
        Ok(_) => Ok(true),
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => Ok(false),
        Err(error) => Err(format!("failed to inspect {}: {}", path.display(), error)),
    }
}

fn symlink_points_to_dev_null(path: &Path) -> bool {
    matches!(fs::read_link(path), Ok(target) if target == Path::new("/dev/null"))
}

fn is_mask(path: &Path) -> Result<bool, String> {
    let metadata = fs::symlink_metadata(path)
        .map_err(|error| format!("failed to inspect {}: {}", path.display(), error))?;

    if metadata.file_type().is_symlink() {
        return Ok(symlink_points_to_dev_null(path));
    }

    Ok(metadata.is_file() && metadata.len() == 0)
}

fn drop_in_dir(config_path: &Path) -> PathBuf {
    let mut path = config_path.as_os_str().to_os_string();
    path.push(".d");
    PathBuf::from(path)
}

fn collect_drop_ins(config_paths: &[PathBuf]) -> Result<BTreeMap<OsString, PathBuf>, String> {
    let mut drop_ins = BTreeMap::new();

    for config_path in config_paths {
        let directory = drop_in_dir(config_path);
        let entries = match fs::read_dir(&directory) {
            Ok(entries) => entries,
            Err(error) if error.kind() == std::io::ErrorKind::NotFound => continue,
            Err(error) => {
                return Err(format!(
                    "failed to read drop-in directory {}: {}",
                    directory.display(),
                    error
                ))
            }
        };

        for entry in entries {
            let entry = entry.map_err(|error| {
                format!(
                    "failed to read drop-in directory {}: {}",
                    directory.display(),
                    error
                )
            })?;
            let path = entry.path();
            if path.extension() != Some(OsStr::new("conf")) {
                continue;
            }

            let file_type = entry.file_type().map_err(|error| {
                format!("failed to inspect drop-in {}: {}", path.display(), error)
            })?;
            let is_config_file = file_type.is_file()
                || (file_type.is_symlink()
                    && (symlink_points_to_dev_null(&path)
                        || fs::metadata(&path)
                            .map(|metadata| metadata.is_file())
                            .unwrap_or(false)));
            if is_config_file {
                drop_ins.insert(entry.file_name(), path);
            }
        }
    }

    Ok(drop_ins)
}

fn load_config_file(config: &mut Ini, path: &Path) -> Result<(), String> {
    let filename = path
        .to_str()
        .ok_or_else(|| format!("configuration path is not valid UTF-8: {}", path.display()))?;
    config
        .load_and_append(filename)
        .map(|_| ())
        .map_err(|error| {
            format!(
                "failed to read config from {} - cannot start up: {} Quitting.",
                path.display(),
                error
            )
        })
}

fn load_config_hierarchy(
    config: &mut Ini,
    config_paths: &[PathBuf],
) -> Result<Vec<PathBuf>, String> {
    let mut effective_config_paths = Vec::new();
    let mut main_config = None;
    for path in config_paths {
        if path_exists(path)? {
            main_config = Some(path);
        }
    }

    if let Some(path) = main_config {
        effective_config_paths.push(path.clone());
        if !is_mask(path)? {
            load_config_file(config, path)?;
        }
    }

    for path in collect_drop_ins(config_paths)?.values() {
        effective_config_paths.push(path.clone());
        if !is_mask(path)? {
            load_config_file(config, path)?;
        }
    }

    Ok(effective_config_paths)
}

impl HimmelblauConfig {
    pub fn new(config_path: Option<&str>) -> Result<HimmelblauConfig, String> {
        let mut sconfig = Ini::new();
        let mut filename: String = DEFAULT_CONFIG_PATH.to_string();
        if let Some(config_path) = config_path {
            filename = config_path.to_string();
        }
        let cfg_path: PathBuf = PathBuf::from(filename.clone());
        let config_paths = if filename == DEFAULT_CONFIG_PATH {
            vec![
                PathBuf::from(VENDOR_CONFIG_PATH),
                PathBuf::from(RUNTIME_CONFIG_PATH),
                cfg_path,
            ]
        } else {
            vec![cfg_path]
        };
        let effective_config_paths = load_config_hierarchy(&mut sconfig, &config_paths)?;

        // Apply server generated config (generated during domain join)
        let srv_cfg_path: PathBuf = PathBuf::from(SERVER_CONFIG_PATH.to_string());
        if srv_cfg_path.exists() {
            if let Err(e) = sconfig.load_and_append(SERVER_CONFIG_PATH) {
                return Err(format!(
                    "failed to read config from {} - cannot start up: {} Quitting.",
                    SERVER_CONFIG_PATH, e
                ));
            }
        }
        Ok(HimmelblauConfig {
            config: sconfig,
            filename,
            effective_config_paths,
        })
    }

    pub fn get(&self, section: &str, option: &str) -> Option<String> {
        self.config.get(section, option)
    }

    pub fn get_home_prefix(&self, domain: Option<&str>) -> String {
        match domain {
            Some(domain) => match self.config.get(domain, "home_prefix") {
                Some(val) => val,
                None => match self.config.get("global", "home_prefix") {
                    Some(val) => val,
                    None => String::from(DEFAULT_HOME_PREFIX),
                },
            },
            None => match self.config.get("global", "home_prefix") {
                Some(val) => val,
                None => String::from(DEFAULT_HOME_PREFIX),
            },
        }
    }

    pub fn get_home_attr(&self, domain: Option<&str>) -> HomeAttr {
        match domain {
            Some(domain) => match self.config.get(domain, "home_attr") {
                Some(val) => str_to_home_attr(&val),
                None => match self.config.get("global", "home_attr") {
                    Some(val) => str_to_home_attr(&val),
                    None => DEFAULT_HOME_ATTR,
                },
            },
            None => match self.config.get("global", "home_attr") {
                Some(val) => str_to_home_attr(&val),
                None => DEFAULT_HOME_ATTR,
            },
        }
    }

    pub fn get_home_alias(&self, domain: Option<&str>) -> Option<HomeAttr> {
        match domain {
            Some(domain) => match self.config.get(domain, "home_alias") {
                Some(val) => Some(str_to_home_attr(&val)),
                None => match self.config.get("global", "home_alias") {
                    Some(val) => Some(str_to_home_attr(&val)),
                    None => DEFAULT_HOME_ALIAS,
                },
            },
            None => match self.config.get("global", "home_alias") {
                Some(val) => Some(str_to_home_attr(&val)),
                None => DEFAULT_HOME_ALIAS,
            },
        }
    }

    pub fn get_shell(&self, domain: Option<&str>) -> String {
        match domain {
            Some(domain) => match self.config.get(domain, "shell") {
                Some(val) => val,
                None => match self.config.get("global", "shell") {
                    Some(val) => val,
                    None => String::from(DEFAULT_SHELL),
                },
            },
            None => match self.config.get("global", "shell") {
                Some(val) => val,
                None => String::from(DEFAULT_SHELL),
            },
        }
    }

    pub fn get_odc_provider(&self, domain: &str) -> String {
        match self.config.get(domain, "odc_provider") {
            Some(val) => val,
            None => match self.config.get("global", "odc_provider") {
                Some(val) => val,
                None => String::from(DEFAULT_ODC_PROVIDER),
            },
        }
    }

    pub fn get_idmap_range(&self, domain: &str) -> (u32, u32) {
        let default_range = DEFAULT_IDMAP_RANGE;
        match self.config.get(domain, "idmap_range") {
            Some(val) => {
                let vals: Vec<u32> = val
                    .split('-')
                    .map(|m| m.parse())
                    .collect::<Result<Vec<u32>, _>>()
                    .unwrap_or_else(|_| vec![default_range.0, default_range.1]);
                match vals.as_slice() {
                    [min, max] => (*min, *max),
                    _ => {
                        error!("Invalid range specified [{}] idmap_range = {}", domain, val);
                        default_range
                    }
                }
            }
            None => match self.config.get("global", "idmap_range") {
                Some(val) => {
                    let vals: Vec<u32> = val
                        .split('-')
                        .map(|m| m.parse())
                        .collect::<Result<Vec<u32>, _>>()
                        .unwrap_or_else(|_| vec![default_range.0, default_range.1]);
                    match vals.as_slice() {
                        [min, max] => (*min, *max),
                        _ => {
                            error!("Invalid range specified [global] idmap_range = {}", val);
                            default_range
                        }
                    }
                }
                None => {
                    warn!(
                        "No idmap_range range specified in config, using {}-{}!",
                        DEFAULT_IDMAP_RANGE.0, DEFAULT_IDMAP_RANGE.1
                    );
                    default_range
                }
            },
        }
    }

    pub fn get_unix_sock_timeout(&self) -> u64 {
        self.get_connection_timeout().saturating_mul(2)
    }

    /// Get the subordinate ID range for container support (podman, etc.)
    /// Returns the configured range, or the default range if not configured.
    pub fn get_subid_range(&self) -> (u32, u32) {
        let default_range = DEFAULT_SUBID_RANGE;
        match self.config.get("global", "subid_range") {
            Some(val) => {
                let vals: Vec<u32> = val
                    .split('-')
                    .map(|m| m.parse())
                    .collect::<Result<Vec<u32>, _>>()
                    .unwrap_or_else(|_| vec![default_range.0, default_range.1]);
                match vals.as_slice() {
                    [min, max] => (*min, *max),
                    _ => {
                        error!("Invalid range specified [global] subid_range = {}", val);
                        default_range
                    }
                }
            }
            None => default_range,
        }
    }

    pub fn get_authority_host(&self, domain: &str) -> String {
        match self.config.get(domain, "authority_host") {
            Some(val) => val,
            None => {
                debug!("authority_host unset, using defaults");
                String::from(DEFAULT_AUTHORITY_HOST)
            }
        }
    }

    pub fn get_tenant_id(&self, domain: &str) -> Option<String> {
        self.config.get(domain, "tenant_id")
    }

    pub fn get_graph_url(&self, domain: &str) -> Option<String> {
        self.config.get(domain, "graph_url")
    }

    pub fn get_app_id(&self, domain: &str) -> Option<String> {
        match self.config.get(domain, "app_id") {
            Some(val) => Some(val),
            None => self.config.get("global", "app_id"),
        }
    }

    pub fn get_logon_token_app_id(&self, domain: &str) -> Option<String> {
        match self.config.get(domain, "logon_token_app_id") {
            Some(val) => Some(val),
            None => self.config.get("global", "logon_token_app_id"),
        }
    }

    pub fn get_policies_db_path(&self) -> String {
        match self.config.get("global", "policies_db_path") {
            Some(val) => val,
            None => DEFAULT_POLICIES_DB_DIR.to_string(),
        }
    }

    pub fn get_hsm_type(&self) -> HsmType {
        match self.config.get("global", "hsm_type") {
            Some(val) => match val.to_lowercase().as_str() {
                "soft" | "tpm_bound_soft_if_possible" => HsmType::Soft,
                "tpm_if_possible" => HsmType::TpmIfPossible,
                "tpm" => HsmType::Tpm,
                _ => {
                    warn!("Invalid hsm_type configured, using default ...");
                    HsmType::default()
                }
            },
            None => {
                warn!("hsm_type not configured, using default ...");
                HsmType::default()
            }
        }
    }

    pub fn get_hsm_pin_path(&self) -> String {
        match env::var("HIMMELBLAU_HSM_PIN_PATH") {
            Ok(val) => val,
            Err(_e) => match self.config.get("global", "hsm_pin_path") {
                Some(val) => val,
                None => DEFAULT_HSM_PIN_PATH.to_string(),
            },
        }
    }

    pub fn get_pam_allow_groups(&self) -> Vec<String> {
        let mut pam_allow_groups = vec![];
        for section in self.config.sections() {
            pam_allow_groups.extend(match self.config.get(&section, "pam_allow_groups") {
                Some(val) => val.split(',').map(|s| s.trim().to_string()).collect(),
                None => vec![],
            });
        }
        pam_allow_groups
    }

    pub fn get_join_type(&self) -> JoinType {
        match self.config.get("global", "join_type") {
            Some(val) => match val.to_lowercase().as_str() {
                "join" => JoinType::Join,
                "register" => JoinType::Register,
                _ => {
                    error!("Unrecognized join_type choice: {}", val);
                    DEFAULT_JOIN_TYPE
                }
            },
            None => DEFAULT_JOIN_TYPE,
        }
    }

    pub fn write(&self) -> Result<(), Error> {
        self.config.write(self.filename.clone())
    }

    pub fn write_server_config(&self) -> Result<(), Error> {
        let mut srv_conf = self.config.clone();
        srv_conf.remove_section("global");

        let permitted_keys = [
            "authority_host",
            "tenant_id",
            "graph_url",
            "domain_aliases",
            "device_id",
            "intune_device_id",
        ];
        let mut keys_to_remove = Vec::new();
        for (section, keys) in srv_conf.get_map_ref() {
            for key in keys.keys() {
                if !permitted_keys.contains(&key.as_str()) {
                    keys_to_remove.push((section.to_string(), key.clone()));
                }
            }
        }
        for (section, key) in keys_to_remove {
            srv_conf.remove_key(&section, &key);
        }

        srv_conf.write(SERVER_CONFIG_PATH)
    }

    pub fn set(&mut self, section: &str, key: &str, value: &str) {
        self.config.set(section, key, Some(value.to_string()));
    }

    pub fn get_configured_domains(&self) -> Vec<String> {
        let mut domains = match self.config.get("global", "domains") {
            Some(val) => val.split(',').map(|s| s.trim().to_string()).collect(),
            None => vec![],
        };
        let domain = match self.config.get("global", "domain") {
            Some(val) => val.split(',').map(|s| s.trim().to_string()).collect(),
            None => vec![],
        };
        domains.extend(domain);
        let mut sections = self.config.sections();
        sections.retain(|s| s != "global" && s != "offline_breakglass");
        for section in sections {
            if !domains.contains(&section) {
                domains.push(section);
            }
        }
        domains
    }

    pub fn get_config_file(&self) -> String {
        self.filename.clone()
    }

    pub fn get_effective_config_paths(&self) -> &[PathBuf] {
        &self.effective_config_paths
    }

    pub fn get_id_attr_map(&self) -> IdAttr {
        match self.config.get("global", "id_attr_map") {
            Some(id_attr_map) => match id_attr_map.to_lowercase().as_str() {
                "uuid" => IdAttr::Uuid,
                "name" => IdAttr::Name,
                "rfc2307" => IdAttr::Rfc2307,
                _ => {
                    error!("Unrecognized id_attr_map choice: {}", id_attr_map);
                    DEFAULT_ID_ATTR_MAP
                }
            },
            None => DEFAULT_ID_ATTR_MAP,
        }
    }

    pub fn get_rfc2307_group_fallback_map(&self) -> Option<IdAttr> {
        self.config
            .get("global", "rfc2307_group_fallback_map")
            .and_then(|id_attr_map| match id_attr_map.to_lowercase().as_str() {
                "uuid" => Some(IdAttr::Uuid),
                "name" => Some(IdAttr::Name),
                _ => None,
            })
    }

    pub fn get_password_only_remote_services_deny_list(&self) -> Vec<String> {
        match self
            .config
            .get("global", "password_only_remote_services_deny_list")
        {
            Some(val) => val
                .split(',')
                .map(|s| s.trim().to_string())
                .filter(|s| !s.is_empty())
                .collect(),
            None => DEFAULT_PASSWORD_ONLY_REMOTE_SERVICES_DENY_LIST
                .split(',')
                .map(|s| s.trim().to_string())
                .filter(|s| !s.is_empty())
                .collect(),
        }
    }

    pub fn get_intune_device_id(&self, domain: &str) -> Option<String> {
        let domain = self
            .get_primary_domain_from_alias_simple(domain)
            .unwrap_or(domain.to_string());
        self.config.get(&domain, "intune_device_id")
    }

    pub fn get_primary_domain_from_alias_simple(&self, alias: &str) -> Option<String> {
        let domains = self.get_configured_domains();

        for domain in &domains {
            if domain.to_lowercase() == alias.to_lowercase() {
                return Some(domain.to_string());
            }
            let domain_aliases = match self.config.get(domain, "domain_aliases") {
                Some(aliases) => aliases
                    .split(",")
                    .map(|s| s.to_string().to_lowercase())
                    .collect(),
                None => vec![],
            };
            if domain_aliases.contains(&alias.to_string().to_lowercase()) {
                return Some(domain.to_string());
            }
        }
        None
    }

    pub async fn domains_are_aliases(&mut self, domain1: &str, domain2: &str) -> bool {
        if let Some(primary) = self.get_primary_domain_from_alias(domain1).await {
            domain2 == primary
        } else if let Some(primary) = self.get_primary_domain_from_alias(domain2).await {
            domain1 == primary
        } else {
            false
        }
    }

    pub async fn get_primary_domain_from_alias(&mut self, alias: &str) -> Option<String> {
        // Short-circuit the request if this is an OIDC provider domain.
        if self.get_oidc_issuer_url().is_some() {
            return None;
        }

        // Attempt to short-circut the request by checking if the alias is
        // already configured.
        if let Some(primary) = self.get_primary_domain_from_alias_simple(alias) {
            return Some(primary);
        }

        let domains = self.get_configured_domains();
        if domains.is_empty() {
            info!("No domains are configured.");
            return None;
        }

        let mut modified_config = false;

        // We don't recognize this alias, so now we need to search for it the
        // hard way by checking for matching tenant id's.
        let (_, alias_tenant_id, _) = match request_federation_provider(
            DEFAULT_ODC_PROVIDER,
            alias,
            self.get_request_timeout(),
        )
        .await
        {
            Ok(resp) => resp,
            Err(e) => {
                error!(
                    "Failed matching alias '{}' to a configured tenant: {:?}",
                    alias, e
                );
                return None;
            }
        };
        for domain in domains {
            let tenant_id = match self.get_tenant_id(&domain) {
                Some(tenant_id) => tenant_id,
                None => {
                    let (authority_host, tenant_id, graph_url) = match request_federation_provider(
                        &self.get_odc_provider(&domain),
                        &domain,
                        self.get_request_timeout(),
                    )
                    .await
                    {
                        Ok(resp) => resp,
                        Err(e) => {
                            error!("Failed sending federation provider request: {:?}", e);
                            continue;
                        }
                    };
                    self.set(&domain, "authority_host", &authority_host);
                    self.set(&domain, "tenant_id", &tenant_id);
                    self.set(&domain, "graph_url", &graph_url);
                    modified_config = true;
                    tenant_id
                }
            };
            if tenant_id == alias_tenant_id {
                let mut domain_aliases = match self.config.get(&domain, "domain_aliases") {
                    Some(aliases) => aliases.split(",").map(|s| s.to_string()).collect(),
                    None => vec![],
                };
                domain_aliases.push(alias.to_string());
                self.set(&domain, "domain_aliases", &domain_aliases.join(","));
                let _ = self.write_server_config();
                return Some(domain);
            }
        }

        error!("Failed matching alias '{}' to a configured tenant", alias);
        if modified_config {
            let _ = self.write_server_config();
        }
        None
    }

    /// Convert a login name to a UPN, or `None` if it cannot be a directory user
    /// (empty, or a known local-only name). Callers treat `None` as user-unknown
    /// and must not look it up against Entra. See himmelblau-idm/himmelblau#1392.
    pub fn map_name_to_upn(&self, account_id: &str) -> Option<String> {
        self.map_name_to_upn_impl(account_id, "/etc/passwd")
    }

    /// Inner impl with an injectable passwd path for hermetic unit tests.
    fn map_name_to_upn_impl(&self, account_id: &str, passwd_path: &str) -> Option<String> {
        let name_mapping_script = self.get_name_mapping_script();
        let cn_name_mapping = self.get_cn_name_mapping();
        let domains = self.get_configured_domains();

        if account_id.trim().is_empty() {
            return None;
        }

        // Make sure this account_id isn't a local user
        let mut contents = vec![];
        if let Ok(mut file) = File::open(passwd_path) {
            let _ = file.read_to_end(&mut contents);
        }
        let local_users = parse_etc_passwd(contents.as_slice()).unwrap_or_default();
        if local_users
            .into_iter()
            .map(|u| u.name.to_string())
            .collect::<Vec<String>>()
            .contains(&account_id.to_string())
        {
            return Some(account_id.to_string());
        }

        // Local-only names probed by systemd/GDM at boot; never directory users.
        if NSS_IGNORE_EXACT.contains(&account_id)
            || NSS_IGNORE_PREFIX
                .iter()
                .any(|prefix| account_id.starts_with(prefix))
        {
            return None;
        }

        // Empty script output signals "not a directory user" -> None.
        if !account_id.contains('@') {
            if let Some(name_mapping_script) = &name_mapping_script {
                let name_cache = MappedNameCache::new(MAPPED_NAME_CACHE, &Mode::ReadWrite).ok();

                let output = Command::new(name_mapping_script).arg(account_id).output();

                match output {
                    Ok(output) => {
                        if output.status.success() {
                            let upn = String::from_utf8_lossy(&output.stdout).trim().to_string();
                            if upn.is_empty() {
                                return None;
                            }
                            if let Some(name_cache) = &name_cache {
                                // Failing to insert a name map is not a critical failure.
                                if let Err(e) = name_cache.insert_mapping(&upn, account_id) {
                                    error!(
                                        "Failed to cache name mapping for {} as {}: {}",
                                        account_id, upn, e
                                    );
                                }
                            }
                            return Some(upn);
                        } else {
                            error!("Script execution failed with error: {:?}", output.status);
                        }
                    }
                    Err(e) => {
                        error!(
                            "Failed to execute script `{}` from `{}`: {}",
                            name_mapping_script,
                            env::current_dir()
                                .unwrap_or_else(|e| {
                                    error!("No working dir: {:?}", e);
                                    String::new().into()
                                })
                                .display(),
                            e
                        );
                    }
                }
            }
        }
        if cn_name_mapping && !account_id.contains('@') && !domains.is_empty() {
            return Some(format!("{}@{}", account_id, domains[0]));
        }
        Some(account_id.to_string())
    }

    /// This function maps a UPN to a mapped name. If a mapping script is
    /// configured, it will use the mapping cache to obtain the mapped name.
    /// If a mapping script is not configured, but upn to cn mapping is
    /// enabled, it will map the upn to the cn. Otherwise it will return the
    /// name unchanged.
    pub fn map_upn_to_name(&self, upn: &str) -> String {
        if let Some((name, domain)) = split_username(upn) {
            let primary = self
                .get_configured_domains()
                .first()
                .map(|e| e.as_str())
                .unwrap_or("")
                .to_lowercase();
            let res;
            if self.get_name_mapping_script().is_some() {
                if let Ok(name_mapping_cache) =
                    MappedNameCache::new(MAPPED_NAME_CACHE, &Mode::ReadOnly)
                {
                    res = name_mapping_cache.get_mapped_name(upn);
                } else {
                    res = upn.to_string();
                }
            // Only perform cn name mapping for the primary domain
            } else if self.get_cn_name_mapping() && primary == domain.to_lowercase() {
                res = name.to_string();
            } else {
                res = upn.to_string();
            }
            res
        } else {
            // This isn't a upn, just return the input unchanged
            upn.to_string()
        }
    }

    pub fn get_sudo_groups(&self) -> Vec<String> {
        let mut sudo_groups: Vec<String> = vec![];
        for section in self.config.sections() {
            sudo_groups.extend(match self.config.get(&section, "sudo_groups") {
                Some(val) => val.split(',').map(|s| s.trim().to_string()).collect(),
                None => vec![],
            });
        }
        sudo_groups
    }

    pub fn get_oidc_issuer_url(&self) -> Option<String> {
        let res = self.config.get("global", "oidc_issuer_url").map(|s| {
            s.trim()
                .strip_suffix("/.well-known/openid-configuration")
                .unwrap_or(s.trim())
                .to_string()
        });
        if let Some(ref s) = res {
            if s.is_empty() {
                return None;
            } else if !s.starts_with("https://") {
                error!("OIDC issuer URL must use https://");
                return None;
            } else if s.contains('?') || s.contains('#') {
                warn!("OIDC issuer URL must not contain query or fragment");
                return None;
            } else if url::Url::parse(s).is_err() {
                error!("OIDC issuer URL is not a valid URL");
                return None;
            }
        }
        res
    }
}

// Generated getter methods from XML parameter definitions.
include!(concat!(env!("OUT_DIR"), "/config_gen.rs"));

impl HimmelblauConfig {
    pub fn get_ip_versions(&self) -> Vec<IpVersion> {
        match self.get_ip_version() {
            IpVersionSelection::Ipv4Only => vec![IpVersion::V4],
            IpVersionSelection::Ipv6Only => vec![IpVersion::V6],
            IpVersionSelection::Both => vec![IpVersion::V4, IpVersion::V6],
        }
    }
}

impl fmt::Debug for HimmelblauConfig {
    fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
        write!(f, "{:?}", self.config)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::env;
    use std::fs;
    #[cfg(unix)]
    use std::os::unix::fs::symlink;

    // Helper function to create temporary configuration files
    fn create_temp_config(contents: &str) -> String {
        let file_path = format!("/tmp/himmelblau_test_config_{}.ini", uuid::Uuid::new_v4());
        fs::write(&file_path, contents).expect("Failed to write temporary config file");
        file_path
    }

    // Throwaway passwd file so map_name_to_upn_impl can be tested hermetically.
    fn create_temp_passwd(contents: &str) -> String {
        let file_path = format!("/tmp/himmelblau_test_passwd_{}", uuid::Uuid::new_v4());
        fs::write(&file_path, contents).expect("Failed to write temporary passwd file");
        file_path
    }

    // Helper function to create an empty config (to test defaults without system config interference)
    fn create_empty_config() -> HimmelblauConfig {
        let temp_file = create_temp_config("");
        HimmelblauConfig::new(Some(&temp_file)).unwrap()
    }

    #[cfg(unix)]
    fn write_temp_config(path: &Path, contents: &str) {
        fs::create_dir_all(path.parent().unwrap()).expect("Failed to create config directory");
        fs::write(path, contents).expect("Failed to write temporary config file");
    }

    #[cfg(unix)]
    #[test]
    fn test_load_config_hierarchy_precedence_and_masking() {
        let root = env::temp_dir().join(format!(
            "himmelblau_test_config_hierarchy_{}",
            uuid::Uuid::new_v4()
        ));
        let vendor = root.join("usr/lib/himmelblau/himmelblau.conf");
        let runtime = root.join("run/himmelblau/himmelblau.conf");
        let local = root.join("etc/himmelblau/himmelblau.conf");

        write_temp_config(
            &vendor,
            "[global]\nvalue = vendor-main\nmain_only = ignored\n",
        );
        write_temp_config(&runtime, "[global]\nvalue = runtime-main\n");

        let mut main_config = Ini::new();
        let effective_config_paths = load_config_hierarchy(
            &mut main_config,
            &[vendor.clone(), runtime.clone(), local.clone()],
        )
        .unwrap();
        assert_eq!(effective_config_paths, vec![runtime.clone()]);
        assert_eq!(
            main_config.get("global", "value").as_deref(),
            Some("runtime-main")
        );
        assert_eq!(main_config.get("global", "main_only"), None);

        write_temp_config(&local, "");

        write_temp_config(
            &drop_in_dir(&vendor).join("10-masked.conf"),
            "[global]\nmasked = no\n",
        );
        let masked_drop_in = drop_in_dir(&local).join("10-masked.conf");
        fs::create_dir_all(masked_drop_in.parent().unwrap())
            .expect("Failed to create local drop-in directory");
        symlink("/dev/null", masked_drop_in).expect("Failed to create drop-in mask");

        write_temp_config(
            &drop_in_dir(&local).join("20-local.conf"),
            "[global]\nvalue = local-drop-in\nlocal_only = retained\n",
        );
        write_temp_config(
            &drop_in_dir(&vendor).join("30-late.conf"),
            "[global]\nvalue = vendor-late\n",
        );
        write_temp_config(
            &drop_in_dir(&runtime).join("30-late.conf"),
            "[global]\nvalue = runtime-late\n",
        );
        let linked_drop_in = root.join("linked.conf");
        write_temp_config(&linked_drop_in, "[global]\nlinked = loaded\n");
        symlink(linked_drop_in, drop_in_dir(&vendor).join("35-linked.conf"))
            .expect("Failed to create regular-file drop-in symlink");

        let directory_target = root.join("directory-target");
        fs::create_dir_all(&directory_target).expect("Failed to create symlink target directory");
        symlink(
            directory_target,
            drop_in_dir(&vendor).join("36-directory.conf"),
        )
        .expect("Failed to create directory drop-in symlink");
        symlink(
            root.join("missing.conf"),
            drop_in_dir(&vendor).join("37-broken.conf"),
        )
        .expect("Failed to create broken drop-in symlink");

        write_temp_config(
            &drop_in_dir(&local).join("40-ignored.ini"),
            "[global]\nvalue = wrong-suffix\n",
        );
        write_temp_config(
            &drop_in_dir(&local).join("50-nested.conf.d/60-ignored.conf"),
            "[global]\nvalue = nested\n",
        );

        let mut config = Ini::new();
        let _effective_config_paths =
            load_config_hierarchy(&mut config, &[vendor, runtime, local]).unwrap();

        assert_eq!(
            config.get("global", "value").as_deref(),
            Some("runtime-late")
        );
        assert_eq!(
            config.get("global", "local_only").as_deref(),
            Some("retained")
        );
        assert_eq!(config.get("global", "main_only"), None);
        assert_eq!(config.get("global", "masked"), None);
        assert_eq!(config.get("global", "linked").as_deref(), Some("loaded"));

        fs::remove_dir_all(root).expect("Failed to remove config hierarchy");
    }

    #[test]
    fn test_get_home_prefix() {
        let config_data = r#"
        [global]
        home_prefix = /home/global

        [example.com]
        home_prefix = /home/example
        "#;

        let temp_file = create_temp_config(config_data);
        let config = HimmelblauConfig::new(Some(&temp_file)).unwrap();

        assert_eq!(config.get_home_prefix(Some("example.com")), "/home/example");
        assert_eq!(config.get_home_prefix(None), "/home/global");
        let config_empty = create_empty_config();
        assert_eq!(
            config_empty.get_home_prefix(Some("unknown.com")),
            DEFAULT_HOME_PREFIX
        );
    }

    #[test]
    fn test_get_shell() {
        let config_data = r#"
        [global]
        shell = /bin/bash

        [example.com]
        shell = /bin/zsh
        "#;

        let temp_file = create_temp_config(config_data);
        let config = HimmelblauConfig::new(Some(&temp_file)).unwrap();

        assert_eq!(config.get_shell(Some("example.com")), "/bin/zsh");
        assert_eq!(config.get_shell(None), "/bin/bash");
        let config_empty = create_empty_config();
        assert_eq!(config_empty.get_shell(Some("unknown.com")), DEFAULT_SHELL);
    }

    #[test]
    fn test_get_connection_timeout() {
        let config_data = r#"
        [global]
        connection_timeout = 45
        "#;

        let temp_file = create_temp_config(config_data);
        let config = HimmelblauConfig::new(Some(&temp_file)).unwrap();

        assert_eq!(config.get_connection_timeout(), 45);
        let config_empty = create_empty_config();
        assert_eq!(config_empty.get_connection_timeout(), 30);
    }

    #[test]
    fn test_get_request_timeout() {
        let config_data = r#"
        [global]
        request_timeout = 15
        "#;

        let temp_file = create_temp_config(config_data);
        let config = HimmelblauConfig::new(Some(&temp_file)).unwrap();

        assert_eq!(config.get_request_timeout(), 15);
        let config_empty = create_empty_config();
        assert_eq!(config_empty.get_request_timeout(), DEFAULT_REQUEST_TIMEOUT);
    }

    #[test]
    fn test_get_idmap_range() {
        let config_data = r#"
        [global]
        idmap_range = 1000-2000

        [example.com]
        idmap_range = 5000-6000
        "#;

        let temp_file = create_temp_config(config_data);
        let config = HimmelblauConfig::new(Some(&temp_file)).unwrap();

        assert_eq!(config.get_idmap_range("example.com"), (5000, 6000));
        assert_eq!(config.get_idmap_range("unknown.com"), (1000, 2000));
        let config_empty = create_empty_config();
        assert_eq!(config_empty.get_idmap_range("any.com"), DEFAULT_IDMAP_RANGE);
    }

    #[test]
    fn test_get_subid_range() {
        let config_data = r#"
        [global]
        subid_range = 100000-999999
        "#;

        let temp_file = create_temp_config(config_data);
        let config = HimmelblauConfig::new(Some(&temp_file)).unwrap();

        assert_eq!(config.get_subid_range(), (100000, 999999));

        // When not configured, use the default range
        let config_empty = create_empty_config();
        assert_eq!(config_empty.get_subid_range(), DEFAULT_SUBID_RANGE);
    }

    #[test]
    fn test_get_broker_socket_path() {
        let config_data = r#"
        [global]
        broker_socket_path = /var/run/broker.sock
        "#;

        let temp_file = create_temp_config(config_data);
        let config = HimmelblauConfig::new(Some(&temp_file)).unwrap();

        assert_eq!(config.get_broker_socket_path(), "/var/run/broker.sock");
        let config_empty = create_empty_config();
        assert_eq!(
            config_empty.get_broker_socket_path(),
            DEFAULT_BROKER_SOCK_PATH
        );
    }

    #[test]
    fn test_get_pam_allow_groups() {
        let config_data = r#"
        [example.com]
        pam_allow_groups = 2eb4e6a2-f55d-4cf4-8e62-978f9f4a828d,f791d7c2-66cd-4f67-a195-72c6faf3c3b5

        [global]
        pam_allow_groups = 825d1f7e-c4cd-4fc2-aeeb-1f92357f8da6,0149b437-fbaa-4419-bf46-f9a9f9a3438c
        "#;

        let temp_file = create_temp_config(config_data);
        let config = HimmelblauConfig::new(Some(&temp_file)).unwrap();

        let mut groups = config.get_pam_allow_groups();
        groups.sort();
        let mut expected_groups: Vec<String> = vec![
            "2eb4e6a2-f55d-4cf4-8e62-978f9f4a828d".to_string(),
            "f791d7c2-66cd-4f67-a195-72c6faf3c3b5".to_string(),
            "825d1f7e-c4cd-4fc2-aeeb-1f92357f8da6".to_string(),
            "0149b437-fbaa-4419-bf46-f9a9f9a3438c".to_string(),
        ];
        expected_groups.sort();

        assert_eq!(groups, expected_groups);
    }

    #[test]
    fn test_get_join_type() {
        let config_data = r#"
        [global]
        join_type = register
        "#;

        let temp_file = create_temp_config(config_data);
        let config = HimmelblauConfig::new(Some(&temp_file)).unwrap();
        assert_eq!(config.get_join_type(), JoinType::Register);
        let config_empty = create_empty_config();
        assert_eq!(config_empty.get_join_type(), JoinType::Join);

        let config_data = r#"
        [global]
        join_type = join
        "#;
        let temp_file = create_temp_config(config_data);
        let config = HimmelblauConfig::new(Some(&temp_file)).unwrap();
        assert_eq!(config.get_join_type(), JoinType::Join);
    }

    #[test]
    fn test_get_ip_version() {
        let config_data = r#"
        [global]
        ip_version = ipv4-only
        "#;

        let temp_file = create_temp_config(config_data);
        let config = HimmelblauConfig::new(Some(&temp_file)).unwrap();
        assert_eq!(config.get_ip_version(), IpVersionSelection::Ipv4Only);
        assert_eq!(config.get_ip_versions(), vec![IpVersion::V4]);

        let config_data = r#"
        [global]
        ip_version = ipv6-only
        "#;
        let temp_file = create_temp_config(config_data);
        let config = HimmelblauConfig::new(Some(&temp_file)).unwrap();
        assert_eq!(config.get_ip_version(), IpVersionSelection::Ipv6Only);
        assert_eq!(config.get_ip_versions(), vec![IpVersion::V6]);

        let config_empty = create_empty_config();
        assert_eq!(config_empty.get_ip_version(), IpVersionSelection::Both);
        assert_eq!(config_empty.get_initgroups_mode(), InitgroupsMode::Named);
        assert_eq!(
            config_empty.get_ip_versions(),
            vec![IpVersion::V4, IpVersion::V6]
        );
    }

    #[test]
    fn test_get_initgroups_mode() {
        let named = r#"
        [global]
        initgroups_mode = named
        "#;
        let temp_file = create_temp_config(named);
        let config = HimmelblauConfig::new(Some(&temp_file)).unwrap();
        assert_eq!(config.get_initgroups_mode(), InitgroupsMode::Named);

        let full = r#"
        [global]
        initgroups_mode = full
        "#;
        let temp_file = create_temp_config(full);
        let config = HimmelblauConfig::new(Some(&temp_file)).unwrap();
        assert_eq!(config.get_initgroups_mode(), InitgroupsMode::Full);

        let invalid = r#"
        [global]
        initgroups_mode = debug
        "#;
        let temp_file = create_temp_config(invalid);
        let config = HimmelblauConfig::new(Some(&temp_file)).unwrap();
        assert_eq!(config.get_initgroups_mode(), InitgroupsMode::Named);
    }

    #[test]
    fn test_get_hsm_pin_path_env_override() {
        env::set_var("HIMMELBLAU_HSM_PIN_PATH", "/custom/pin/path");

        let config_data = r#"
        [global]
        hsm_pin_path = /etc/hsm/default_pin
        "#;

        let temp_file = create_temp_config(config_data);
        let config = HimmelblauConfig::new(Some(&temp_file)).unwrap();

        assert_eq!(config.get_hsm_pin_path(), "/custom/pin/path");

        env::remove_var("HIMMELBLAU_HSM_PIN_PATH");
    }

    #[test]
    fn test_get_apply_policy() {
        let config_data = r#"
        [global]
        apply_policy = true
        "#;

        let temp_file = create_temp_config(config_data);
        let config = HimmelblauConfig::new(Some(&temp_file)).unwrap();

        assert_eq!(config.get_apply_policy(), true);
        let config_empty = create_empty_config();
        assert_eq!(config_empty.get_apply_policy(), false);
    }

    #[test]
    fn test_get_home_attr() {
        let config_data = r#"
        [global]
        home_attr = cn

        [example.com]
        home_attr = spn
        "#;

        let temp_file = create_temp_config(config_data);
        let config = HimmelblauConfig::new(Some(&temp_file)).unwrap();

        assert_eq!(config.get_home_attr(None), HomeAttr::Cn);
        assert_eq!(config.get_home_attr(Some("example.com")), HomeAttr::Spn);
        let config_empty = create_empty_config();
        assert_eq!(config_empty.get_home_attr(None), HomeAttr::Uuid);
    }

    #[test]
    fn test_get_home_alias() {
        let config_data = r#"
        [global]
        home_alias = cn

        [example.com]
        home_alias = uuid
        "#;

        let temp_file = create_temp_config(config_data);
        let config = HimmelblauConfig::new(Some(&temp_file)).unwrap();

        assert_eq!(config.get_home_alias(None), Some(HomeAttr::Cn));
        assert_eq!(
            config.get_home_alias(Some("example.com")),
            Some(HomeAttr::Uuid)
        );
        let config_empty = create_empty_config();
        assert_eq!(
            config_empty.get_home_alias(Some("unknown.com")),
            Some(HomeAttr::Spn)
        );
    }

    #[test]
    fn test_get_odc_provider() {
        let config_data = r#"
        [global]
        odc_provider = suse.com

        [example.com]
        odc_provider = odc.officeapps.live.com
        "#;

        let temp_file = create_temp_config(config_data);
        let config = HimmelblauConfig::new(Some(&temp_file)).unwrap();

        assert_eq!(config.get_odc_provider("unknown.com"), "suse.com");
        assert_eq!(
            config.get_odc_provider("example.com"),
            "odc.officeapps.live.com"
        );
        let config_empty = create_empty_config();
        assert_eq!(
            config_empty.get_odc_provider("unknown.com"),
            DEFAULT_ODC_PROVIDER
        );
    }

    #[test]
    fn test_get_app_id() {
        let config_data = r#"
        [example.com]
        app_id = 70fee399-7cd8-42f9-a0ea-1e12ea308908
        "#;

        let temp_file = create_temp_config(config_data);
        let config = HimmelblauConfig::new(Some(&temp_file)).unwrap();

        assert_eq!(config.get_app_id("unknown.com"), None);
        assert_eq!(
            config.get_app_id("example.com"),
            Some("70fee399-7cd8-42f9-a0ea-1e12ea308908".to_string())
        );
        let config_empty = create_empty_config();
        assert_eq!(config_empty.get_app_id("example.com"), None);
    }

    #[test]
    fn test_get_socket_path() {
        let config_data = r#"
        [global]
        socket_path = /var/run/socket_path.sock
        "#;

        let temp_file = create_temp_config(config_data);
        let config = HimmelblauConfig::new(Some(&temp_file)).unwrap();

        assert_eq!(config.get_socket_path(), "/var/run/socket_path.sock");
        let config_empty = create_empty_config();
        assert_eq!(config_empty.get_socket_path(), DEFAULT_SOCK_PATH);
    }

    #[test]
    fn test_get_task_socket_path() {
        let config_data = r#"
        [global]
        task_socket_path = /var/run/task_socket.sock
        "#;

        let temp_file = create_temp_config(config_data);
        let config = HimmelblauConfig::new(Some(&temp_file)).unwrap();

        assert_eq!(config.get_task_socket_path(), "/var/run/task_socket.sock");
        let config_empty = create_empty_config();
        assert_eq!(config_empty.get_task_socket_path(), DEFAULT_TASK_SOCK_PATH);
    }

    #[test]
    fn test_get_cache_timeout() {
        let config_data = r#"
        [global]
        cache_timeout = 120
        "#;

        let temp_file = create_temp_config(config_data);
        let config = HimmelblauConfig::new(Some(&temp_file)).unwrap();

        assert_eq!(config.get_cache_timeout(), 120);
        let config_empty = create_empty_config();
        assert_eq!(config_empty.get_cache_timeout(), DEFAULT_CACHE_TIMEOUT);
    }

    #[test]
    fn test_get_unix_sock_timeout() {
        let config_data = r#"
        [global]
        connection_timeout = 15
        "#;

        let temp_file = create_temp_config(config_data);
        let config = HimmelblauConfig::new(Some(&temp_file)).unwrap();

        assert_eq!(config.get_unix_sock_timeout(), 30);
        let config_empty = create_empty_config();
        assert_eq!(
            config_empty.get_unix_sock_timeout(),
            DEFAULT_CONN_TIMEOUT * 2
        );
    }

    #[test]
    fn test_get_db_path() {
        let config_data = r#"
        [global]
        db_path = /var/db/himmelblau.db
        "#;

        let temp_file = create_temp_config(config_data);
        let config = HimmelblauConfig::new(Some(&temp_file)).unwrap();

        assert_eq!(config.get_db_path(), "/var/db/himmelblau.db");
    }

    #[test]
    fn test_get_hsm_type() {
        let (config_data, default, alt) = if HsmType::default() == HsmType::Soft {
            (
                r#"
                    [global]
                    hsm_type = tpm
                "#,
                HsmType::Soft,
                HsmType::Tpm,
            )
        } else {
            (
                r#"
                    [global]
                    hsm_type = soft
                "#,
                HsmType::Tpm,
                HsmType::Soft,
            )
        };

        let temp_file = create_temp_config(config_data);
        let config = HimmelblauConfig::new(Some(&temp_file)).unwrap();
        assert_eq!(config.get_hsm_type(), alt);
        let config_empty = create_empty_config();
        assert_eq!(config_empty.get_hsm_type(), default);
    }

    #[test]
    fn test_get_use_etc_skel() {
        let config_data = r#"
        [global]
        use_etc_skel = true
        "#;

        let temp_file = create_temp_config(config_data);
        let config = HimmelblauConfig::new(Some(&temp_file)).unwrap();

        assert_eq!(config.get_use_etc_skel(), true);

        let config_empty = create_empty_config();
        assert_eq!(config_empty.get_use_etc_skel(), false);
    }

    #[test]
    fn test_get_configured_domains() {
        let config_data = r#"
        [global]
        domains = example.com,test.com

        [alpha.com]
        [test.com]
        [example2.com]
        [example.com]
        [test2.com]
        "#;

        let temp_file = create_temp_config(config_data);
        let config = HimmelblauConfig::new(Some(&temp_file)).unwrap();

        let mut domains = config.get_configured_domains();
        // The order from `domains` must always be preserved (specifically, we
        // care about the placement of the first domain only).
        assert_eq!(domains[..2], vec!["example.com", "test.com"]);

        // The order of the remaining domains is irrelevant.
        domains.sort();
        assert_eq!(
            domains,
            vec![
                "alpha.com",
                "example.com",
                "example2.com",
                "test.com",
                "test2.com"
            ]
        );
    }

    #[test]
    fn test_get_enable_hello() {
        let config_data = r#"
        [global]
        enable_hello = false
        "#;

        let temp_file = create_temp_config(config_data);
        let config = HimmelblauConfig::new(Some(&temp_file)).unwrap();

        assert_eq!(config.get_enable_hello(), false);
        let config_empty = create_empty_config();
        assert_eq!(config_empty.get_enable_hello(), DEFAULT_HELLO_ENABLED);
    }

    #[test]
    fn test_get_enable_passwordless() {
        let config_data = r#"
        [global]
        enable_passwordless = false
        "#;

        let temp_file = create_temp_config(config_data);
        let config = HimmelblauConfig::new(Some(&temp_file)).unwrap();

        assert_eq!(config.get_enable_passwordless(), false);

        // Test that default is true (backward compat)
        let config_empty = create_empty_config();
        assert_eq!(config_empty.get_enable_passwordless(), true);
    }

    #[test]
    fn test_get_enable_experimental_mfa() {
        let config_data = r#"
        [global]
        enable_experimental_mfa = false
        "#;

        let temp_file = create_temp_config(config_data);
        let config = HimmelblauConfig::new(Some(&temp_file)).unwrap();

        assert_eq!(config.get_enable_experimental_mfa(), false);
        let config_empty = create_empty_config();
        assert_eq!(config_empty.get_enable_experimental_mfa(), true);
    }

    #[test]
    fn test_get_enable_experimental_passwordless_fido() {
        let config_data = r#"
        [global]
        enable_experimental_passwordless_fido = true
        "#;

        let temp_file = create_temp_config(config_data);
        let config = HimmelblauConfig::new(Some(&temp_file)).unwrap();

        // Test when explicitly set to true
        assert_eq!(config.get_enable_experimental_passwordless_fido(), true);

        // Test fallback default (false) when config is missing
        let config_empty = create_empty_config();
        assert_eq!(
            config_empty.get_enable_experimental_passwordless_fido(),
            false
        );
    }

    #[test]
    fn test_get_debug() {
        let config_data = r#"
        [global]
        debug = true
        "#;

        let temp_file = create_temp_config(config_data);
        let config = HimmelblauConfig::new(Some(&temp_file)).unwrap();

        assert_eq!(config.get_debug(), true);
        let config_empty = create_empty_config();
        assert_eq!(config_empty.get_debug(), false);
    }

    #[test]
    fn test_get_cn_name_mapping() {
        let config_data = r#"
        [global]
        cn_name_mapping = false
        "#;

        let temp_file = create_temp_config(config_data);
        let config = HimmelblauConfig::new(Some(&temp_file)).unwrap();

        assert_eq!(config.get_cn_name_mapping(), false);
        let config_empty = create_empty_config();
        assert_eq!(config_empty.get_cn_name_mapping(), CN_NAME_MAPPING);
    }

    #[test]
    fn test_get_authority_host() {
        let config_data = r#"
        [example.com]
        authority_host = https://login.suse.com
        "#;

        let temp_file = create_temp_config(config_data);
        let config = HimmelblauConfig::new(Some(&temp_file)).unwrap();

        assert_eq!(
            config.get_authority_host("example.com"),
            "https://login.suse.com"
        );
        let config_empty = create_empty_config();
        assert_eq!(
            config_empty.get_authority_host("example.com"),
            DEFAULT_AUTHORITY_HOST
        );
    }

    #[test]
    fn test_get_graph_url() {
        let config_data = r#"
        [example.com]
        graph_url = https://graph.suse.com
        "#;

        let temp_file = create_temp_config(config_data);
        let config = HimmelblauConfig::new(Some(&temp_file)).unwrap();

        assert_eq!(
            config.get_graph_url("example.com"),
            Some("https://graph.suse.com".to_string())
        );
        let config_empty = create_empty_config();
        assert_eq!(config_empty.get_graph_url("example.com"), None);
    }

    #[test]
    fn test_get_selinux() {
        let config_data = r#"
        [global]
        selinux = true
        "#;

        let temp_file = create_temp_config(config_data);
        let config = HimmelblauConfig::new(Some(&temp_file)).unwrap();

        assert_eq!(config.get_selinux(), true);
        let config_empty = create_empty_config();
        assert_eq!(config_empty.get_selinux(), DEFAULT_SELINUX);
    }

    #[test]
    fn test_get_id_attr_map() {
        let config_data = r#"
        [global]
        id_attr_map = uuid
        "#;

        let temp_file = create_temp_config(config_data);
        let config = HimmelblauConfig::new(Some(&temp_file)).unwrap();

        assert_eq!(config.get_id_attr_map(), IdAttr::Uuid);

        // Default fallback for unknown value
        let config_invalid = r#"
        [global]
        id_attr_map = invalid_value
        "#;
        let temp_file_invalid = create_temp_config(config_invalid);
        let config_invalid = HimmelblauConfig::new(Some(&temp_file_invalid)).unwrap();
        assert_eq!(config_invalid.get_id_attr_map(), DEFAULT_ID_ATTR_MAP);

        let config_missing = create_empty_config();
        assert_eq!(config_missing.get_id_attr_map(), DEFAULT_ID_ATTR_MAP);
    }

    #[test]
    fn test_get_hello_pin_min_length() {
        let config_data = r#"
        [global]
        hello_pin_min_length = 8
        "#;

        let temp_file = create_temp_config(config_data);
        let config = HimmelblauConfig::new(Some(&temp_file)).unwrap();

        assert_eq!(config.get_hello_pin_min_length(), 8);
        let config_invalid = r#"
        [global]
        hello_pin_min_length = invalid_value
        "#;
        let temp_file_invalid = create_temp_config(config_invalid);
        let config_invalid = HimmelblauConfig::new(Some(&temp_file_invalid)).unwrap();
        assert_eq!(
            config_invalid.get_hello_pin_min_length(),
            DEFAULT_HELLO_PIN_MIN_LEN
        );
        let config_missing = create_empty_config();
        assert_eq!(
            config_missing.get_hello_pin_min_length(),
            DEFAULT_HELLO_PIN_MIN_LEN
        );
    }

    #[test]
    fn test_get_tenant_id() {
        let config_data = r#"
        [example.com]
        tenant_id = example-tenant-id
        "#;

        let temp_file = create_temp_config(config_data);
        let config = HimmelblauConfig::new(Some(&temp_file)).unwrap();

        assert_eq!(
            config.get_tenant_id("example.com"),
            Some("example-tenant-id".to_string())
        );
        assert_eq!(config.get_tenant_id("nonexistent.com"), None);
        let config_missing = create_empty_config();
        assert_eq!(config_missing.get_tenant_id("example.com"), None);
    }

    #[test]
    fn test_get_local_groups() {
        let config_data = r#"
        [global]
        local_groups = group1,group2,group3
        "#;

        let temp_file = create_temp_config(config_data);
        let config = HimmelblauConfig::new(Some(&temp_file)).unwrap();

        let expected_groups = vec![
            "group1".to_string(),
            "group2".to_string(),
            "group3".to_string(),
        ];
        assert_eq!(config.get_local_groups(), expected_groups);
        let config_empty = create_empty_config();
        assert_eq!(config_empty.get_local_groups(), Vec::<String>::new());
    }

    #[test]
    fn test_get_local_groups_reconcile_interval() {
        let config_data = r#"
        [global]
        local_groups_reconcile_interval = 0
        "#;

        let temp_file = create_temp_config(config_data);
        let config = HimmelblauConfig::new(Some(&temp_file)).unwrap();

        assert_eq!(config.get_local_groups_reconcile_interval(), 0);
        let config_empty = create_empty_config();
        assert_eq!(
            config_empty.get_local_groups_reconcile_interval(),
            DEFAULT_LOCAL_GROUPS_RECONCILE_INTERVAL
        );
    }

    #[test]
    fn test_get_logon_script() {
        let config_data = r#"
        [global]
        logon_script = /path/to/logon/script
        "#;

        let temp_file = create_temp_config(config_data);
        let config = HimmelblauConfig::new(Some(&temp_file)).unwrap();

        assert_eq!(
            config.get_logon_script(),
            Some("/path/to/logon/script".to_string())
        );
        let config_missing = create_empty_config();
        assert_eq!(config_missing.get_logon_script(), None);
    }

    #[test]
    fn test_get_logon_script_timeout() {
        let config_data = r#"
        [global]
        logon_script_timeout = 120
        "#;

        let temp_file = create_temp_config(config_data);
        let config = HimmelblauConfig::new(Some(&temp_file)).unwrap();

        assert_eq!(config.get_logon_script_timeout(), 120);
        let config_empty = create_empty_config();
        assert_eq!(
            config_empty.get_logon_script_timeout(),
            DEFAULT_LOGON_SCRIPT_TIMEOUT
        );
    }

    #[test]
    fn test_get_intune_device_id() {
        let config_data = r#"
        [example.com]
        intune_device_id = 123e4567-e89b-12d3-a456-426614174000
        "#;

        let temp_file = create_temp_config(config_data);
        let config = HimmelblauConfig::new(Some(&temp_file)).unwrap();

        assert_eq!(
            config.get_intune_device_id("example.com"),
            Some("123e4567-e89b-12d3-a456-426614174000".to_string())
        );

        // Test missing domain
        assert_eq!(config.get_intune_device_id("missing.com"), None);
        let config_missing = create_empty_config();
        assert_eq!(config_missing.get_intune_device_id("example.com"), None);
    }

    #[test]
    fn test_get_logon_token_scopes() {
        let config_data = r#"
        [global]
        logon_token_scopes = scope1,scope2,scope3
        "#;

        let temp_file = create_temp_config(config_data);
        let config = HimmelblauConfig::new(Some(&temp_file)).unwrap();

        let expected_scopes = vec![
            "scope1".to_string(),
            "scope2".to_string(),
            "scope3".to_string(),
        ];
        assert_eq!(config.get_logon_token_scopes(), expected_scopes);
        let config_empty = create_empty_config();
        assert_eq!(config_empty.get_logon_token_scopes(), Vec::<String>::new());
    }

    #[test]
    fn test_get_logon_token_app_id() {
        let config_data = r#"
        [example.com]
        logon_token_app_id = 544e695f-5d78-442e-b14e-e114e95e640c
        "#;

        let temp_file = create_temp_config(config_data);
        let config = HimmelblauConfig::new(Some(&temp_file)).unwrap();

        assert_eq!(
            config.get_logon_token_app_id("example.com"),
            Some("544e695f-5d78-442e-b14e-e114e95e640c".to_string())
        );

        // Test missing domain
        assert_eq!(config.get_logon_token_app_id("missing.com"), None);

        // Test empty configuration
        let config_empty = create_empty_config();
        assert_eq!(config_empty.get_logon_token_app_id("example.com"), None);
    }

    #[test]
    fn test_get_mfa_method() {
        let config_data = r#"
        [global]
        mfa_method = TwoWayVoiceMobile
        "#;

        let temp_file = create_temp_config(config_data);
        let config = HimmelblauConfig::new(Some(&temp_file)).unwrap();

        // Test when MFA method is set
        assert_eq!(
            config.get_mfa_method(),
            Some("TwoWayVoiceMobile".to_string())
        );

        // Test when config is missing (should return None)
        let config_empty = create_empty_config();
        assert_eq!(config_empty.get_mfa_method(), None);

        // Test with different MFA method
        let config_data_sms = r#"
        [global]
        mfa_method = OneWaySMS
        "#;
        let temp_file_sms = create_temp_config(config_data_sms);
        let config_sms = HimmelblauConfig::new(Some(&temp_file_sms)).unwrap();
        assert_eq!(config_sms.get_mfa_method(), Some("OneWaySMS".to_string()));
    }

    #[test]
    fn test_str_to_home_attr() {
        assert_eq!(str_to_home_attr("uuid"), HomeAttr::Uuid);
        assert_eq!(str_to_home_attr("spn"), HomeAttr::Spn);
        assert_eq!(str_to_home_attr("cn"), HomeAttr::Cn);
        assert_eq!(str_to_home_attr("invalid"), HomeAttr::Uuid); // Default fallback
    }

    #[test]
    fn test_split_username() {
        assert_eq!(
            split_username("user@example.com"),
            Some(("user", "example.com"))
        );
        assert_eq!(split_username("invalid_username"), None);
    }

    #[test]
    fn test_get_name_mapping_script() {
        let config_data = r#"
        [global]
        name_mapping_script = /path/to/name_mapping_script
        "#;

        let temp_file = create_temp_config(config_data);
        let config = HimmelblauConfig::new(Some(&temp_file)).unwrap();

        assert_eq!(
            config.get_name_mapping_script(),
            Some("/path/to/name_mapping_script".to_string())
        );

        let config_missing = create_empty_config();
        assert_eq!(config_missing.get_name_mapping_script(), None);
    }

    const PASSWD_MINIMAL: &str = "root:x:0:0:root:/root:/bin/bash\n";

    #[test]
    fn test_map_name_to_upn_script_execution_success() {
        let config = HimmelblauConfig::new(Some(&create_temp_config(
            r#"
        [global]
        name_mapping_script = ../../scripts/test_script_echo.sh
        domains = example.com
        "#,
        )))
        .unwrap();
        let passwd = create_temp_passwd(PASSWD_MINIMAL);
        assert_eq!(
            config.map_name_to_upn_impl("user", &passwd),
            Some("user".to_string())
        );
    }

    #[test]
    fn test_map_name_to_upn_local_user() {
        let config = HimmelblauConfig::new(Some(&create_temp_config(
            r#"
        [global]
        domains = example.com
        "#,
        )))
        .unwrap();
        let passwd = create_temp_passwd(&format!(
            "{}localuser:x:1000:1000::/home/localuser:/bin/bash\n",
            PASSWD_MINIMAL
        ));
        assert_eq!(
            config.map_name_to_upn_impl("localuser", &passwd),
            Some("localuser".to_string())
        );
    }

    #[test]
    fn test_map_name_to_upn_local_user_wins_over_ignore_list() {
        let config = HimmelblauConfig::new(Some(&create_temp_config(
            r#"
        [global]
        domains = example.com
        "#,
        )))
        .unwrap();
        let passwd = create_temp_passwd(&format!(
            "{}systemd-coredump:x:999:999::/run/systemd:/usr/sbin/nologin\n",
            PASSWD_MINIMAL
        ));
        assert_eq!(
            config.map_name_to_upn_impl("systemd-coredump", &passwd),
            Some("systemd-coredump".to_string())
        );
    }

    #[test]
    fn test_map_name_to_upn_add_domain() {
        let config = HimmelblauConfig::new(Some(&create_temp_config(
            r#"
        [global]
        cn_to_upn_mapping = true
        domains = example.com
        "#,
        )))
        .unwrap();
        let passwd = create_temp_passwd(PASSWD_MINIMAL);
        assert_eq!(
            config.map_name_to_upn_impl("user", &passwd),
            Some("user@example.com".to_string())
        );
    }

    #[test]
    fn test_map_name_to_upn_empty_is_none() {
        let config = HimmelblauConfig::new(Some(&create_temp_config(
            r#"
        [global]
        domains = example.com
        "#,
        )))
        .unwrap();
        let passwd = create_temp_passwd(PASSWD_MINIMAL);
        assert_eq!(config.map_name_to_upn_impl("", &passwd), None);
        assert_eq!(config.map_name_to_upn_impl("   ", &passwd), None);
    }

    #[test]
    fn test_map_name_to_upn_ignored_names_are_none() {
        let config = HimmelblauConfig::new(Some(&create_temp_config(
            r#"
        [global]
        domains = example.com
        "#,
        )))
        .unwrap();
        let passwd = create_temp_passwd(PASSWD_MINIMAL);
        for name in [
            "gdm",
            "sssd",
            "systemd-coredump",
            "gnome-initial-setup",
            "gdm-greeter",
            "gdm-greeter-2",
            "gdm-greeter-9",
            "pam_unix_non_existent",
            "pam_unix_non_existent:",
        ] {
            assert_eq!(
                config.map_name_to_upn_impl(name, &passwd),
                None,
                "{name} should be None"
            );
        }
    }

    #[test]
    fn test_map_name_to_upn_prefix_does_not_overmatch() {
        // A real user whose name merely starts with "gdm" must NOT be ignored.
        let config = HimmelblauConfig::new(Some(&create_temp_config(
            r#"
        [global]
        domains = example.com
        "#,
        )))
        .unwrap();
        let passwd = create_temp_passwd(PASSWD_MINIMAL);
        assert_eq!(
            config.map_name_to_upn_impl("gdmitrij.popov", &passwd),
            Some("gdmitrij.popov@example.com".to_string())
        );
    }

    #[test]
    fn test_map_name_to_upn_no_mapping() {
        let config = HimmelblauConfig::new(Some(&create_temp_config(
            r#"
        [global]
        "#,
        )))
        .unwrap();
        let passwd = create_temp_passwd(PASSWD_MINIMAL);
        assert_eq!(
            config.map_name_to_upn_impl("user", &passwd),
            Some("user".to_string())
        );
    }

    #[test]
    fn test_get_local_sudo_group() {
        let config_data = r#"
        [global]
        local_sudo_group = wheel
        "#;

        let temp_file = create_temp_config(config_data);
        let config = HimmelblauConfig::new(Some(&temp_file)).unwrap();

        let group = config.get_local_sudo_group();

        assert_eq!(group, "wheel");

        let empty_config = create_empty_config();

        let default_group = empty_config.get_local_sudo_group();

        assert_eq!(default_group, "sudo")
    }

    #[test]
    fn test_get_sudo_groups() {
        let config_data = r#"
        [example.com]
        sudo_groups = 2eb4e6a2-f55d-4cf4-8e62-978f9f4a828d,f791d7c2-66cd-4f67-a195-72c6faf3c3b5

        [global]
        sudo_groups = 825d1f7e-c4cd-4fc2-aeeb-1f92357f8da6,0149b437-fbaa-4419-bf46-f9a9f9a3438c
        "#;

        let temp_file = create_temp_config(config_data);
        let config = HimmelblauConfig::new(Some(&temp_file)).unwrap();

        let mut groups = config.get_sudo_groups();
        groups.sort();
        let mut expected_groups: Vec<String> = vec![
            "825d1f7e-c4cd-4fc2-aeeb-1f92357f8da6".to_string(),
            "0149b437-fbaa-4419-bf46-f9a9f9a3438c".to_string(),
            "2eb4e6a2-f55d-4cf4-8e62-978f9f4a828d".to_string(),
            "f791d7c2-66cd-4f67-a195-72c6faf3c3b5".to_string(),
        ];
        expected_groups.sort();

        assert_eq!(groups, expected_groups);
    }

    #[test]
    fn test_user_map_file() {
        let config_data = r#"
        [global]
        "#;
        let temp_file = create_temp_config(config_data);
        let config = HimmelblauConfig::new(Some(&temp_file)).unwrap();
        assert_eq!(config.get_user_map_file(), DEFAULT_USER_MAP_FILE);

        let config_data = r#"
        [global]
        user_map_file = /path/to/user_map
        "#;
        let temp_file = create_temp_config(config_data);
        let config = HimmelblauConfig::new(Some(&temp_file)).unwrap();
        assert_eq!(config.get_user_map_file(), "/path/to/user_map");
    }

    #[test]
    fn test_get_offline_breakglass_enabled() {
        // Explicitly disabled
        let config_data = r#"
        [offline_breakglass]
        enabled = false
        "#;
        let temp_file = create_temp_config(config_data);
        let config = HimmelblauConfig::new(Some(&temp_file)).unwrap();
        assert_eq!(config.get_offline_breakglass_enabled(), false);

        // Explicitly enabled
        let config_data = r#"
        [offline_breakglass]
        enabled = true
        "#;
        let temp_file = create_temp_config(config_data);
        let config = HimmelblauConfig::new(Some(&temp_file)).unwrap();
        assert_eq!(config.get_offline_breakglass_enabled(), true);

        // Missing value → default (false)
        let config_data = r#"
        [offline_breakglass]
        "#;
        let temp_file = create_temp_config(config_data);
        let config = HimmelblauConfig::new(Some(&temp_file)).unwrap();
        assert_eq!(config.get_offline_breakglass_enabled(), false);
    }

    #[test]
    fn test_get_offline_breakglass_ttl() {
        // TTL with hours
        let config_data = r#"
        [offline_breakglass]
        ttl = 2h
        "#;
        let temp_file = create_temp_config(config_data);
        let config = HimmelblauConfig::new(Some(&temp_file)).unwrap();
        assert_eq!(config.get_offline_breakglass_ttl(), 7200);

        // TTL with minutes
        let config_data = r#"
        [offline_breakglass]
        ttl = 30m
        "#;
        let temp_file = create_temp_config(config_data);
        let config = HimmelblauConfig::new(Some(&temp_file)).unwrap();
        assert_eq!(config.get_offline_breakglass_ttl(), 1800);

        // Invalid TTL → fallback to default
        let config_data = r#"
        [offline_breakglass]
        ttl = nonsense
        "#;
        let temp_file = create_temp_config(config_data);
        let config = HimmelblauConfig::new(Some(&temp_file)).unwrap();
        assert_eq!(
            config.get_offline_breakglass_ttl(),
            DEFAULT_OFFLINE_BREAKGLASS_TTL
        );

        // Missing → default
        let config_data = r#"
        [offline_breakglass]
        "#;
        let temp_file = create_temp_config(config_data);
        let config = HimmelblauConfig::new(Some(&temp_file)).unwrap();
        assert_eq!(
            config.get_offline_breakglass_ttl(),
            DEFAULT_OFFLINE_BREAKGLASS_TTL
        );
    }

    #[test]
    fn test_get_password_only_remote_services_deny_list_comma_separated() {
        let config_data = r#"
        [global]
        password_only_remote_services_deny_list = ssh,telnet,ftp
        "#;

        let temp_file = create_temp_config(config_data);
        let config = HimmelblauConfig::new(Some(&temp_file)).unwrap();

        let result = config.get_password_only_remote_services_deny_list();
        assert_eq!(result, vec!["ssh", "telnet", "ftp"]);
    }

    #[test]
    fn test_get_password_only_remote_services_deny_list_whitespace_trimming() {
        let config_data = r#"
        [global]
        password_only_remote_services_deny_list = ssh , telnet,  ftp  ,vnc
        "#;

        let temp_file = create_temp_config(config_data);
        let config = HimmelblauConfig::new(Some(&temp_file)).unwrap();

        let result = config.get_password_only_remote_services_deny_list();
        assert_eq!(result, vec!["ssh", "telnet", "ftp", "vnc"]);
    }

    #[test]
    fn test_get_password_only_remote_services_deny_list_empty_string() {
        let config_data = r#"
        [global]
        password_only_remote_services_deny_list =
        "#;

        let temp_file = create_temp_config(config_data);
        let config = HimmelblauConfig::new(Some(&temp_file)).unwrap();

        let result = config.get_password_only_remote_services_deny_list();
        // Empty string should be filtered out to prevent matching all services
        assert_eq!(result, Vec::<String>::new());
    }

    #[test]
    fn test_get_password_only_remote_services_deny_list_default_value() {
        let config_data = r#"
        [global]
        "#;

        let temp_file = create_temp_config(config_data);
        let config = HimmelblauConfig::new(Some(&temp_file)).unwrap();

        let result = config.get_password_only_remote_services_deny_list();
        // Should return the default list parsed from DEFAULT_PASSWORD_ONLY_REMOTE_SERVICES_DENY_LIST
        let expected: Vec<String> = DEFAULT_PASSWORD_ONLY_REMOTE_SERVICES_DENY_LIST
            .split(',')
            .map(|s| s.trim().to_string())
            .filter(|s| !s.is_empty())
            .collect();
        assert_eq!(result, expected);
        // Verify default contains expected services
        assert!(result.contains(&"ssh".to_string()));
        assert!(result.contains(&"telnet".to_string()));
    }

    #[test]
    fn test_get_password_only_remote_services_deny_list_case_sensitivity() {
        // Values are stored as-is (case-sensitive). The caller (himmelblau.rs)
        // may apply case-insensitive matching, but the config parser preserves case.
        let config_data = r#"
        [global]
        password_only_remote_services_deny_list = SSH,Telnet,FTP
        "#;

        let temp_file = create_temp_config(config_data);
        let config = HimmelblauConfig::new(Some(&temp_file)).unwrap();

        let result = config.get_password_only_remote_services_deny_list();
        assert_eq!(result, vec!["SSH", "Telnet", "FTP"]);
        // Case is preserved - these are not lowercased
        assert!(result.contains(&"SSH".to_string()));
        assert!(!result.contains(&"ssh".to_string()));
    }

    #[test]
    fn test_get_password_only_remote_services_deny_list_single_value() {
        let config_data = r#"
        [global]
        password_only_remote_services_deny_list = ssh
        "#;

        let temp_file = create_temp_config(config_data);
        let config = HimmelblauConfig::new(Some(&temp_file)).unwrap();

        let result = config.get_password_only_remote_services_deny_list();
        assert_eq!(result, vec!["ssh"]);
    }

    #[test]
    fn test_get_mfa_poll_prompt_services_default_value() {
        let config = create_empty_config();

        let result = config.get_mfa_poll_prompt_services();
        let expected: Vec<String> = DEFAULT_MFA_POLL_PROMPT_SERVICES
            .split(',')
            .map(|s| s.trim().to_string())
            .filter(|s| !s.is_empty())
            .collect();
        assert_eq!(result, expected);
        assert!(result.contains(&"ssh".to_string()));
        assert!(result.contains(&"cockpit".to_string()));
    }

    #[test]
    fn test_get_mfa_poll_prompt_services_comma_separated() {
        let config_data = r#"
        [global]
        mfa_poll_prompt_services = ssh,cockpit,custom
        "#;

        let temp_file = create_temp_config(config_data);
        let config = HimmelblauConfig::new(Some(&temp_file)).unwrap();

        let result = config.get_mfa_poll_prompt_services();
        assert_eq!(result, vec!["ssh", "cockpit", "custom"]);
    }

    #[test]
    fn test_get_mfa_poll_prompt_services_whitespace_trimming() {
        let config_data = r#"
        [global]
        mfa_poll_prompt_services = ssh , cockpit,  custom
        "#;

        let temp_file = create_temp_config(config_data);
        let config = HimmelblauConfig::new(Some(&temp_file)).unwrap();

        let result = config.get_mfa_poll_prompt_services();
        assert_eq!(result, vec!["ssh", "cockpit", "custom"]);
    }

    #[test]
    fn test_get_mfa_poll_prompt_services_empty_string() {
        let config_data = r#"
        [global]
        mfa_poll_prompt_services =
        "#;

        let temp_file = create_temp_config(config_data);
        let config = HimmelblauConfig::new(Some(&temp_file)).unwrap();

        let result = config.get_mfa_poll_prompt_services();
        assert_eq!(result, Vec::<String>::new());
    }

    // Tests for parse_ttl_to_seconds()

    #[test]
    fn test_parse_ttl_seconds() {
        assert_eq!(parse_ttl_to_seconds("10"), Some(10));
        assert_eq!(parse_ttl_to_seconds("10s"), Some(10));
        assert_eq!(parse_ttl_to_seconds("10S"), Some(10));
        assert_eq!(parse_ttl_to_seconds("0s"), Some(0));
        assert_eq!(parse_ttl_to_seconds("1"), Some(1));
    }

    #[test]
    fn test_parse_ttl_minutes() {
        assert_eq!(parse_ttl_to_seconds("1m"), Some(60));
        assert_eq!(parse_ttl_to_seconds("5m"), Some(300));
        assert_eq!(parse_ttl_to_seconds("30M"), Some(1800));
    }

    #[test]
    fn test_parse_ttl_hours() {
        assert_eq!(parse_ttl_to_seconds("1h"), Some(3600));
        assert_eq!(parse_ttl_to_seconds("2h"), Some(7200));
        assert_eq!(parse_ttl_to_seconds("24H"), Some(86400));
    }

    #[test]
    fn test_parse_ttl_days() {
        assert_eq!(parse_ttl_to_seconds("1d"), Some(86400));
        assert_eq!(parse_ttl_to_seconds("7d"), Some(604800));
        assert_eq!(parse_ttl_to_seconds("30D"), Some(2592000));
    }

    #[test]
    fn test_parse_ttl_whitespace() {
        assert_eq!(parse_ttl_to_seconds("  10s  "), Some(10));
        assert_eq!(parse_ttl_to_seconds("\t5m\n"), Some(300));
    }

    #[test]
    fn test_parse_ttl_invalid() {
        // Empty string
        assert_eq!(parse_ttl_to_seconds(""), None);
        // Invalid suffix
        assert_eq!(parse_ttl_to_seconds("10x"), None);
        assert_eq!(parse_ttl_to_seconds("10w"), None);
        // Non-numeric
        assert_eq!(parse_ttl_to_seconds("abc"), None);
        assert_eq!(parse_ttl_to_seconds("tenm"), None);
        // Negative (parse as u64 fails)
        assert_eq!(parse_ttl_to_seconds("-10s"), None);
        // Floating point
        assert_eq!(parse_ttl_to_seconds("1.5h"), None);
    }

    // Tests for split_username()

    #[test]
    fn test_split_username_valid() {
        assert_eq!(
            split_username("user@example.com"),
            Some(("user", "example.com"))
        );
        assert_eq!(
            split_username("alice@contoso.onmicrosoft.com"),
            Some(("alice", "contoso.onmicrosoft.com"))
        );
    }

    #[test]
    fn test_split_username_no_at() {
        assert_eq!(split_username("username"), None);
        assert_eq!(split_username(""), None);
    }

    #[test]
    fn test_split_username_multiple_at() {
        // More than one @ returns None (len != 2)
        assert_eq!(split_username("user@domain@extra"), None);
    }

    #[test]
    fn test_get_fido_timeout() {
        let config_data = r#"
        [global]
        fido_timeout = 60
        "#;

        let temp_file = create_temp_config(config_data);
        let config = HimmelblauConfig::new(Some(&temp_file)).unwrap();

        assert_eq!(config.get_fido_timeout(), 60);
        let config_empty = create_empty_config();
        assert_eq!(config_empty.get_fido_timeout(), 25);
    }

    #[test]
    fn test_get_fido_prompt() {
        let config_data = r#"
        [global]
        fido_prompt = Insert key now.
        "#;

        let temp_file = create_temp_config(config_data);
        let config = HimmelblauConfig::new(Some(&temp_file)).unwrap();

        assert_eq!(config.get_fido_prompt(), "Insert key now.");
        let config_empty = create_empty_config();
        assert_eq!(
            config_empty.get_fido_prompt(),
            "Please insert your security key."
        );
    }

    #[test]
    fn test_get_fido_presence_prompt() {
        let config_data = r#"
        [global]
        fido_presence_prompt = Touch key now.
        "#;

        let temp_file = create_temp_config(config_data);
        let config = HimmelblauConfig::new(Some(&temp_file)).unwrap();

        assert_eq!(config.get_fido_presence_prompt(), "Touch key now.");
        let config_empty = create_empty_config();
        assert_eq!(
            config_empty.get_fido_presence_prompt(),
            "Please touch your security key."
        );
    }

    #[test]
    fn test_split_username_edge_cases() {
        // Empty parts are still valid splits
        assert_eq!(split_username("@domain"), Some(("", "domain")));
        assert_eq!(split_username("user@"), Some(("user", "")));
        // Just @ sign
        assert_eq!(split_username("@"), Some(("", "")));
    }
}
