#!/usr/bin/env bash
set -euo pipefail
root=$(cd "$(dirname "$0")/../.." && pwd)
artifacts=${1:?artifact directory required}
test "$(uname -m)" = aarch64
python3 "$root/packages/himmelblau/verify-packages.py" "$artifacts"
docker run --rm --mount "type=bind,src=$artifacts,dst=/packages,readonly" --mount "type=bind,src=$root/ansible/roles/himmelblau/templates/himmelblau-pam.conf.j2,dst=/core-pam-profile,readonly" ubuntu:26.04 bash -euo pipefail -c '
  export DEBIAN_FRONTEND=noninteractive
  printf "#!/bin/sh\nexit 101\n" > /usr/sbin/policy-rc.d
  chmod 755 /usr/sbin/policy-rc.d
  apt-get update
  apt-get install -y --no-install-recommends openssh-server python3
  apt-get install -y --no-install-recommends /packages/himmelblau_*.deb /packages/pam-himmelblau_*.deb /packages/nss-himmelblau_*.deb
  cp /core-pam-profile /usr/share/pam-configs/himmelblau
  pam-auth-update --package
  test "$(dpkg --print-architecture)" = arm64
  himmelblaud --help >/dev/null
  aad-tool --help >/dev/null
  getent passwd root
  python3 - <<PYCODE
import ctypes, subprocess
for package, suffix in (("pam-himmelblau", "/pam_himmelblau.so"), ("nss-himmelblau", "/libnss_himmelblau.so.2")):
    paths = subprocess.check_output(["dpkg", "-L", package], text=True).splitlines()
    libraries = [path for path in paths if path.endswith(suffix)]
    assert len(libraries) == 1, (package, libraries)
    ctypes.CDLL(libraries[0])
print("Native PAM and NSS libraries loaded")
PYCODE
  grep -E "pam_himmelblau.so.*mfa_poll_prompt" /etc/pam.d/common-auth
  mkdir -p /run/sshd
  /usr/sbin/sshd -t
  python3 -c "from pathlib import Path; s=Path(\"/etc/pam.d/common-account\").read_text(); lines=[l for l in s.splitlines() if not l.lstrip().startswith(\"#\") and \"pam_himmelblau.so\" in l]; assert len(lines)==1 and \"auth_err=die\" in lines[0]"
'
