{
  lib,
  config,
  pkgs,
  ...
}:
let
  cfg = config.services.himmelblau;

  # Convert a value to INI format string
  toIniValue =
    v:
    if v == null then
      null
    else if lib.isBool v then
      (if v then "true" else "false")
    else if lib.isList v then
      lib.concatStringsSep "," v
    else
      toString v;

  # Filter out null values from an attrset
  filterNulls = attrs: lib.filterAttrs (n: v: v != null) attrs;

  # Convert typed settings to INI-compatible attrset
  # The settings structure has global options at the top level and
  # subsections (like offline_breakglass) as nested attrsets
  toIniSettings =
    settings:
    let
      # Separate top-level (global) options from subsections
      isSubsection = n: v: lib.isAttrs v && !(lib.isList v);

      globalOpts = lib.filterAttrs (n: v: !(isSubsection n v)) settings;
      subsections = lib.filterAttrs isSubsection settings;

      # Convert global options (they go in [global] section)
      globalSection = lib.mapAttrs (n: v: toIniValue v) (filterNulls globalOpts);

      # Convert each subsection
      convertedSubsections = lib.mapAttrs (
        sectionName: sectionOpts: lib.mapAttrs (n: v: toIniValue v) (filterNulls sectionOpts)
      ) subsections;
    in
    # Only include global section if it has values
    (if globalSection != { } then { global = globalSection; } else { }) // convertedSubsections;

  ini = pkgs.formats.ini { };
  configFile = ini.generate "himmelblau.conf" (toIniSettings cfg.settings);
in
{
  # Import the auto-generated typed options
  imports = [ ./himmelblau-options.nix ];

  options = {
    services.himmelblau = {
      enable = lib.mkEnableOption "Himmelblau";

      daemonPackage = lib.mkOption {
        type = lib.types.path;
        description = "Package of the himmelblau daemon";
      };

      ssoPackage = lib.mkOption {
        type = lib.types.path;
        description = "Package of the linux-entra-sso native messaging host";
      };

      brokerPackage = lib.mkOption {
        type = lib.types.path;
        description = "Package himmelblau_broker - used for sso";
      };

      pamPackage = lib.mkOption {
        type = lib.types.path;
        description = "Library for the pam module";
      };

      nssPackage = lib.mkOption {
        type = lib.types.path;
        description = "Library for the nss lookup";
      };

      mfaSshWorkaroundFlag = lib.mkOption {
        type = lib.types.bool;
        default = false;
        description = ''
          Whether to add the mfa_poll_prompt option to the libpam_himmelblau.so PAM module
          to workaround OpenSSH Bug 2876.
        '';
      };

      debugFlag = lib.mkOption {
        type = lib.types.bool;
        default = false;
        description = "Whether to pass the debug (-d) flag to the himmelblaud binary.";
      };

      tryUnsealFlag = lib.mkOption {
        type = lib.types.bool;
        default = false;
        description = ''
          Whether to add a try_unseal auth module to automatically unseal
          cached Entra ID SSO material using the login password as PIN, similar
          to how pam_gnome_keyring unlocks the keyring at login.

          This cannot be used with enable_hello_totp. When Hello TOTP is enabled,
          the daemon refuses the non-interactive unseal before loading cached SSO
          material because the hook cannot collect the required second factor.
        '';
      };

      pamServices = lib.mkOption {
        type = lib.types.listOf lib.types.str;
        default = [
          "passwd"
          "login"
          "su"
          "systemd-user"
        ];
        description = "Which PAM services to add the himmelblau module to.";
      };

      # Note: settings options are now defined in himmelblau-options.nix
      # which is auto-generated from docs-xml/ by src/common/scripts/gen_param_code.py
    };
  };

  config = lib.mkIf cfg.enable {
    # The default HSM mode uses the TPM when available. Configure its udev
    # permissions as well as compiling support, unless explicitly disabled.
    security.tpm2.enable = lib.mkDefault (cfg.settings.hsm_type != "soft");

    environment.etc."himmelblau/himmelblau.conf".source = configFile;

    systemd.tmpfiles.rules = [
      "d /var/cache/nss-himmelblau 0755 root root -"
    ];

    programs.firefox = {
      policies = {
        Extensions.Install = [
          "https://github.com/siemens/linux-entra-sso/releases/download/v1.7.1/linux_entra_sso-1.7.1.xpi"
        ];
      };
      nativeMessagingHosts.packages = [ cfg.ssoPackage ];
    };

    programs.chromium.extensions = [
      "jlnfnnolkbjieggibinobhkjdfbpcohn"
    ];
    environment.etc."chromium/native-messaging-hosts/linux_entra_sso.json".source =
      "${cfg.ssoPackage}/lib/chromium/native-messaging-hosts/linux_entra_sso.json";
    environment.etc."opt/chrome/native-messaging-hosts/linux_entra_sso.json".source =
      "${cfg.ssoPackage}/lib/chromium/native-messaging-hosts/linux_entra_sso.json";
    services.dbus.packages = [ cfg.brokerPackage ];

    # Add himmelblau to the list of name services to lookup users/groups
    system.nssModules = [ cfg.nssPackage ];
    system.nssDatabases.passwd = lib.mkOrder 1501 [ "himmelblau" ]; # will be merged with entries from other modules
    system.nssDatabases.group = lib.mkOrder 1501 [ "himmelblau" ]; # will be merged with entries from other modules
    system.nssDatabases.shadow = lib.mkOrder 1501 [ "himmelblau" ]; # will be merged with entries from other modules

    # Add entries for authenticating users via pam
    security.pam.services =
      let
        genServiceCfg = service: {
          rules =
            let
              super = config.security.pam.services.${service}.rules;
              # nixpkgs adds a second, earlier pam_unix rule named
              # "unix-early" whenever something downstream needs the
              # password already cached (GNOME keyring, fscrypt,
              # kwallet, ...). It prompts, and it displaces the main
              # unix rule to a much later order, so anchoring only to
              # the main rule puts himmelblau behind a password prompt
              # and defeats the device code flow. Anchor to whichever
              # pam_unix rule comes first.
              authUnixOrder =
                if super.auth ? unix-early then
                  lib.min super.auth.unix-early.order super.auth.unix.order
                else
                  super.auth.unix.order;
            in
            {
              account.himmelblau = {
                order = super.account.unix.order - 10;
                control = "sufficient";
                modulePath = "${cfg.pamPackage.lib}/lib/libpam_himmelblau.so";
                settings.ignore_unknown_user = true;
                settings.debug = cfg.debugFlag;
              };
              auth.himmelblau = {
                order = authUnixOrder - 10;
                control = "sufficient";
                modulePath = "${cfg.pamPackage.lib}/lib/libpam_himmelblau.so";
                settings.mfa_poll_prompt = cfg.mfaSshWorkaroundFlag && service == "sshd";
                settings.debug = cfg.debugFlag;
              };
              session.himmelblau = {
                order = super.session.unix.order - 10;
                control = "optional";
                modulePath = "${cfg.pamPackage.lib}/lib/libpam_himmelblau.so";
                settings.debug = cfg.debugFlag;
              };
              auth.himmelblau-unseal = lib.mkIf cfg.tryUnsealFlag {
                order = super.auth.unix.order + 1000;
                control = "optional";
                modulePath = "${cfg.package}/lib/libpam_himmelblau.so";
                settings.try_unseal = true;
                settings.debug = cfg.debugFlag;
              };
            };
        };
        services =
          cfg.pamServices
          ++ lib.optional config.security.sudo.enable "sudo"
          ++ lib.optional config.security.doas.enable "doas"
          ++ lib.optional config.security.polkit.enable "polkit-1"
          ++ lib.optional config.services.sshd.enable "sshd";
      in
      lib.genAttrs services genServiceCfg;

    systemd.user.services.himmelblau-broker = {
      description = "Himmelblau Authentication Broker";
      serviceConfig = {
        Type = "dbus";
        BusName = "com.microsoft.identity.broker1";
        ExecStart = "${cfg.brokerPackage}/bin/himmelblau_broker";
        Slice = "background.slice";
        TimeoutStopSec = 5;
        Restart = "on-failure";
        WatchdogSec = "120s";
      };
    };

    systemd.services =
      let
        commonServiceConfig = {
          Type = "notify";
          UMask = "0027";
          # SystemCallFilter = "@aio @basic-io @chown @file-system @io-event @network-io @sync";
          NoNewPrivileges = true;
          PrivateDevices = true;
          ProtectHostname = true;
          ProtectClock = true;
          ProtectKernelTunables = true;
          ProtectKernelModules = true;
          ProtectKernelLogs = true;
          ProtectControlGroups = true;
          MemoryDenyWriteExecute = true;
        };
      in
      {

        himmelblaud = {
          description = "Himmelblau Authentication Daemon";
          wants = [
            "chronyd.service"
            "ntpd.service"
            "network-online.target"
          ] ++ lib.optional config.security.tpm2.enable "tpm2-udev-trigger.service";
          after = lib.optional config.security.tpm2.enable "tpm2-udev-trigger.service";
          before = [ "accounts-daemon.service" ];
          wantedBy = [
            "multi-user.target"
            "accounts-daemon.service"
          ];

          upholds = [ "himmelblaud-tasks.service" ];
          serviceConfig = commonServiceConfig // {
            ExecStart =
              "${cfg.daemonPackage}/bin/himmelblaud --config ${configFile}"
              + lib.optionalString cfg.debugFlag " -d";
            Restart = "on-failure";
            WatchdogSec = "120s";
            DynamicUser = "yes";
            CacheDirectory = "himmelblaud"; # /var/cache/himmelblaud
            CacheDirectoryMode = "0750";
            RuntimeDirectory = "himmelblaud"; # /var/run/himmelblaud
            StateDirectory = "himmelblaud"; # /var/lib/himmelblaud
            PrivateTmp = true;
            # We have to disable this to allow tpmrm0 access for tpm binding.
            PrivateDevices = false;
            # ProtectClock adds a device allowlist. Both tpm and tpmrm devices
            # use the kernel's "tpm" character-device major.
            DeviceAllow = [ "char-tpm rw" ];
            SupplementaryGroups = lib.optional (
              config.security.tpm2.enable && config.security.tpm2.tssGroup != null
            ) config.security.tpm2.tssGroup;
          };
        };

        himmelblaud-tasks = {
          description = "Himmelblau Local Tasks";
          bindsTo = [ "himmelblaud.service" ];
          wantedBy = [ "multi-user.target" ];
          path = [
            pkgs.shadow
            pkgs.bash
            pkgs.util-linux
          ];
          unitConfig = {
            ConditionPathExists = "/var/run/himmelblaud/task_sock";
          };
          serviceConfig = commonServiceConfig // {
            ExecStart = "${cfg.daemonPackage}/bin/himmelblaud_tasks";
            Restart = "on-failure";
            WatchdogSec = "120s";
            User = "root";
            ProtectSystem = "strict";
            CacheDirectory = "himmelblau-policies"; # /var/cache/himmelblau-policies
            ReadWritePaths =
              "/home /var/run/himmelblaud /tmp /etc/krb5.conf.d /etc /var/lib /var/cache/nss-himmelblau /var/cache/himmelblau-policies";
            RestrictAddressFamilies = ["AF_UNIX" "AF_INET" "AF_INET6"];
          };
        };
      };
  };

}
