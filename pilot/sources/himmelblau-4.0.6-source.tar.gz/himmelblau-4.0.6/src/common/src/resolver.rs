/*
 * Unix Azure Entra ID implementation
 * Copyright (C) William Brown <william@blackhats.net.au> and the Kanidm team 2018-2024
 * Copyright (C) David Mulder <dmulder@samba.org> 2024
 *
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/.
 */

// use async_trait::async_trait;
use hashbrown::HashSet;
use libc::uid_t;
use libkrimes::proto::KerberosCredentials;
use std::collections::{BTreeSet, HashMap};
use std::fmt::Display;
use std::fs;
use std::num::NonZeroUsize;
use std::ops::DerefMut;
use std::path::Path;
use std::string::ToString;
use std::sync::atomic::{AtomicU64, Ordering};
use std::time::{Duration, SystemTime};

use lru::LruCache;
use tokio::sync::Mutex;
use uuid::Uuid;
use zeroize::Zeroizing;

use crate::config::InitgroupsMode;
use crate::constants::SERVER_CONFIG_PATH;
use crate::db::{Cache, CacheTxn, Db};
use crate::idprovider::interface::{
    AuthCacheAction,
    AuthCredHandler,
    AuthRequest,
    AuthResult,
    CacheState,
    GroupToken,
    Id,
    IdProvider,
    IdpError,
    // KeyStore,
    UserToken,
    UserTokenState,
};
use crate::unix_config::{HomeAttr, UidAttr};
use crate::unix_proto::{HomeDirectoryInfo, NssGroup, NssUser, PamAuthRequest, PamAuthResponse};

use kanidm_hsm_crypto::{
    provider::BoxedDynTpm, structures::HmacS256Key as HmacKey, structures::StorageKey as MachineKey,
};

use tokio::sync::broadcast;

use himmelblau::auth::UserToken as UnixUserToken;

const NXCACHE_SIZE: NonZeroUsize = NonZeroUsize::new(128).unwrap();

// These keys deliberately mirror account_t's UUID/name/SPN/GID conflicts.
// They are not tenant-scoped because the database's uniqueness constraints are not.
#[derive(Debug, Clone, PartialEq, Eq, Hash)]
enum PasswordCacheKey {
    Uuid(Uuid),
    Name(String),
    Spn(String),
    Gid(u32),
}

#[derive(Clone, Copy)]
struct PasswordCacheGeneration {
    identity_generation: u64,
    password_generation: Option<u64>,
    uuid: Uuid,
    tenant_id: Option<Uuid>,
}

#[derive(Debug, PartialEq, Eq)]
enum CacheUpdateResult {
    Updated,
    Superseded,
    IdentityChanged,
}

#[allow(clippy::large_enum_variant)]
pub enum AuthSession {
    InProgress {
        account_id: String,
        service: String,
        id: Id,
        token: Option<Box<UserToken>>,
        pending_password: Option<(u64, Zeroizing<String>)>,
        // Retain the accepted identity's order through local PIN/TOTP setup too.
        cache_generation: u64,
        identity_staged: bool,
        online_at_init: bool,
        cred_handler: AuthCredHandler,
        /// Some authentication operations may need to spawn background tasks. These tasks need
        /// to know when to stop as the caller has disconnected. This reciever allows that, so
        /// that tasks which .resubscribe() to this channel can then select! on it and be notified
        /// when they need to stop.
        shutdown_rx: broadcast::Receiver<()>,
        no_hello_pin: bool,
        force_reauth: bool,
    },
    Success(String),
    Denied,
}

pub struct Resolver<I>
where
    I: IdProvider + Sync,
{
    // Generic / modular types.
    db: Db,
    hsm: Mutex<BoxedDynTpm>,
    machine_key: MachineKey,
    hmac_key: HmacKey,
    client: I,
    pam_allow_groups: BTreeSet<String>,
    oidc_auth: bool,
    timeout_seconds: u64,
    default_shell: String,
    home_prefix: String,
    home_attr: HomeAttr,
    home_alias: Option<HomeAttr>,
    uid_attr_map: UidAttr,
    gid_attr_map: UidAttr,
    initgroups_mode: InitgroupsMode,
    allow_id_overrides: HashSet<Id>,
    nxset: Mutex<HashSet<Id>>,
    nxcache: Mutex<LruCache<Id, SystemTime>>,
    password_generation: AtomicU64,
    // Keep committed identity observations and password invalidations while older sessions exist.
    // Both this map and all pending sessions disappear on daemon restart.
    password_cache_generations: Mutex<HashMap<PasswordCacheKey, PasswordCacheGeneration>>,
}

impl Display for Id {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.write_str(&match self {
            Id::Name(s) => s.to_string(),
            Id::Gid(g) => g.to_string(),
        })
    }
}

#[cfg(test)]
mod tests {
    use super::{AuthSession, CacheUpdateResult, Resolver};
    use crate::config::InitgroupsMode;
    use crate::db::{Cache, CacheTxn, Db, KeyStoreTxn};
    use crate::idprovider::interface::{
        tpm, AuthCacheAction, AuthCredHandler, AuthRequest, AuthResult, CacheState, GroupToken, Id,
        IdProvider, IdpError, UserToken, UserTokenState,
    };
    use crate::unix_config::{HomeAttr, UidAttr};
    use crate::unix_proto::{PamAuthRequest, PamAuthResponse};
    use async_trait::async_trait;
    use himmelblau::UserToken as UnixUserToken;
    use kanidm_hsm_crypto::{provider::BoxedDynTpm, provider::SoftTpm, provider::Tpm, AuthValue};
    use libkrimes::proto::KerberosCredentials;
    use std::sync::atomic::{AtomicBool, AtomicUsize, Ordering};
    use std::sync::RwLock;
    use std::time::{Duration, SystemTime};
    use tokio::sync::broadcast;

    struct OfflineFallbackProvider {
        cache_state: RwLock<CacheState>,
        check_online_result: AtomicBool,
        cache_state_calls: AtomicUsize,
        check_online_calls: AtomicUsize,
        try_unseal_online: AtomicBool,
        user_get_calls: AtomicUsize,
        try_unseal_calls: AtomicUsize,
        user_get_error: AtomicUsize,
        auth_token: RwLock<UserToken>,
    }

    impl OfflineFallbackProvider {
        fn new() -> Self {
            Self {
                cache_state: RwLock::new(CacheState::Online),
                check_online_result: AtomicBool::new(true),
                cache_state_calls: AtomicUsize::new(0),
                check_online_calls: AtomicUsize::new(0),
                try_unseal_online: AtomicBool::new(false),
                user_get_calls: AtomicUsize::new(0),
                try_unseal_calls: AtomicUsize::new(0),
                user_get_error: AtomicUsize::new(0),
                auth_token: RwLock::new(test_token()),
            }
        }

        fn auth_token(&self) -> UserToken {
            self.auth_token
                .read()
                .expect("auth token lock poisoned")
                .clone()
        }

        fn set_cache_state(&self, state: CacheState) {
            *self.cache_state.write().expect("cache state lock poisoned") = state;
        }
    }

    #[async_trait]
    impl IdProvider for OfflineFallbackProvider {
        async fn check_online(
            &self,
            _tpm: &mut tpm::provider::BoxedDynTpm,
            _now: SystemTime,
        ) -> bool {
            self.check_online_calls.fetch_add(1, Ordering::AcqRel);
            self.check_online_result.load(Ordering::Acquire)
        }

        async fn unix_user_get<D: KeyStoreTxn + Send>(
            &self,
            _id: &Id,
            _token: Option<&UserToken>,
            _keystore: &mut D,
            _tpm: &mut tpm::provider::BoxedDynTpm,
            _machine_key: &tpm::structures::StorageKey,
        ) -> Result<UserTokenState, IdpError> {
            self.user_get_calls.fetch_add(1, Ordering::AcqRel);
            match self.user_get_error.load(Ordering::Acquire) {
                1 => Err(IdpError::NotFound {
                    what: "user".to_string(),
                    where_: "test provider".to_string(),
                }),
                2 => Err(IdpError::BadRequest),
                3..=5 | 7 if matches!(_id, Id::Name(_)) => {
                    Ok(UserTokenState::LookupOnly(test_token()))
                }
                6 => Ok(UserTokenState::Update(self.auth_token())),
                _ => Ok(UserTokenState::UseCached),
            }
        }

        async fn unix_user_access<D: KeyStoreTxn + Send>(
            &self,
            _id: &Id,
            _scopes: Vec<String>,
            _token: Option<&UserToken>,
            _client_id: Option<String>,
            _redirect_uri: Option<String>,
            _req_cnf: Option<String>,
            _keystore: &mut D,
            _tpm: &mut tpm::provider::BoxedDynTpm,
            _machine_key: &tpm::structures::StorageKey,
        ) -> Result<UnixUserToken, IdpError> {
            Err(IdpError::BadRequest)
        }

        async fn unix_user_tgts<D: KeyStoreTxn + Send>(
            &self,
            _id: &Id,
            _old_token: Option<&UserToken>,
            _keystore: &mut D,
            _tpm: &mut tpm::provider::BoxedDynTpm,
            _machine_key: &tpm::structures::StorageKey,
        ) -> (
            Option<Box<KerberosCredentials>>,
            Option<Box<KerberosCredentials>>,
            Option<String>,
            Option<String>,
        ) {
            (None, None, None, None)
        }

        async fn unix_user_prt_cookie<D: KeyStoreTxn + Send>(
            &self,
            _id: &Id,
            _token: Option<&UserToken>,
            _sso_nonce: Option<&str>,
            _keystore: &mut D,
            _tpm: &mut tpm::provider::BoxedDynTpm,
            _machine_key: &tpm::structures::StorageKey,
        ) -> Result<String, IdpError> {
            Err(IdpError::BadRequest)
        }

        async fn change_auth_token<D: KeyStoreTxn + Send>(
            &self,
            _account_id: &str,
            _token: &UnixUserToken,
            _new_tok: &str,
            _keystore: &mut D,
            _tpm: &mut tpm::provider::BoxedDynTpm,
            _machine_key: &tpm::structures::StorageKey,
        ) -> Result<bool, IdpError> {
            Err(IdpError::BadRequest)
        }

        async fn unix_user_online_auth_init<D: KeyStoreTxn + Send>(
            &self,
            _account_id: &str,
            _token: Option<&UserToken>,
            _service: &str,
            _no_hello_pin: bool,
            _force_reauth: bool,
            _keystore: &mut D,
            _tpm: &mut tpm::provider::BoxedDynTpm,
            _machine_key: &tpm::structures::StorageKey,
            _shutdown_rx: &broadcast::Receiver<()>,
        ) -> Result<(AuthRequest, AuthCredHandler), IdpError> {
            if matches!(self.user_get_error.load(Ordering::Acquire), 3..=5 | 7) {
                return Ok((
                    AuthRequest::Password {
                        prompt: None,
                        long_prompt: None,
                    },
                    AuthCredHandler::None,
                ));
            }
            self.set_cache_state(CacheState::OfflineNextCheck(
                SystemTime::now() + Duration::from_secs(60),
            ));
            Err(IdpError::BadRequest)
        }

        async fn unix_user_online_auth_step<D: KeyStoreTxn + Send>(
            &self,
            _account_id: &str,
            _old_token: &UserToken,
            _service: &str,
            _no_hello_pin: bool,
            _cred_handler: &mut AuthCredHandler,
            _pam_next_req: PamAuthRequest,
            _keystore: &mut D,
            _tpm: &mut tpm::provider::BoxedDynTpm,
            _machine_key: &tpm::structures::StorageKey,
            _shutdown_rx: &broadcast::Receiver<()>,
        ) -> Result<(AuthResult, AuthCacheAction), IdpError> {
            if self.user_get_error.load(Ordering::Acquire) == 5 {
                return Ok((
                    AuthResult::Success {
                        token: self.auth_token(),
                    },
                    AuthCacheAction::None,
                ));
            }
            if self.user_get_error.load(Ordering::Acquire) == 3 {
                return Ok((
                    AuthResult::Success {
                        token: self.auth_token(),
                    },
                    AuthCacheAction::PasswordHashUpdate {
                        cred: match _pam_next_req {
                            PamAuthRequest::Password { cred } => cred,
                            _ => return Err(IdpError::BadRequest),
                        },
                    },
                ));
            }
            if matches!(self.user_get_error.load(Ordering::Acquire), 4 | 7) {
                if matches!(&_pam_next_req, PamAuthRequest::Password { cred } if cred == "direct-totp")
                {
                    return Ok((
                        AuthResult::Next(AuthRequest::HelloTOTP {
                            msg: "Enter local TOTP".to_string(),
                        }),
                        AuthCacheAction::None,
                    ));
                }
                if let PamAuthRequest::HelloTOTP { cred } = &_pam_next_req {
                    return Ok((
                        AuthResult::Success {
                            token: self.auth_token(),
                        },
                        if cred == "cache-password" {
                            AuthCacheAction::PasswordHashUpdate {
                                cred: "late-secret".to_string(),
                            }
                        } else {
                            AuthCacheAction::None
                        },
                    ));
                }
                if matches!(&_pam_next_req, PamAuthRequest::SetupPin { pin } if pin == "totp") {
                    return Ok((
                        AuthResult::Next(AuthRequest::HelloTOTP {
                            msg: "Enter local TOTP".to_string(),
                        }),
                        AuthCacheAction::None,
                    ));
                }
                if matches!(&_pam_next_req, PamAuthRequest::SetupPin { pin } if pin == "retry") {
                    return Ok((
                        AuthResult::Next(AuthRequest::SetupPin {
                            msg: "Try a different PIN".to_string(),
                        }),
                        AuthCacheAction::None,
                    ));
                }
                if matches!(_pam_next_req, PamAuthRequest::SetupPin { .. }) {
                    return Ok((
                        AuthResult::Success {
                            token: self.auth_token(),
                        },
                        AuthCacheAction::None,
                    ));
                }
                if self.user_get_error.load(Ordering::Acquire) == 7 {
                    return Ok((
                        AuthResult::Next(AuthRequest::SetupPin {
                            msg: "Set PIN".to_string(),
                        }),
                        AuthCacheAction::None,
                    ));
                }
                return Ok((
                    AuthResult::Next(AuthRequest::SetupPin {
                        msg: "Set PIN".to_string(),
                    }),
                    AuthCacheAction::PasswordHashUpdate {
                        cred: match _pam_next_req {
                            PamAuthRequest::Password { cred } => cred,
                            _ => return Err(IdpError::BadRequest),
                        },
                    },
                ));
            }
            Err(IdpError::BadRequest)
        }

        async fn unix_user_offline_auth_init<D: KeyStoreTxn + Send>(
            &self,
            _account_id: &str,
            _token: Option<&UserToken>,
            _service: &str,
            _no_hello_pin: bool,
            _keystore: &mut D,
        ) -> Result<(AuthRequest, AuthCredHandler), IdpError> {
            Ok((AuthRequest::Pin, AuthCredHandler::None))
        }

        async fn unix_user_offline_auth_step<D: KeyStoreTxn + Send>(
            &self,
            _account_id: &str,
            _token: &UserToken,
            _cred_handler: &mut AuthCredHandler,
            _pam_next_req: PamAuthRequest,
            _keystore: &mut D,
            _tpm: &mut tpm::provider::BoxedDynTpm,
            _machine_key: &tpm::structures::StorageKey,
            _online_at_init: bool,
        ) -> Result<AuthResult, IdpError> {
            Err(IdpError::BadRequest)
        }

        async fn unix_user_try_unseal<D: KeyStoreTxn + Send>(
            &self,
            _account_id: &str,
            _cred: &str,
            _keystore: &mut D,
            _tpm: &mut tpm::provider::BoxedDynTpm,
            _machine_key: &tpm::structures::StorageKey,
            online: bool,
        ) -> Result<bool, IdpError> {
            self.try_unseal_calls.fetch_add(1, Ordering::AcqRel);
            self.try_unseal_online.store(online, Ordering::Release);
            Ok(true)
        }

        async fn unix_group_get(
            &self,
            _id: &Id,
            _tpm: &mut tpm::provider::BoxedDynTpm,
        ) -> Result<GroupToken, IdpError> {
            Err(IdpError::NotFound {
                what: "group".to_string(),
                where_: "test".to_string(),
            })
        }

        async fn get_cachestate<D: KeyStoreTxn + Send>(
            &self,
            _account_id: Option<&str>,
            _keystore: &mut D,
        ) -> CacheState {
            self.cache_state_calls.fetch_add(1, Ordering::AcqRel);
            self.cache_state
                .read()
                .expect("cache state lock poisoned")
                .clone()
        }

        async fn offline_break_glass(&self, _ttl: Option<u64>) -> Result<(), IdpError> {
            Ok(())
        }
    }

    fn test_token() -> UserToken {
        let group = GroupToken {
            name: "linux-users".to_string(),
            spn: "linux-users".to_string(),
            uuid: uuid::uuid!("9f8a7a5a-a8e8-5c57-9f4f-7dfe21126c23"),
            gidnumber: 2100,
        };
        UserToken {
            name: "testuser".to_string(),
            spn: "testuser@example.com".to_string(),
            uuid: uuid::uuid!("0302b99c-f0f6-41ab-9492-852692b0fd16"),
            real_gidnumber: Some(2000),
            gidnumber: 2000,
            displayname: "Test User".to_string(),
            shell: None,
            groups: vec![group],
            tenant_id: Some(uuid::uuid!("58e8a301-2502-4814-81c5-a4d17c399a45")),
            valid: true,
        }
    }

    async fn setup_resolver_with_expiry(expiry: u64) -> Resolver<OfflineFallbackProvider> {
        setup_resolver_with(expiry, InitgroupsMode::Named, Vec::new()).await
    }

    async fn setup_resolver_with(
        expiry: u64,
        initgroups_mode: InitgroupsMode,
        extra_groups: Vec<GroupToken>,
    ) -> Resolver<OfflineFallbackProvider> {
        let db = Db::new("").expect("failed to create test db");
        setup_resolver_with_db(db, expiry, initgroups_mode, extra_groups).await
    }

    async fn setup_resolver_with_db(
        db: Db,
        expiry: u64,
        initgroups_mode: InitgroupsMode,
        extra_groups: Vec<GroupToken>,
    ) -> Resolver<OfflineFallbackProvider> {
        let mut dbtxn = db.write().await;
        dbtxn.migrate().expect("failed to migrate test db");
        let mut token = test_token();
        let named_group = token.groups[0].clone();
        token.groups.extend(extra_groups);
        dbtxn
            .update_group(&named_group, expiry)
            .expect("failed to seed test group");
        dbtxn
            .update_account(&token, expiry)
            .expect("failed to seed test token");
        dbtxn.commit().expect("failed to commit test db");

        let mut hsm = BoxedDynTpm::new(SoftTpm::new());
        let auth_value = AuthValue::ephemeral().expect("failed to create auth value");
        let loadable_machine_key = hsm
            .root_storage_key_create(&auth_value)
            .expect("failed to create machine key");
        let machine_key = hsm
            .root_storage_key_load(&auth_value, &loadable_machine_key)
            .expect("failed to load machine key");

        Resolver::new(
            db,
            OfflineFallbackProvider::new(),
            hsm,
            machine_key,
            3600,
            vec!["9f8a7a5a-a8e8-5c57-9f4f-7dfe21126c23".to_string()],
            false,
            "/bin/sh".to_string(),
            "/home/".to_string(),
            HomeAttr::Name,
            None,
            UidAttr::Name,
            UidAttr::Name,
            initgroups_mode,
            Vec::new(),
        )
        .await
        .expect("failed to create resolver")
    }

    async fn setup_resolver() -> Resolver<OfflineFallbackProvider> {
        setup_resolver_with_expiry(0).await
    }

    async fn setup_sql_resolver() -> (Resolver<OfflineFallbackProvider>, rusqlite::Connection) {
        let uri = format!(
            "file:password-cache-{}?mode=memory&cache=shared",
            uuid::Uuid::new_v4()
        );
        let conn = rusqlite::Connection::open(&uri).unwrap();
        let db = Db::new(&uri).unwrap();
        let resolver = setup_resolver_with_db(db, 0, InitgroupsMode::Named, Vec::new()).await;
        (resolver, conn)
    }

    #[tokio::test]
    async fn lookup_only_user_is_not_cached_before_first_login() {
        let resolver = setup_resolver().await;
        resolver
            .delete_cache_usertoken(test_token().uuid)
            .await
            .unwrap();
        resolver.client.user_get_error.store(3, Ordering::Release);

        let user = resolver
            .get_nssaccount_name("testuser@example.com")
            .await
            .unwrap()
            .unwrap();
        assert!(!user.cacheable);
        assert!(resolver.get_cached_usertokens().await.unwrap().is_empty());
        assert!(resolver
            .get_nssaccount_gid(user.uid)
            .await
            .unwrap()
            .is_none());

        let (_shutdown_tx, shutdown_rx) = broadcast::channel(1);
        let (mut session, response) = resolver
            .pam_account_authenticate_init(
                "testuser@example.com",
                "sshd",
                false,
                false,
                shutdown_rx,
            )
            .await
            .unwrap();
        assert!(matches!(response, PamAuthResponse::Password { .. }));
        assert!(resolver.get_cached_usertokens().await.unwrap().is_empty());

        let response = resolver
            .pam_account_authenticate_step(
                &mut session,
                PamAuthRequest::Password {
                    cred: "secret".to_string(),
                },
            )
            .await
            .unwrap();
        assert!(matches!(response, PamAuthResponse::Success));
        assert_eq!(resolver.get_cached_usertokens().await.unwrap().len(), 1);
        assert!(resolver
            .check_cache_userpassword(test_token().uuid, "secret")
            .await
            .unwrap());
    }

    #[tokio::test]
    async fn lookup_only_user_does_not_revalidate_expired_cached_identity() {
        let resolver = setup_resolver().await;
        let token = test_token();
        resolver
            .set_cache_userpassword(token.uuid, "secret")
            .await
            .unwrap();
        resolver.client.user_get_error.store(3, Ordering::Release);

        let user = resolver
            .get_nssaccount_name(&token.spn)
            .await
            .unwrap()
            .unwrap();
        assert!(!user.cacheable);
        assert!(resolver.get_nssaccounts().await.unwrap().is_empty());
        let mut dbtxn = resolver.db.write().await;
        let (cached, expiry) = dbtxn
            .get_account(&Id::Name(token.spn.clone()))
            .unwrap()
            .unwrap();
        // The lookup-only result deliberately has the same UUID as the
        // expired row left behind by migration.
        assert_eq!(cached.uuid, token.uuid);
        assert_eq!(expiry, 0);
        dbtxn.commit().unwrap();
        assert!(resolver
            .check_cache_userpassword(token.uuid, "secret")
            .await
            .unwrap());
    }

    #[tokio::test]
    async fn trusted_user_refresh_is_cacheable() {
        let resolver = setup_resolver().await;
        let token = test_token();
        resolver.client.user_get_error.store(6, Ordering::Release);

        assert!(
            resolver
                .get_nssaccount_name(&token.spn)
                .await
                .unwrap()
                .unwrap()
                .cacheable
        );
        let (expired, cached) = resolver
            .get_cached_usertoken(&Id::Name(token.spn))
            .await
            .unwrap();
        assert!(!expired);
        assert_eq!(cached.unwrap().uuid, token.uuid);
        assert!(
            resolver
                .get_nssaccount_gid(token.gidnumber)
                .await
                .unwrap()
                .unwrap()
                .cacheable
        );
        assert_eq!(resolver.client.user_get_calls.load(Ordering::Acquire), 1);
    }

    #[tokio::test]
    async fn unexpired_cached_user_is_cacheable() {
        let expiry = (SystemTime::now() + Duration::from_secs(3600))
            .duration_since(SystemTime::UNIX_EPOCH)
            .unwrap()
            .as_secs();
        for state in [
            CacheState::Online,
            CacheState::Offline,
            CacheState::OfflineNextCheck(SystemTime::now() + Duration::from_secs(60)),
        ] {
            let resolver = setup_resolver_with_expiry(expiry).await;
            resolver.client.set_cache_state(state);
            let token = test_token();
            for id in [
                Id::Name(token.spn),
                Id::Name(token.name),
                Id::Gid(token.gidnumber),
            ] {
                assert!(
                    resolver
                        .get_nssaccount(id)
                        .await
                        .unwrap()
                        .unwrap()
                        .cacheable
                );
            }
            assert_eq!(resolver.client.user_get_calls.load(Ordering::Acquire), 0);
        }
    }

    #[tokio::test]
    async fn expired_cached_user_remains_available_but_not_cacheable() {
        for (state, error) in [
            (CacheState::Offline, 0),
            (
                CacheState::OfflineNextCheck(SystemTime::now() + Duration::from_secs(60)),
                0,
            ),
            (CacheState::OfflineNextCheck(SystemTime::UNIX_EPOCH), 0),
            (CacheState::Online, 0),
            (CacheState::Online, 1),
            (CacheState::Online, 2),
        ] {
            let resolver = setup_resolver().await;
            let token = test_token();
            resolver.client.set_cache_state(state);
            resolver
                .client
                .user_get_error
                .store(error, Ordering::Release);
            resolver
                .client
                .check_online_result
                .store(false, Ordering::Release);
            resolver
                .set_cache_userpassword(token.uuid, "secret")
                .await
                .unwrap();

            let cached = resolver
                .get_usertoken(Id::Name(token.spn.clone()))
                .await
                .unwrap()
                .unwrap();
            assert_eq!(cached.uuid, token.uuid);
            for id in [Id::Name(token.spn.clone()), Id::Gid(token.gidnumber)] {
                assert!(
                    !resolver
                        .get_nssaccount(id)
                        .await
                        .unwrap()
                        .unwrap()
                        .cacheable
                );
            }
            let mut dbtxn = resolver.db.write().await;
            let (_, expiry) = dbtxn.get_account(&Id::Name(token.spn)).unwrap().unwrap();
            assert_eq!(expiry, 0);
            dbtxn.commit().unwrap();
            assert!(resolver
                .check_cache_userpassword(token.uuid, "secret")
                .await
                .unwrap());
        }
    }

    #[tokio::test]
    async fn online_auth_succeeds_when_offline_password_cache_fails() {
        for (setup_pin, cached_password) in [
            (false, None),
            (true, None),
            (false, Some("old-secret")),
            (true, Some("old-secret")),
            (false, Some("secret")),
        ] {
            // Share an isolated in-memory database with a connection that can
            // fail only verifier replacements, leaving identity caching operational.
            let (resolver, conn) = setup_sql_resolver().await;
            if let Some(cred) = cached_password {
                resolver
                    .set_cache_userpassword(test_token().uuid, cred)
                    .await
                    .unwrap();
            } else {
                resolver
                    .delete_cache_usertoken(test_token().uuid)
                    .await
                    .unwrap();
            }
            conn.execute_batch(
                "CREATE TRIGGER fail_password_cache BEFORE UPDATE OF password ON account_t
                 WHEN NEW.password IS NOT NULL
                 BEGIN SELECT RAISE(ABORT, 'injected password cache failure'); END;",
            )
            .unwrap();
            resolver
                .client
                .user_get_error
                .store(if setup_pin { 4 } else { 3 }, Ordering::Release);

            for cache_fails in [true, false] {
                if !cache_fails {
                    // A later login must update the verifier once storage
                    // recovers, including a password staged until PIN setup.
                    conn.execute_batch("DROP TRIGGER fail_password_cache")
                        .unwrap();
                }
                let (_shutdown_tx, shutdown_rx) = broadcast::channel(1);
                let (mut session, response) = resolver
                    .pam_account_authenticate_init(
                        "testuser@example.com",
                        "sshd",
                        false,
                        false,
                        shutdown_rx,
                    )
                    .await
                    .unwrap();
                assert!(matches!(response, PamAuthResponse::Password { .. }));
                let mut response = resolver
                    .pam_account_authenticate_step(
                        &mut session,
                        PamAuthRequest::Password {
                            cred: "secret".to_string(),
                        },
                    )
                    .await
                    .unwrap();
                if setup_pin {
                    assert!(matches!(response, PamAuthResponse::SetupPin { .. }));
                    if cache_fails && cached_password.is_none() {
                        assert!(resolver.get_cached_usertokens().await.unwrap().is_empty());
                    }
                    response = resolver
                        .pam_account_authenticate_step(
                            &mut session,
                            PamAuthRequest::SetupPin {
                                pin: "123456".to_string(),
                            },
                        )
                        .await
                        .unwrap();
                }

                assert!(matches!(response, PamAuthResponse::Success));
                assert!(
                    matches!(session, AuthSession::Success(ref spn) if spn == "testuser@example.com")
                );
                assert_eq!(resolver.get_cached_usertokens().await.unwrap().len(), 1);
                assert_eq!(
                    resolver
                        .check_cache_userpassword(test_token().uuid, "secret")
                        .await
                        .unwrap(),
                    !cache_fails
                );
                assert!(!resolver
                    .check_cache_userpassword(test_token().uuid, "old-secret")
                    .await
                    .unwrap());
            }
        }
    }

    #[tokio::test]
    async fn authentication_without_password_update_preserves_verifier() {
        let resolver = setup_resolver().await;
        resolver
            .set_cache_userpassword(test_token().uuid, "old-secret")
            .await
            .unwrap();
        let mut token = test_token();
        resolver
            .set_cache_usertoken(&mut token, false)
            .await
            .unwrap();
        assert!(resolver
            .check_cache_userpassword(token.uuid, "old-secret")
            .await
            .unwrap());

        resolver.client.user_get_error.store(5, Ordering::Release);
        let (_shutdown_tx, shutdown_rx) = broadcast::channel(1);
        let (mut session, _) = resolver
            .pam_account_authenticate_init(
                "testuser@example.com",
                "sshd",
                false,
                false,
                shutdown_rx,
            )
            .await
            .unwrap();
        let response = resolver
            .pam_account_authenticate_step(
                &mut session,
                PamAuthRequest::Password {
                    cred: "secret".to_string(),
                },
            )
            .await
            .unwrap();
        assert!(matches!(response, PamAuthResponse::Success));
        assert!(resolver
            .check_cache_userpassword(token.uuid, "old-secret")
            .await
            .unwrap());
    }

    #[tokio::test]
    async fn failed_password_invalidation_rejects_login_and_rolls_back_token() {
        let (resolver, conn) = setup_sql_resolver().await;
        let token = test_token();
        resolver
            .set_cache_userpassword(token.uuid, "old-secret")
            .await
            .unwrap();
        conn.execute_batch(
            "CREATE TRIGGER fail_password_invalidation BEFORE UPDATE OF password ON account_t
             WHEN NEW.password IS NULL
             BEGIN SELECT RAISE(ABORT, 'injected password invalidation failure'); END;",
        )
        .unwrap();
        resolver.client.user_get_error.store(3, Ordering::Release);
        let (_shutdown_tx, shutdown_rx) = broadcast::channel(1);
        let (mut session, _) = resolver
            .pam_account_authenticate_init(
                "testuser@example.com",
                "sshd",
                false,
                false,
                shutdown_rx,
            )
            .await
            .unwrap();
        assert!(resolver
            .pam_account_authenticate_step(
                &mut session,
                PamAuthRequest::Password {
                    cred: "secret".to_string(),
                },
            )
            .await
            .is_err());
        assert!(!matches!(session, AuthSession::Success(_)));
        assert!(resolver.password_cache_generations.lock().await.is_empty());
        let mut dbtxn = resolver.db.write().await;
        let (cached, expiry) = dbtxn.get_account(&Id::Name(token.spn)).unwrap().unwrap();
        assert_eq!(expiry, 0);
        assert!(cached.shell.is_none());
        dbtxn.commit().unwrap();
        // Failed invalidation leaves the old transaction state intact, but
        // must never report this online authentication as successful.
        assert!(resolver
            .check_cache_userpassword(token.uuid, "old-secret")
            .await
            .unwrap());
    }

    #[tokio::test]
    async fn failed_password_replacement_does_not_erase_newer_verifier() {
        let (resolver, conn) = setup_sql_resolver().await;
        let mut token = test_token();
        resolver
            .set_cache_userpassword(token.uuid, "old-secret")
            .await
            .unwrap();
        resolver
            .set_cache_usertoken(&mut token, true)
            .await
            .unwrap();
        // Another authentication can save its verifier between this login's
        // invalidation and its replacement attempt.
        resolver
            .set_cache_userpassword(token.uuid, "newer-secret")
            .await
            .unwrap();
        conn.execute_batch(
            "CREATE TRIGGER fail_password_cache BEFORE UPDATE OF password ON account_t
             WHEN NEW.password IS NOT NULL
             BEGIN SELECT RAISE(ABORT, 'injected password cache failure'); END;",
        )
        .unwrap();
        assert!(resolver
            .set_cache_userpassword(token.uuid, "secret")
            .await
            .is_err());
        assert!(resolver
            .check_cache_userpassword(token.uuid, "newer-secret")
            .await
            .unwrap());
        assert!(!resolver
            .check_cache_userpassword(token.uuid, "old-secret")
            .await
            .unwrap());
    }

    #[tokio::test]
    async fn older_pin_setup_cannot_replace_newer_password_generation() {
        for (newer_cache_fails, older_cache_fails) in [(false, false), (true, false), (false, true)]
        {
            let (resolver, conn) = setup_sql_resolver().await;
            resolver.client.user_get_error.store(4, Ordering::Release);
            let (_shutdown_tx, shutdown_rx) = broadcast::channel(1);
            // Start B first: credential acceptance, not session creation,
            // determines which password update is newer.
            let (mut newer, _) = resolver
                .pam_account_authenticate_init(
                    "testuser@example.com",
                    "sshd",
                    false,
                    false,
                    shutdown_rx.resubscribe(),
                )
                .await
                .unwrap();
            let (mut older, _) = resolver
                .pam_account_authenticate_init(
                    "testuser@example.com",
                    "sshd",
                    false,
                    false,
                    shutdown_rx,
                )
                .await
                .unwrap();
            // An initial lookup may have a synthetic UUID. Use only the final
            // authenticated UUID when comparing password generations.
            if let AuthSession::InProgress {
                token: Some(token), ..
            } = &mut older
            {
                token.uuid = uuid::Uuid::new_v4();
            }
            let response = resolver
                .pam_account_authenticate_step(
                    &mut older,
                    PamAuthRequest::Password {
                        cred: "old-secret".to_string(),
                    },
                )
                .await
                .unwrap();
            assert!(matches!(response, PamAuthResponse::SetupPin { .. }));

            let fail_replacement =
                "CREATE TRIGGER fail_password_cache BEFORE UPDATE OF password ON account_t
                 WHEN NEW.password IS NOT NULL
                 BEGIN SELECT RAISE(ABORT, 'injected password cache failure'); END;";
            if newer_cache_fails {
                conn.execute_batch(fail_replacement).unwrap();
            }
            let mut newer_token = test_token();
            newer_token.displayname = "Newer profile".to_string();
            newer_token.groups.clear();
            *resolver.client.auth_token.write().unwrap() = newer_token.clone();
            resolver.client.user_get_error.store(3, Ordering::Release);
            let response = resolver
                .pam_account_authenticate_step(
                    &mut newer,
                    PamAuthRequest::Password {
                        cred: "new-secret".to_string(),
                    },
                )
                .await
                .unwrap();
            assert!(matches!(response, PamAuthResponse::Success));
            if newer_cache_fails {
                // A durable invalidation must also supersede older sessions
                // when its optional replacement failed.
                conn.execute_batch("DROP TRIGGER fail_password_cache")
                    .unwrap();
            } else if older_cache_fails {
                conn.execute_batch(fail_replacement).unwrap();
            }

            *resolver.client.auth_token.write().unwrap() = test_token();
            resolver.client.user_get_error.store(4, Ordering::Release);
            let response = resolver
                .pam_account_authenticate_step(
                    &mut older,
                    PamAuthRequest::SetupPin {
                        pin: "123456".to_string(),
                    },
                )
                .await
                .unwrap();
            assert!(matches!(response, PamAuthResponse::Success));
            let cached = resolver.get_cached_usertokens().await.unwrap();
            assert_eq!(cached.len(), 1);
            assert_eq!(cached[0].displayname, newer_token.displayname);
            assert!(cached[0].groups.is_empty());
            assert!(!resolver
                .check_cache_userpassword(test_token().uuid, "old-secret")
                .await
                .unwrap());
            assert_eq!(
                resolver
                    .check_cache_userpassword(test_token().uuid, "new-secret")
                    .await
                    .unwrap(),
                !newer_cache_fails
            );
        }
    }

    async fn stage_test_pin(
        resolver: &Resolver<OfflineFallbackProvider>,
        cache_password: bool,
    ) -> AuthSession {
        stage_test_local_auth(resolver, cache_password, false).await
    }

    async fn stage_test_local_auth(
        resolver: &Resolver<OfflineFallbackProvider>,
        cache_password: bool,
        direct_totp: bool,
    ) -> AuthSession {
        resolver
            .client
            .user_get_error
            .store(if cache_password { 4 } else { 7 }, Ordering::Release);
        let (_shutdown_tx, shutdown_rx) = broadcast::channel(1);
        let (mut session, _) = resolver
            .pam_account_authenticate_init(
                "testuser@example.com",
                "sshd",
                false,
                false,
                shutdown_rx,
            )
            .await
            .unwrap();
        let response = resolver
            .pam_account_authenticate_step(
                &mut session,
                PamAuthRequest::Password {
                    cred: if direct_totp {
                        "direct-totp".to_string()
                    } else {
                        "staged-secret".to_string()
                    },
                },
            )
            .await
            .unwrap();
        if direct_totp {
            assert!(matches!(response, PamAuthResponse::HelloTOTP { .. }));
        } else {
            assert!(matches!(response, PamAuthResponse::SetupPin { .. }));
        }
        session
    }

    async fn complete_test_auth(
        resolver: &Resolver<OfflineFallbackProvider>,
        cache_password: bool,
    ) {
        resolver
            .client
            .user_get_error
            .store(if cache_password { 3 } else { 5 }, Ordering::Release);
        let (_shutdown_tx, shutdown_rx) = broadcast::channel(1);
        let (mut session, _) = resolver
            .pam_account_authenticate_init(
                "testuser@example.com",
                "sshd",
                false,
                false,
                shutdown_rx,
            )
            .await
            .unwrap();
        let response = resolver
            .pam_account_authenticate_step(
                &mut session,
                PamAuthRequest::Password {
                    cred: "new-secret".to_string(),
                },
            )
            .await
            .unwrap();
        assert!(matches!(response, PamAuthResponse::Success));
        assert!(matches!(session, AuthSession::Success(_)));
    }

    #[tokio::test]
    async fn stale_pin_cannot_restore_identity_replaced_through_any_cache_alias() {
        for collision in ["all", "name", "spn", "gid", "tenant"] {
            for replacement in ["password", "failed-password", "passwordless", "refresh"] {
                let (resolver, conn) = setup_sql_resolver().await;
                resolver
                    .set_cache_userpassword(test_token().uuid, "old-secret")
                    .await
                    .unwrap();
                let mut older = stage_test_pin(&resolver, true).await;
                let mut newer_token = test_token();
                newer_token.uuid = uuid::Uuid::new_v4();
                newer_token.name = "replacement".to_string();
                newer_token.spn = "replacement@example.com".to_string();
                newer_token.gidnumber += 1;
                newer_token.displayname = "Replacement identity".to_string();
                newer_token.groups.clear();
                match collision {
                    "all" => {
                        newer_token.name = test_token().name;
                        newer_token.spn = test_token().spn;
                        newer_token.gidnumber = test_token().gidnumber;
                    }
                    "name" => newer_token.name = test_token().name,
                    "spn" => newer_token.spn = test_token().spn,
                    "gid" => newer_token.gidnumber = test_token().gidnumber,
                    "tenant" => {
                        newer_token.uuid = test_token().uuid;
                        newer_token.tenant_id = Some(uuid::Uuid::new_v4());
                    }
                    _ => unreachable!(),
                }
                *resolver.client.auth_token.write().unwrap() = newer_token.clone();
                if replacement == "failed-password" {
                    conn.execute_batch(
                        "CREATE TRIGGER fail_password_cache BEFORE UPDATE OF password ON account_t
                         WHEN NEW.password IS NOT NULL
                         BEGIN SELECT RAISE(ABORT, 'injected password cache failure'); END;",
                    )
                    .unwrap();
                }
                if replacement == "refresh" {
                    resolver.client.user_get_error.store(6, Ordering::Release);
                    let refreshed = resolver
                        .refresh_usertoken(&Id::Name(test_token().spn), Some(test_token()))
                        .await
                        .unwrap()
                        .unwrap();
                    assert_eq!(refreshed.uuid, newer_token.uuid);
                } else {
                    complete_test_auth(&resolver, replacement != "passwordless").await;
                }
                if replacement == "failed-password" {
                    conn.execute_batch("DROP TRIGGER fail_password_cache")
                        .unwrap();
                }

                *resolver.client.auth_token.write().unwrap() = test_token();
                resolver.client.user_get_error.store(4, Ordering::Release);
                let response = resolver
                    .pam_account_authenticate_step(
                        &mut older,
                        PamAuthRequest::SetupPin {
                            pin: "123456".to_string(),
                        },
                    )
                    .await
                    .unwrap();
                assert!(matches!(response, PamAuthResponse::Denied(_)));
                assert!(matches!(older, AuthSession::Denied));
                let cached = resolver.get_cached_usertokens().await.unwrap();
                assert_eq!(cached.len(), 1);
                assert_eq!(cached[0].uuid, newer_token.uuid);
                assert_eq!(cached[0].tenant_id, newer_token.tenant_id);
                assert_eq!(cached[0].displayname, newer_token.displayname);
                assert!(cached[0].groups.is_empty());
                for password in ["old-secret", "staged-secret"] {
                    assert!(!resolver
                        .check_cache_userpassword(newer_token.uuid, password)
                        .await
                        .unwrap());
                }
                assert_eq!(
                    resolver
                        .check_cache_userpassword(newer_token.uuid, "new-secret")
                        .await
                        .unwrap(),
                    replacement == "password"
                );
            }
        }
    }

    #[tokio::test]
    async fn passwordless_pin_setup_keeps_its_original_identity_generation() {
        let resolver = setup_resolver().await;
        let mut older = stage_test_pin(&resolver, false).await;
        let mut replacement = test_token();
        replacement.uuid = uuid::Uuid::new_v4();
        *resolver.client.auth_token.write().unwrap() = replacement.clone();
        complete_test_auth(&resolver, false).await;
        *resolver.client.auth_token.write().unwrap() = test_token();
        resolver.client.user_get_error.store(7, Ordering::Release);
        let retry = resolver
            .pam_account_authenticate_step(
                &mut older,
                PamAuthRequest::SetupPin {
                    pin: "retry".to_string(),
                },
            )
            .await
            .unwrap();
        assert!(matches!(retry, PamAuthResponse::SetupPin { .. }));
        let response = resolver
            .pam_account_authenticate_step(
                &mut older,
                PamAuthRequest::SetupPin {
                    pin: "123456".to_string(),
                },
            )
            .await
            .unwrap();
        assert!(matches!(response, PamAuthResponse::Denied(_)));
        assert!(matches!(older, AuthSession::Denied));
        let cached = resolver.get_cached_usertokens().await.unwrap();
        assert_eq!(cached.len(), 1);
        assert_eq!(cached[0].uuid, replacement.uuid);
    }

    #[tokio::test]
    async fn local_totp_completion_cannot_refresh_a_stale_identity_generation() {
        for direct_totp in [false, true] {
            for final_password_update in [false, true] {
                let resolver = setup_resolver().await;
                let mut older = stage_test_local_auth(&resolver, false, direct_totp).await;
                if !direct_totp {
                    let response = resolver
                        .pam_account_authenticate_step(
                            &mut older,
                            PamAuthRequest::SetupPin {
                                pin: "totp".to_string(),
                            },
                        )
                        .await
                        .unwrap();
                    assert!(matches!(response, PamAuthResponse::HelloTOTP { .. }));
                }
                let mut replacement = test_token();
                replacement.uuid = uuid::Uuid::new_v4();
                *resolver.client.auth_token.write().unwrap() = replacement.clone();
                complete_test_auth(&resolver, true).await;
                *resolver.client.auth_token.write().unwrap() = test_token();
                resolver.client.user_get_error.store(7, Ordering::Release);
                let response = resolver
                    .pam_account_authenticate_step(
                        &mut older,
                        PamAuthRequest::HelloTOTP {
                            cred: if final_password_update {
                                "cache-password".to_string()
                            } else {
                                "123456".to_string()
                            },
                        },
                    )
                    .await
                    .unwrap();
                assert!(matches!(response, PamAuthResponse::Denied(_)));
                assert!(matches!(older, AuthSession::Denied));
                let cached = resolver.get_cached_usertokens().await.unwrap();
                assert_eq!(cached.len(), 1);
                assert_eq!(cached[0].uuid, replacement.uuid);
                assert!(resolver
                    .check_cache_userpassword(replacement.uuid, "new-secret")
                    .await
                    .unwrap());
                assert!(!resolver
                    .check_cache_userpassword(replacement.uuid, "late-secret")
                    .await
                    .unwrap());
            }
        }
    }

    #[tokio::test]
    async fn same_identity_refresh_preserves_claims_without_suppressing_password_invalidation() {
        for refresh in [false, true] {
            let resolver = setup_resolver().await;
            resolver
                .set_cache_userpassword(test_token().uuid, "old-secret")
                .await
                .unwrap();
            let mut session = stage_test_pin(&resolver, true).await;
            let mut refreshed = test_token();
            refreshed.displayname = "Refreshed claims".to_string();
            refreshed.groups.clear();
            *resolver.client.auth_token.write().unwrap() = refreshed.clone();
            if refresh {
                resolver.client.user_get_error.store(6, Ordering::Release);
                resolver
                    .refresh_usertoken(&Id::Name(test_token().spn), Some(test_token()))
                    .await
                    .unwrap();
            } else {
                complete_test_auth(&resolver, false).await;
            }
            assert!(resolver
                .check_cache_userpassword(test_token().uuid, "old-secret")
                .await
                .unwrap());
            *resolver.client.auth_token.write().unwrap() = test_token();
            resolver.client.user_get_error.store(4, Ordering::Release);
            let response = resolver
                .pam_account_authenticate_step(
                    &mut session,
                    PamAuthRequest::SetupPin {
                        pin: "123456".to_string(),
                    },
                )
                .await
                .unwrap();
            assert!(matches!(response, PamAuthResponse::Success));
            let cached = resolver.get_cached_usertokens().await.unwrap();
            assert_eq!(cached[0].displayname, refreshed.displayname);
            assert!(cached[0].groups.is_empty());
            assert!(!resolver
                .check_cache_userpassword(test_token().uuid, "old-secret")
                .await
                .unwrap());
            assert!(resolver
                .check_cache_userpassword(test_token().uuid, "staged-secret")
                .await
                .unwrap());
        }
    }

    #[tokio::test]
    async fn stale_passwordless_cache_writer_cannot_replace_newer_identity() {
        let resolver = setup_resolver().await;
        let mut newer = test_token();
        newer.uuid = uuid::Uuid::new_v4();
        assert_eq!(
            resolver
                .set_cache_usertoken_guarded(&mut newer, 2, None)
                .await
                .unwrap(),
            CacheUpdateResult::Updated
        );
        assert_eq!(
            resolver
                .set_cache_usertoken_guarded(&mut test_token(), 1, None)
                .await
                .unwrap(),
            CacheUpdateResult::IdentityChanged
        );
        assert_eq!(
            resolver.get_cached_usertokens().await.unwrap()[0].uuid,
            newer.uuid
        );
    }

    #[tokio::test]
    async fn cache_generation_guard_does_not_block_unrelated_identities() {
        let resolver = setup_resolver().await;
        let mut unrelated = test_token();
        unrelated.uuid = uuid::Uuid::new_v4();
        unrelated.name = "unrelated".to_string();
        unrelated.spn = "unrelated@example.com".to_string();
        unrelated.gidnumber += 1;
        assert_eq!(
            resolver
                .set_cache_usertoken_guarded(&mut unrelated, 2, Some("other-secret"))
                .await
                .unwrap(),
            CacheUpdateResult::Updated
        );
        assert_eq!(
            resolver
                .set_cache_usertoken_guarded(&mut test_token(), 1, Some("original-secret"))
                .await
                .unwrap(),
            CacheUpdateResult::Updated
        );
        assert_eq!(resolver.get_cached_usertokens().await.unwrap().len(), 2);
        assert!(resolver
            .check_cache_userpassword(unrelated.uuid, "other-secret")
            .await
            .unwrap());
        assert!(resolver
            .check_cache_userpassword(test_token().uuid, "original-secret")
            .await
            .unwrap());
    }

    #[tokio::test]
    async fn password_helpers_wait_for_hsm_before_acquiring_database() {
        let resolver = setup_resolver().await;
        for write in [true, false] {
            let hsm_guard = resolver.hsm.lock().await;
            let password_operation = async {
                if write {
                    resolver
                        .set_cache_userpassword(test_token().uuid, "secret")
                        .await
                        .unwrap();
                } else {
                    assert!(resolver
                        .check_cache_userpassword(test_token().uuid, "secret")
                        .await
                        .unwrap());
                }
            };
            tokio::pin!(password_operation);
            tokio::select! {
                biased;
                _ = &mut password_operation => panic!("password operation bypassed the HSM lock"),
                _ = tokio::task::yield_now() => {}
            }
            // The provider's HSM -> DB order must remain possible while the
            // password operation is waiting, rather than form a lock cycle.
            let dbtxn = tokio::time::timeout(Duration::from_secs(1), resolver.db.write())
                .await
                .expect("password operation held the database while waiting for the HSM");
            dbtxn.commit().unwrap();
            drop(hsm_guard);
            password_operation.await;
        }
    }

    #[tokio::test]
    async fn enumeration_and_reconciliation_ignore_expired_accounts() {
        let resolver = setup_resolver().await;
        let token = test_token();
        resolver
            .set_cache_userpassword(token.uuid, "secret")
            .await
            .unwrap();
        assert!(resolver.get_nssaccounts().await.unwrap().is_empty());
        assert!(resolver
            .get_unexpired_nssaccounts()
            .await
            .unwrap()
            .is_empty());

        let mut fresh_token = token.clone();
        fresh_token.uuid = uuid::Uuid::new_v4();
        fresh_token.name = "freshuser".to_string();
        fresh_token.spn = "freshuser@example.com".to_string();
        fresh_token.gidnumber += 1;
        resolver
            .set_cache_usertoken(&mut fresh_token, false)
            .await
            .unwrap();
        for users in [
            resolver.get_nssaccounts().await.unwrap(),
            resolver.get_unexpired_nssaccounts().await.unwrap(),
        ] {
            assert_eq!(users.len(), 1);
            assert_eq!(users[0].name, fresh_token.name);
            assert!(users[0].cacheable);
        }
        // Enumeration filters expired accounts without removing their offline
        // identity or password verifier from the database.
        assert_eq!(resolver.get_cached_usertokens().await.unwrap().len(), 2);
        let mut dbtxn = resolver.db.write().await;
        let (_, expiry) = dbtxn.get_account(&Id::Name(token.spn)).unwrap().unwrap();
        assert_eq!(expiry, 0);
        dbtxn.commit().unwrap();
        assert!(resolver
            .check_cache_userpassword(token.uuid, "secret")
            .await
            .unwrap());
    }

    #[tokio::test]
    async fn reconciliation_refresh_requires_an_unexpired_cached_identity() {
        let resolver = setup_resolver().await;
        let token = test_token();
        // Even a trusted refresh must not revive an ineligible account for
        // reconciliation, or discover an account that was not already cached.
        resolver.client.user_get_error.store(6, Ordering::Release);
        assert!(resolver
            .refresh_cached_usertoken(&token.name)
            .await
            .unwrap()
            .is_none());
        let (expired, cached) = resolver
            .get_cached_usertoken(&Id::Name(token.name.clone()))
            .await
            .unwrap();
        assert!(expired);
        assert_eq!(cached.unwrap().uuid, token.uuid);

        resolver.delete_cache_usertoken(token.uuid).await.unwrap();
        assert!(resolver
            .refresh_cached_usertoken(&token.name)
            .await
            .unwrap()
            .is_none());
        resolver.set_nxcache(&Id::Name(token.name.clone())).await;
        assert!(resolver
            .refresh_cached_usertoken(&token.name)
            .await
            .unwrap()
            .is_none());
        assert_eq!(resolver.client.user_get_calls.load(Ordering::Acquire), 0);
    }

    #[tokio::test]
    async fn reconciliation_refresh_rejects_lookup_only_and_replacement_identities() {
        let token = test_token();
        let other_uuid = uuid::Uuid::new_v4();
        let other_tenant = Some(uuid::Uuid::new_v4());
        for (mode, cached_uuid, cached_tenant) in [
            (3, token.uuid, token.tenant_id),
            (3, other_uuid, token.tenant_id),
            (3, token.uuid, other_tenant),
            (3, token.uuid, None),
            (6, other_uuid, token.tenant_id),
            (6, token.uuid, other_tenant),
            (6, token.uuid, None),
        ] {
            let resolver = setup_resolver().await;
            resolver.delete_cache_usertoken(token.uuid).await.unwrap();
            let mut cached = token.clone();
            cached.uuid = cached_uuid;
            cached.tenant_id = cached_tenant;
            cached.groups.clear();
            resolver
                .set_cache_usertoken(&mut cached, false)
                .await
                .unwrap();
            resolver
                .client
                .user_get_error
                .store(mode, Ordering::Release);

            let accounts = resolver.get_unexpired_nssaccounts().await.unwrap();
            assert_eq!(accounts.len(), 1);
            // Both provider modes return the same name and new group claims.
            // Lookup-only claims remain ineligible even for the same UUID;
            // trusted updates must still match both the UUID and tenant.
            assert!(resolver
                .refresh_cached_usertoken(&accounts[0].name)
                .await
                .unwrap()
                .is_none());
            assert_eq!(resolver.client.user_get_calls.load(Ordering::Acquire), 1);
            if mode == 3 {
                let (expired, cached) = resolver
                    .get_cached_usertoken(&Id::Name(token.name.clone()))
                    .await
                    .unwrap();
                let cached = cached.unwrap();
                assert!(!expired);
                assert_eq!(cached.uuid, cached_uuid);
                assert_eq!(cached.tenant_id, cached_tenant);
                assert!(cached.groups.is_empty());
            }
        }
    }

    #[tokio::test]
    async fn reconciliation_refresh_accepts_a_matching_trusted_update() {
        let resolver = setup_resolver().await;
        let mut cached = test_token();
        cached.groups.clear();
        resolver
            .set_cache_usertoken(&mut cached, false)
            .await
            .unwrap();
        resolver.client.user_get_error.store(6, Ordering::Release);

        let refreshed = resolver
            .refresh_cached_usertoken(&cached.name)
            .await
            .unwrap()
            .unwrap();
        assert_eq!(refreshed.uuid, cached.uuid);
        assert_eq!(refreshed.tenant_id, cached.tenant_id);
        assert_eq!(refreshed.groups.len(), 1);
        assert_eq!(refreshed.groups[0].uuid, test_token().groups[0].uuid);
        assert_eq!(resolver.client.user_get_calls.load(Ordering::Acquire), 1);
    }

    #[tokio::test]
    async fn reconciliation_refresh_preserves_unexpired_cached_fallback() {
        let expiry = SystemTime::now()
            .duration_since(SystemTime::UNIX_EPOCH)
            .unwrap()
            .as_secs()
            + 3600;
        for mode in [0, 1, 2] {
            let resolver = setup_resolver_with_expiry(expiry).await;
            let token = test_token();
            resolver
                .client
                .user_get_error
                .store(mode, Ordering::Release);
            let refreshed = resolver
                .refresh_cached_usertoken(&token.name)
                .await
                .unwrap()
                .unwrap();
            assert_eq!(refreshed.uuid, token.uuid);
            assert_eq!(refreshed.tenant_id, token.tenant_id);
            assert_eq!(refreshed.groups[0].uuid, token.groups[0].uuid);
            assert_eq!(resolver.client.user_get_calls.load(Ordering::Acquire), 1);
            let mut dbtxn = resolver.db.write().await;
            let (_, cached_expiry) = dbtxn.get_account(&Id::Name(token.name)).unwrap().unwrap();
            assert_eq!(cached_expiry, expiry);
            dbtxn.commit().unwrap();
        }
    }

    #[tokio::test]
    async fn reconciliation_refresh_rechecks_cached_eligibility_after_wait() {
        let expiry = SystemTime::now()
            .duration_since(SystemTime::UNIX_EPOCH)
            .unwrap()
            .as_secs()
            + 3600;
        for mode in [0, 1, 2] {
            for change in ["expire", "remove", "uuid", "tenant", "claims"] {
                let resolver = setup_resolver_with_expiry(expiry).await;
                let token = test_token();
                resolver
                    .client
                    .user_get_error
                    .store(mode, Ordering::Release);
                // Stop after the initial eligible snapshot, before provider
                // work resumes, without relying on wall-clock sleeps.
                let hsm_guard = resolver.hsm.lock().await;
                let refresh = resolver.refresh_cached_usertoken(&token.name);
                tokio::pin!(refresh);
                tokio::select! {
                    biased;
                    _ = &mut refresh => panic!("refresh bypassed the HSM lock"),
                    _ = tokio::task::yield_now() => {}
                }
                assert_eq!(resolver.client.user_get_calls.load(Ordering::Acquire), 0);
                match change {
                    "expire" => resolver.invalidate().await.unwrap(),
                    "remove" => resolver.delete_cache_usertoken(token.uuid).await.unwrap(),
                    _ => {
                        let mut current = token.clone();
                        current.groups.clear();
                        if change == "uuid" {
                            current.uuid = uuid::Uuid::new_v4();
                        } else if change == "tenant" {
                            current.tenant_id = Some(uuid::Uuid::new_v4());
                        }
                        resolver
                            .set_cache_usertoken(&mut current, false)
                            .await
                            .unwrap();
                    }
                }
                drop(hsm_guard);

                let refreshed = refresh.await.unwrap();
                if change == "claims" {
                    let refreshed = refreshed.unwrap();
                    assert_eq!(refreshed.uuid, token.uuid);
                    assert_eq!(refreshed.tenant_id, token.tenant_id);
                    assert!(refreshed.groups.is_empty());
                } else {
                    assert!(refreshed.is_none());
                }
                assert_eq!(resolver.client.user_get_calls.load(Ordering::Acquire), 1);
            }
        }
    }

    #[tokio::test]
    async fn abandoned_pin_setup_does_not_cache_identity_or_password() {
        let resolver = setup_resolver().await;
        resolver
            .delete_cache_usertoken(test_token().uuid)
            .await
            .unwrap();
        resolver.client.user_get_error.store(4, Ordering::Release);
        let (_shutdown_tx, shutdown_rx) = broadcast::channel(1);
        let (mut session, _) = resolver
            .pam_account_authenticate_init(
                "testuser@example.com",
                "sshd",
                false,
                false,
                shutdown_rx,
            )
            .await
            .unwrap();
        let response = resolver
            .pam_account_authenticate_step(
                &mut session,
                PamAuthRequest::Password {
                    cred: "secret".to_string(),
                },
            )
            .await
            .unwrap();
        assert!(matches!(response, PamAuthResponse::SetupPin { .. }));
        drop(session);
        assert!(resolver.get_cached_usertokens().await.unwrap().is_empty());
        assert!(!resolver
            .check_cache_userpassword(test_token().uuid, "secret")
            .await
            .unwrap());
    }

    #[tokio::test]
    async fn refresh_usertoken_logs_not_found_at_debug_and_other_errors_at_error() {
        use std::sync::{Arc, Mutex};
        use tracing::instrument::WithSubscriber;
        use tracing::{Event, Level, Subscriber};
        use tracing_subscriber::layer::{Context, SubscriberExt};
        use tracing_subscriber::Layer;

        struct Events(Arc<Mutex<Vec<Level>>>);
        impl<S: Subscriber> Layer<S> for Events {
            fn on_event(&self, event: &Event<'_>, _ctx: Context<'_, S>) {
                if event.metadata().target() == "himmelblau_unix_common::resolver" {
                    self.0
                        .lock()
                        .expect("events lock poisoned")
                        .push(*event.metadata().level());
                }
            }
        }

        let resolver = setup_resolver().await;
        let id = Id::Name("testuser@example.com".to_string());
        for (error, level) in [(1, Level::DEBUG), (2, Level::ERROR)] {
            resolver
                .client
                .user_get_error
                .store(error, Ordering::Release);
            for token in [None, Some(test_token())] {
                let expected_spn = token.as_ref().map(|token| token.spn.clone());
                let events = Arc::new(Mutex::new(Vec::new()));
                let subscriber = tracing_subscriber::registry().with(Events(events.clone()));
                let result = resolver
                    .refresh_usertoken(&id, token)
                    .with_subscriber(subscriber)
                    .await
                    .expect("refresh failed");
                assert_eq!(result.map(|token| token.spn), expected_spn);
                assert_eq!(*events.lock().expect("events lock poisoned"), vec![level]);
            }
        }
    }

    #[tokio::test]
    async fn initgroups_named_omits_gid_with_no_nss_name() {
        let unnamed = GroupToken {
            name: "unnamed".to_string(),
            spn: "unnamed".to_string(),
            uuid: uuid::uuid!("aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa"),
            gidnumber: 299568524,
        };
        let named_resolver =
            setup_resolver_with(0, InitgroupsMode::Named, vec![unnamed.clone()]).await;
        let named = named_resolver
            .get_initgroups("testuser")
            .await
            .expect("named initgroups")
            .expect("cached user");
        assert_eq!(named, vec![2100]);

        let full_resolver = setup_resolver_with(0, InitgroupsMode::Full, vec![unnamed]).await;
        let full = full_resolver
            .get_initgroups("testuser")
            .await
            .expect("full initgroups")
            .expect("cached user");
        assert_eq!(full, vec![2100, 299568524]);
    }

    #[tokio::test]
    async fn online_auth_init_offline_fallback_does_not_reenter_db_lock() {
        let resolver = setup_resolver().await;
        let (_shutdown_tx, shutdown_rx) = broadcast::channel(1);

        let result = tokio::time::timeout(
            Duration::from_secs(5),
            resolver.pam_account_authenticate_init(
                "testuser@example.com",
                "gdm-password",
                false,
                false,
                shutdown_rx,
            ),
        )
        .await
        .expect("auth init deadlocked waiting for the db lock")
        .expect("auth init failed");

        assert!(matches!(result.0, AuthSession::InProgress { .. }));
        assert!(matches!(result.1, PamAuthResponse::Pin));
    }

    #[tokio::test]
    async fn try_unseal_refreshes_only_an_expired_user_token() {
        let resolver = setup_resolver().await;

        assert!(resolver
            .pam_try_unseal("testuser@example.com", "123456")
            .await
            .expect("try_unseal failed"));
        assert_eq!(resolver.client.try_unseal_calls.load(Ordering::Acquire), 1);
        assert!(resolver.client.try_unseal_online.load(Ordering::Acquire));
        assert_eq!(resolver.client.cache_state_calls.load(Ordering::Acquire), 1);
        assert_eq!(
            resolver.client.check_online_calls.load(Ordering::Acquire),
            0
        );
        assert_eq!(resolver.client.user_get_calls.load(Ordering::Acquire), 1);
        let (_expired, cached) = resolver
            .get_cached_usertoken(&Id::Name("testuser@example.com".to_string()))
            .await
            .expect("failed to reload cached user");
        let cached = cached.expect("cached user was removed");
        assert_eq!(cached.groups.len(), 1);
        assert_eq!(cached.groups[0].spn, "linux-users");
        assert_eq!(
            resolver
                .pam_account_allowed("testuser@example.com")
                .await
                .expect("allow-group check failed"),
            Some(true)
        );
    }

    #[tokio::test]
    async fn try_unseal_skips_refresh_for_a_valid_user_token() {
        let expiry = SystemTime::now()
            .duration_since(SystemTime::UNIX_EPOCH)
            .expect("system clock predates UNIX epoch")
            .as_secs()
            + 3600;
        let resolver = setup_resolver_with_expiry(expiry).await;

        assert!(resolver
            .pam_try_unseal("testuser@example.com", "123456")
            .await
            .expect("try_unseal failed"));
        assert_eq!(resolver.client.try_unseal_calls.load(Ordering::Acquire), 1);
        assert!(resolver.client.try_unseal_online.load(Ordering::Acquire));
        assert_eq!(resolver.client.cache_state_calls.load(Ordering::Acquire), 1);
        assert_eq!(
            resolver.client.check_online_calls.load(Ordering::Acquire),
            0
        );
        assert_eq!(resolver.client.user_get_calls.load(Ordering::Acquire), 0);
    }

    #[tokio::test]
    async fn try_unseal_passes_offline_state_to_provider() {
        let resolver = setup_resolver().await;
        resolver
            .client
            .set_cache_state(CacheState::OfflineNextCheck(
                SystemTime::now() + Duration::from_secs(60),
            ));

        assert!(resolver
            .pam_try_unseal("testuser@example.com", "123456")
            .await
            .expect("try_unseal failed"));
        assert_eq!(resolver.client.try_unseal_calls.load(Ordering::Acquire), 1);
        assert!(!resolver.client.try_unseal_online.load(Ordering::Acquire));
        assert_eq!(resolver.client.cache_state_calls.load(Ordering::Acquire), 1);
        assert_eq!(
            resolver.client.check_online_calls.load(Ordering::Acquire),
            0
        );
        assert_eq!(resolver.client.user_get_calls.load(Ordering::Acquire), 0);
    }

    #[tokio::test]
    async fn try_unseal_does_not_probe_or_refresh_when_offline() {
        let resolver = setup_resolver().await;
        resolver.client.set_cache_state(CacheState::Offline);

        assert!(resolver
            .pam_try_unseal("testuser@example.com", "123456")
            .await
            .expect("try_unseal failed"));
        assert_eq!(resolver.client.try_unseal_calls.load(Ordering::Acquire), 1);
        assert!(!resolver.client.try_unseal_online.load(Ordering::Acquire));
        assert_eq!(resolver.client.cache_state_calls.load(Ordering::Acquire), 1);
        assert_eq!(
            resolver.client.check_online_calls.load(Ordering::Acquire),
            0
        );
        assert_eq!(resolver.client.user_get_calls.load(Ordering::Acquire), 0);
    }

    #[tokio::test]
    async fn try_unseal_probes_and_refreshes_when_retry_is_due() {
        let resolver = setup_resolver().await;
        resolver
            .client
            .set_cache_state(CacheState::OfflineNextCheck(SystemTime::UNIX_EPOCH));

        assert!(resolver
            .pam_try_unseal("testuser@example.com", "123456")
            .await
            .expect("try_unseal failed"));
        assert_eq!(resolver.client.try_unseal_calls.load(Ordering::Acquire), 1);
        assert!(resolver.client.try_unseal_online.load(Ordering::Acquire));
        assert_eq!(resolver.client.cache_state_calls.load(Ordering::Acquire), 1);
        assert_eq!(
            resolver.client.check_online_calls.load(Ordering::Acquire),
            1
        );
        assert_eq!(resolver.client.user_get_calls.load(Ordering::Acquire), 1);
    }

    #[tokio::test]
    async fn try_unseal_does_not_refresh_when_due_probe_fails() {
        let resolver = setup_resolver().await;
        resolver
            .client
            .set_cache_state(CacheState::OfflineNextCheck(SystemTime::UNIX_EPOCH));
        resolver
            .client
            .check_online_result
            .store(false, Ordering::Release);

        assert!(resolver
            .pam_try_unseal("testuser@example.com", "123456")
            .await
            .expect("try_unseal failed"));
        assert_eq!(resolver.client.try_unseal_calls.load(Ordering::Acquire), 1);
        assert!(!resolver.client.try_unseal_online.load(Ordering::Acquire));
        assert_eq!(resolver.client.cache_state_calls.load(Ordering::Acquire), 1);
        assert_eq!(
            resolver.client.check_online_calls.load(Ordering::Acquire),
            1
        );
        assert_eq!(resolver.client.user_get_calls.load(Ordering::Acquire), 0);
    }

    #[tokio::test]
    async fn hello_password_reauth_cannot_fall_back_to_offline_auth() {
        let resolver = setup_resolver().await;
        resolver
            .set_cache_userpassword(test_token().uuid, "cached-password")
            .await
            .expect("failed to seed cached password");
        resolver.client.set_cache_state(CacheState::Offline);
        let (_shutdown_tx, shutdown_rx) = broadcast::channel(1);
        let mut auth_session = AuthSession::InProgress {
            account_id: "testuser@example.com".to_string(),
            service: "gdm-password".to_string(),
            id: Id::Name("testuser@example.com".to_string()),
            token: Some(Box::new(test_token())),
            pending_password: None,
            cache_generation: 0,
            identity_staged: false,
            online_at_init: true,
            cred_handler: AuthCredHandler::ReauthPassword {
                reauth_hello_pin: "123456".to_string().into(),
            },
            shutdown_rx,
            no_hello_pin: false,
            force_reauth: false,
        };

        let result = resolver
            .pam_account_authenticate_step(
                &mut auth_session,
                PamAuthRequest::Password {
                    cred: "cached-password".to_string(),
                },
            )
            .await;

        assert!(result.is_err());
    }
}

impl<I> Resolver<I>
where
    I: IdProvider + Sync,
{
    #[allow(clippy::too_many_arguments)]
    pub async fn new(
        db: Db,
        client: I,
        hsm: BoxedDynTpm,
        machine_key: MachineKey,
        // cache timeout
        timeout_seconds: u64,
        pam_allow_groups: Vec<String>,
        oidc_auth: bool,
        default_shell: String,
        home_prefix: String,
        home_attr: HomeAttr,
        home_alias: Option<HomeAttr>,
        uid_attr_map: UidAttr,
        gid_attr_map: UidAttr,
        initgroups_mode: InitgroupsMode,
        allow_id_overrides: Vec<String>,
    ) -> Result<Self, ()> {
        let hsm = Mutex::new(hsm);
        let mut hsm_lock = hsm.lock().await;

        // Setup our internal keys
        let mut dbtxn = db.write().await;

        let loadable_hmac_key = match dbtxn.get_hsm_hmac_key() {
            Ok(Some(hmk)) => hmk,
            Ok(None) => {
                // generate a new key.
                let loadable_hmac_key = hsm_lock.hmac_s256_create(&machine_key).map_err(|err| {
                    error!(?err, "Unable to create hmac key");
                })?;

                dbtxn
                    .insert_hsm_hmac_key(&loadable_hmac_key)
                    .map_err(|err| {
                        error!(?err, "Unable to persist hmac key");
                    })?;

                loadable_hmac_key
            }
            Err(err) => {
                error!(?err, "Unable to retrieve loadable hmac key from db");
                return Err(());
            }
        };

        let hmac_key = hsm_lock
            .hmac_s256_load(&machine_key, &loadable_hmac_key)
            .map_err(|err| {
                error!(?err, "Unable to load hmac key");
            })?;

        // Ask the client what keys it wants the HSM to configure.
        // make a key store
        // let mut ks = KeyStore::new(&mut dbtxn);

        let result = client
            .configure_hsm_keys(&mut dbtxn, hsm_lock.deref_mut(), &machine_key)
            .await;

        // drop(ks);
        drop(hsm_lock);

        result.map_err(|err| {
            error!(?err, "Client was unable to configure hsm keys");
        })?;

        dbtxn.commit().map_err(|_| ())?;

        if pam_allow_groups.is_empty() {
            warn!("pam_allow_groups config is not configured, all users will be authorized!");
        }

        // We assume we are offline at start up, and we mark the next "online check" as
        // being valid from "now".
        Ok(Resolver {
            db,
            hsm,
            machine_key,
            hmac_key,
            client,
            timeout_seconds,
            pam_allow_groups: pam_allow_groups.into_iter().collect(),
            oidc_auth,
            default_shell,
            home_prefix,
            home_attr,
            home_alias,
            uid_attr_map,
            gid_attr_map,
            initgroups_mode,
            allow_id_overrides: allow_id_overrides.into_iter().map(Id::Name).collect(),
            nxset: Mutex::new(HashSet::new()),
            nxcache: Mutex::new(LruCache::new(NXCACHE_SIZE)),
            password_generation: AtomicU64::new(0),
            password_cache_generations: Mutex::new(HashMap::new()),
        })
    }

    /// Export broker PRTs from the identity provider for fdstore
    /// persistence across daemon restarts.
    pub async fn export_broker_prts(&self) -> Result<Vec<u8>, serde_json::Error> {
        self.client.export_broker_prts().await
    }

    /// Import broker PRTs previously exported by [`Self::export_broker_prts`].
    pub async fn import_broker_prts(&self, data: &[u8]) -> Result<(), serde_json::Error> {
        self.client.import_broker_prts(data).await
    }

    async fn get_cachestate(&self, account_id: Option<&str>) -> CacheState {
        let mut dbtxn = self.db.write().await;
        let res = self.client.get_cachestate(account_id, &mut dbtxn).await;
        if let Err(e) = dbtxn.commit() {
            error!(
                "Failed to commit db transaction after getting cache state: {:?}",
                e
            );
        }
        res
    }

    pub async fn clear_cache(&self) -> Result<(), ()> {
        let mut nxcache_txn = self.nxcache.lock().await;
        nxcache_txn.clear();
        let mut dbtxn = self.db.write().await;
        dbtxn
            .clear()
            .and_then(|_| dbtxn.clear_hello_keys())
            .and_then(|_| dbtxn.commit())
            .map_err(|_| ())?;

        // Also delete the generated himmelblau.conf. This unjoins the host!
        let path = Path::new(SERVER_CONFIG_PATH);
        if path.exists() {
            fs::remove_file(path).map_err(|_| ())?;
        }
        Ok(())
    }

    pub async fn invalidate(&self) -> Result<(), ()> {
        let mut nxcache_txn = self.nxcache.lock().await;
        nxcache_txn.clear();
        let mut dbtxn = self.db.write().await;
        dbtxn
            .invalidate()
            .and_then(|_| dbtxn.commit())
            .map_err(|_| ())
    }

    #[cfg(test)]
    async fn get_cached_usertokens(&self) -> Result<Vec<UserToken>, ()> {
        let mut dbtxn = self.db.write().await;
        dbtxn.get_accounts().map_err(|_| ())
    }

    pub async fn refresh_cached_usertoken(
        &self,
        account_id: &str,
    ) -> Result<Option<UserToken>, ()> {
        let id = Id::Name(account_id.to_string());
        let (false, Some(token)) = self.get_cached_usertoken(&id).await? else {
            return Ok(None);
        };
        let uuid = token.uuid;
        let tenant_id = token.tenant_id;
        // Reconciliation may use only the authenticated identity that made
        // this account eligible, never a lookup-only or replacement identity.
        let Some((refreshed, true)) = self
            .refresh_usertoken_with_cacheability(&id, Some((token, true)))
            .await?
        else {
            return Ok(None);
        };
        if refreshed.uuid != uuid || refreshed.tenant_id != tenant_id {
            return Ok(None);
        }
        // Provider work can yield while eligibility or memberships change.
        // Use current claims only if the same cached identity is still eligible.
        let (expired, current) = self.get_cached_usertoken(&id).await?;
        Ok(current.filter(|token| !expired && token.uuid == uuid && token.tenant_id == tenant_id))
    }

    async fn get_cached_grouptokens(&self) -> Result<Vec<GroupToken>, ()> {
        let mut dbtxn = self.db.write().await;
        dbtxn.get_groups().map_err(|_| ())
    }

    async fn set_nxcache(&self, id: &Id) {
        let mut nxcache_txn = self.nxcache.lock().await;
        let ex_time = SystemTime::now() + Duration::from_secs(self.timeout_seconds);
        nxcache_txn.put(id.clone(), ex_time);
    }

    pub async fn check_nxcache(&self, id: &Id) -> Option<SystemTime> {
        let mut nxcache_txn = self.nxcache.lock().await;
        nxcache_txn.get(id).copied()
    }

    pub async fn reload_nxset(&self, iter: impl Iterator<Item = (String, u32)>) {
        let mut nxset_txn = self.nxset.lock().await;
        nxset_txn.clear();
        for (name, gid) in iter {
            let name = Id::Name(name);
            let gid = Id::Gid(gid);

            // Skip anything that the admin opted in to
            if !(self.allow_id_overrides.contains(&gid) || self.allow_id_overrides.contains(&name))
            {
                trace!("Adding {:?}:{:?} to resolver exclusion set", name, gid);
                nxset_txn.insert(name);
                nxset_txn.insert(gid);
            }
        }
    }

    pub async fn check_nxset(&self, name: Option<&str>, idnumber: Option<u32>) -> bool {
        let nxset_txn = self.nxset.lock().await;
        if let Some(name) = name {
            if nxset_txn.contains(&Id::Name(name.to_string())) {
                return true;
            }
        }
        if let Some(idnumber) = idnumber {
            if nxset_txn.contains(&Id::Gid(idnumber)) {
                return true;
            }
        }
        false
    }

    async fn get_cached_usertoken(&self, account_id: &Id) -> Result<(bool, Option<UserToken>), ()> {
        // Account_id could be:
        //  * gidnumber
        //  * name
        //  * spn
        //  * uuid
        //  Attempt to search these in the db.
        let mut dbtxn = self.db.write().await;
        let r = dbtxn.get_account(account_id).map_err(|err| {
            trace!("get_cached_usertoken {:?}", err);
        })?;

        match r {
            Some((ut, ex)) => {
                // Are we expired?
                let offset = Duration::from_secs(ex);
                let ex_time = SystemTime::UNIX_EPOCH + offset;
                let now = SystemTime::now();

                if now >= ex_time {
                    Ok((true, Some(ut)))
                } else {
                    Ok((false, Some(ut)))
                }
            }
            None => {
                // it wasn't in the DB - lets see if it's in the nxcache.
                match self.check_nxcache(account_id).await {
                    Some(ex_time) => {
                        let now = SystemTime::now();
                        if now >= ex_time {
                            // It's in the LRU, but we are past the expiry so
                            // lets attempt a refresh.
                            Ok((true, None))
                        } else {
                            // It's in the LRU and still valid, so return that
                            // no check is needed.
                            Ok((false, None))
                        }
                    }
                    None => {
                        // Not in the LRU. Return that this IS expired
                        // and we have no data.
                        Ok((true, None))
                    }
                }
            }
        } // end match r
    }

    async fn get_cached_grouptoken(&self, grp_id: &Id) -> Result<(bool, Option<GroupToken>), ()> {
        // grp_id could be:
        //  * gidnumber
        //  * name
        //  * spn
        //  * uuid
        //  Attempt to search these in the db.
        let mut dbtxn = self.db.write().await;
        let r = dbtxn.get_group(grp_id).map_err(|_| ())?;

        match r {
            Some((ut, ex)) => {
                // Are we expired?
                let offset = Duration::from_secs(ex);
                let ex_time = SystemTime::UNIX_EPOCH + offset;
                let now = SystemTime::now();

                if now >= ex_time {
                    Ok((true, Some(ut)))
                } else {
                    Ok((false, Some(ut)))
                }
            }
            None => {
                // it wasn't in the DB - lets see if it's in the nxcache.
                match self.check_nxcache(grp_id).await {
                    Some(ex_time) => {
                        let now = SystemTime::now();
                        if now >= ex_time {
                            // It's in the LRU, but we are past the expiry so
                            // lets attempt a refresh.
                            Ok((true, None))
                        } else {
                            // It's in the LRU and still valid, so return that
                            // no check is needed.
                            Ok((false, None))
                        }
                    }
                    None => {
                        // Not in the LRU. Return that this IS expired
                        // and we have no data.
                        Ok((true, None))
                    }
                }
            }
        }
    }

    async fn set_cache_usertoken_guarded(
        &self,
        token: &mut UserToken,
        generation: u64,
        password: Option<&str>,
    ) -> Result<CacheUpdateResult, ()> {
        let keys = [
            PasswordCacheKey::Uuid(token.uuid),
            PasswordCacheKey::Name(token.name.clone()),
            PasswordCacheKey::Spn(token.spn.clone()),
            PasswordCacheKey::Gid(token.gidnumber),
        ];
        let mut generations = self.password_cache_generations.lock().await;
        let same_identity = |latest: &&PasswordCacheGeneration| {
            latest.uuid == token.uuid && latest.tenant_id == token.tenant_id
        };
        if keys
            .iter()
            .filter_map(|key| generations.get(key))
            .any(|latest| latest.identity_generation > generation && !same_identity(&latest))
        {
            return Ok(CacheUpdateResult::IdentityChanged);
        }
        let latest_identity_generation = keys
            .iter()
            .filter_map(|key| generations.get(key))
            .filter(same_identity)
            .map(|latest| latest.identity_generation)
            .max();
        let latest_password_generation = keys
            .iter()
            .filter_map(|key| generations.get(key))
            .filter(same_identity)
            .filter_map(|latest| latest.password_generation)
            .max();
        if latest_password_generation.is_some_and(|latest| latest >= generation)
            || (password.is_none()
                && latest_identity_generation.is_some_and(|latest| latest > generation))
        {
            // Never restore stale identity claims or group memberships either.
            return Ok(CacheUpdateResult::Superseded);
        }

        if latest_identity_generation.is_some_and(|latest| latest > generation) {
            // A same-identity refresh must not suppress password invalidation,
            // but its newer identity claims and memberships must be preserved.
            let (_, current) = self
                .get_cached_usertoken(&Id::Name(token.uuid.hyphenated().to_string()))
                .await?;
            let Some(current) = current.filter(|current| {
                current.uuid == token.uuid && current.tenant_id == token.tenant_id
            }) else {
                return Ok(CacheUpdateResult::IdentityChanged);
            };
            *token = current;
        }
        self.set_cache_usertoken(token, password.is_some()).await?;
        let keys = [
            PasswordCacheKey::Uuid(token.uuid),
            PasswordCacheKey::Name(token.name.clone()),
            PasswordCacheKey::Spn(token.spn.clone()),
            PasswordCacheKey::Gid(token.gidnumber),
        ];
        // Publish only after durable token storage/invalidation. A passwordless
        // refresh advances identity ordering without suppressing an accepted
        // password that still needs to invalidate the previous verifier.
        let latest = PasswordCacheGeneration {
            identity_generation: latest_identity_generation
                .map_or(generation, |latest| latest.max(generation)),
            password_generation: if password.is_some() {
                Some(generation)
            } else {
                latest_password_generation
            },
            uuid: token.uuid,
            tenant_id: token.tenant_id,
        };
        generations.extend(keys.into_iter().map(|key| (key, latest)));
        if let Some(password) = password {
            if self
                .set_cache_userpassword(token.uuid, password)
                .await
                .is_err()
            {
                error!("Failed to cache offline password after successful authentication");
            }
        }
        Ok(CacheUpdateResult::Updated)
    }

    async fn set_cache_usertoken(
        &self,
        token: &mut UserToken,
        clear_password: bool,
    ) -> Result<(), ()> {
        // Set an expiry
        let ex_time = SystemTime::now() + Duration::from_secs(self.timeout_seconds);
        let offset = ex_time
            .duration_since(SystemTime::UNIX_EPOCH)
            .map_err(|e| {
                error!("time conversion error - ex_time less than epoch? {:?}", e);
            })?;

        // Check if requested `shell` exists on the system, else use `default_shell`
        let requested_shell_exists: bool = token
            .shell
            .as_ref()
            .map(|shell| {
                let exists = Path::new(shell).exists();
                if !exists {
                    info!(
                        "User shell is not present on this system - {}. Check `/etc/shells` for valid shell options.",
                        shell
                    )
                }
                exists
            })
            .unwrap_or_else(|| {
                info!("User has not specified a shell, using default");
                false
            });

        if !requested_shell_exists {
            token.shell = Some(self.default_shell.clone())
        }

        // Filter out groups that are in the nxset
        {
            let nxset_txn = self.nxset.lock().await;
            token.groups.retain(|g| {
                !(nxset_txn.contains(&Id::Gid(g.gidnumber))
                    || nxset_txn.contains(&Id::Name(g.name.clone())))
            });
        }

        let mut dbtxn = self.db.write().await;
        let clear_password = clear_password
            || dbtxn
                .get_account(&Id::Name(token.uuid.hyphenated().to_string()))
                .map_err(|_| ())?
                .is_some_and(|(cached, _)| {
                    cached.uuid == token.uuid && cached.tenant_id != token.tenant_id
                });
        token
            .groups
            .iter()
            // We need to add the groups first
            .try_for_each(|g| dbtxn.update_group(g, offset.as_secs()))
            .and_then(|_|
                // So that when we add the account it can make the relationships.
                dbtxn
                    .update_account(token, offset.as_secs()))
            .and_then(|_| {
                if clear_password {
                    // Commit invalidation with the authenticated identity so
                    // a failed replacement cannot retain the old verifier.
                    dbtxn.clear_account_password(token.uuid)
                } else {
                    Ok(())
                }
            })
            .and_then(|_| dbtxn.commit())
            .map_err(|_| ())
    }

    async fn set_cache_grouptoken(&self, token: &GroupToken) -> Result<(), ()> {
        // Set an expiry
        let ex_time = SystemTime::now() + Duration::from_secs(self.timeout_seconds);
        let offset = ex_time
            .duration_since(SystemTime::UNIX_EPOCH)
            .map_err(|e| {
                error!("time conversion error - ex_time less than epoch? {:?}", e);
            })?;

        let mut dbtxn = self.db.write().await;
        dbtxn
            .update_group(token, offset.as_secs())
            .and_then(|_| dbtxn.commit())
            .map_err(|_| ())
    }

    async fn delete_cache_usertoken(&self, a_uuid: Uuid) -> Result<(), ()> {
        let mut dbtxn = self.db.write().await;
        dbtxn
            .delete_account(a_uuid)
            .and_then(|_| dbtxn.commit())
            .map_err(|_| ())
    }

    async fn delete_cache_grouptoken(&self, g_uuid: Uuid) -> Result<(), ()> {
        let mut dbtxn = self.db.write().await;
        dbtxn
            .delete_group(g_uuid)
            .and_then(|_| dbtxn.commit())
            .map_err(|_| ())
    }

    async fn set_cache_userpassword(&self, a_uuid: Uuid, cred: &str) -> Result<(), ()> {
        let mut hsm_txn = self.hsm.lock().await;
        let mut dbtxn = self.db.write().await;
        dbtxn
            .update_account_password(a_uuid, cred, hsm_txn.deref_mut(), &self.hmac_key)
            .and_then(|x| dbtxn.commit().map(|_| x))
            .map_err(|_| ())
    }

    async fn check_cache_userpassword(&self, a_uuid: Uuid, cred: &str) -> Result<bool, ()> {
        let mut hsm_txn = self.hsm.lock().await;
        let mut dbtxn = self.db.write().await;
        dbtxn
            .check_account_password(a_uuid, cred, hsm_txn.deref_mut(), &self.hmac_key)
            .and_then(|x| dbtxn.commit().map(|_| x))
            .map_err(|_| ())
    }

    async fn refresh_usertoken(
        &self,
        account_id: &Id,
        token: Option<UserToken>,
    ) -> Result<Option<UserToken>, ()> {
        self.refresh_usertoken_with_cacheability(account_id, token.map(|token| (token, false)))
            .await
            .map(|result| result.map(|(token, _)| token))
    }

    async fn refresh_usertoken_with_cacheability(
        &self,
        account_id: &Id,
        token: Option<(UserToken, bool)>,
    ) -> Result<Option<(UserToken, bool)>, ()> {
        let mut hsm_lock = self.hsm.lock().await;
        let mut dbtxn = self.db.write().await;

        let user_get_result = self
            .client
            .unix_user_get(
                account_id,
                token.as_ref().map(|(token, _)| token),
                &mut dbtxn,
                hsm_lock.deref_mut(),
                &self.machine_key,
            )
            .await;

        // Order this provider observation before another request can replace it.
        let generation = self.password_generation.fetch_add(1, Ordering::Relaxed);
        drop(hsm_lock);
        dbtxn.commit().map_err(|_| ())?;

        match user_get_result {
            Ok(UserTokenState::Update(mut n_tok)) => {
                match self
                    .set_cache_usertoken_guarded(&mut n_tok, generation, None)
                    .await?
                {
                    CacheUpdateResult::Updated => Ok(Some((n_tok, true))),
                    CacheUpdateResult::Superseded | CacheUpdateResult::IdentityChanged => {
                        // A newer observation won. Never return the stale token
                        // as authenticated/cacheable after discarding its write.
                        self.get_cached_usertoken(account_id)
                            .await
                            .map(|(expired, token)| token.map(|token| (token, !expired)))
                    }
                }
            }
            Ok(UserTokenState::LookupOnly(n_tok)) => Ok(Some((n_tok, false))),
            Ok(UserTokenState::NotFound) => {
                // It previously existed, so now purge it.
                if let Some((tok, _)) = token {
                    self.delete_cache_usertoken(tok.uuid).await?;
                };
                // Cache the NX here.
                self.set_nxcache(account_id).await;
                Ok(None)
            }
            Ok(UserTokenState::UseCached) => Ok(token),
            Err(err @ IdpError::NotFound { .. }) => {
                // NSS may ask for local or unknown identities outside the provider.
                debug!(?err, "User lookup did not match an identity provider");
                Ok(token)
            }
            Err(err) => {
                // Something went wrong, we don't know what, but lets return the token
                // anyway.
                error!(?err);
                Ok(token)
            }
        }
    }

    async fn refresh_grouptoken(
        &self,
        grp_id: &Id,
        token: Option<GroupToken>,
    ) -> Result<Option<GroupToken>, ()> {
        let mut hsm_lock = self.hsm.lock().await;

        let group_get_result = self
            .client
            .unix_group_get(grp_id, hsm_lock.deref_mut())
            .await;

        drop(hsm_lock);

        match group_get_result {
            Ok(n_tok) => {
                if self
                    .check_nxset(Some(&n_tok.name), Some(n_tok.gidnumber))
                    .await
                {
                    // Refuse to release the token, it's in the denied set.
                    self.delete_cache_grouptoken(n_tok.uuid).await?;
                    Ok(None)
                } else {
                    // We have the token!
                    self.set_cache_grouptoken(&n_tok).await?;
                    Ok(Some(n_tok))
                }
            }
            Err(e) => {
                // Some other transient error, continue with the token.
                error!(?e);
                Ok(token)
            }
        }
    }

    pub async fn get_user_accesstoken(
        &self,
        account_id: Id,
        scopes: Vec<String>,
        client_id: Option<String>,
        redirect_uri: Option<String>,
        req_cnf: Option<String>,
    ) -> Option<UnixUserToken> {
        // Validate the user isn't in the nxset (aka, it's a local user or group).
        let (name, idnumber) = match account_id.clone() {
            Id::Name(name) => (Some(name), None),
            Id::Gid(idnumber) => (None, Some(idnumber)),
        };
        if self.check_nxset(name.as_deref(), idnumber).await {
            return None;
        }

        let token = match self.get_usertoken(account_id.clone()).await {
            Ok(Some(token)) => token,
            _ => {
                error!("Failed to fetch unix user token during access token request!");
                return None;
            }
        };

        let mut hsm_lock = self.hsm.lock().await;
        let mut dbtxn = self.db.write().await;

        let user_get_result = self
            .client
            .unix_user_access(
                &account_id,
                scopes,
                Some(&token),
                client_id,
                redirect_uri,
                req_cnf,
                &mut dbtxn,
                hsm_lock.deref_mut(),
                &self.machine_key,
            )
            .await;

        drop(hsm_lock);
        if dbtxn.commit().is_err() {
            error!("Failed to commit user token DB transaction");
            return None;
        }

        match user_get_result {
            Ok(token) => Some(token),
            Err(e) => {
                error!("Failed to fetch access token: {:?}", e);
                None
            }
        }
    }

    pub async fn get_user_tgts(
        &self,
        account_id: Id,
    ) -> Option<(
        uid_t,
        uid_t,
        Option<Box<KerberosCredentials>>,
        Option<Box<KerberosCredentials>>,
        Option<String>,
        Option<String>,
    )> {
        // Validate the user isn't in the nxset (aka, it's a local user or group).
        let (name, idnumber) = match account_id.clone() {
            Id::Name(name) => (Some(name), None),
            Id::Gid(idnumber) => (None, Some(idnumber)),
        };
        if self.check_nxset(name.as_deref(), idnumber).await {
            return None;
        }

        let token = match self.get_usertoken(account_id.clone()).await {
            Ok(Some(token)) => token,
            _ => {
                error!("Failed to fetch unix user token during access token request!");
                return None;
            }
        };

        let mut hsm_lock = self.hsm.lock().await;
        let mut dbtxn = self.db.write().await;

        let (cloud_ccache, ad_ccache, top_level_names, tenant_id) = self
            .client
            .unix_user_tgts(
                &account_id,
                Some(&token),
                &mut dbtxn,
                hsm_lock.deref_mut(),
                &self.machine_key,
            )
            .await;

        drop(hsm_lock);
        if dbtxn.commit().is_err() {
            error!("Failed to commit user token DB transaction");
            return None;
        }

        Some((
            token.gidnumber,
            token.real_gidnumber.unwrap_or(token.gidnumber),
            cloud_ccache,
            ad_ccache,
            top_level_names,
            tenant_id,
        ))
    }

    pub async fn get_user_prt_cookie(
        &self,
        account_id: Id,
        sso_nonce: Option<&str>,
    ) -> Option<String> {
        // Validate the user isn't in the nxset (aka, it's a local user or group).
        let (name, idnumber) = match account_id.clone() {
            Id::Name(name) => (Some(name), None),
            Id::Gid(idnumber) => (None, Some(idnumber)),
        };
        if self.check_nxset(name.as_deref(), idnumber).await {
            return None;
        }

        let token = match self.get_usertoken(account_id.clone()).await {
            Ok(Some(token)) => token,
            _ => {
                error!("Failed to fetch unix user token during access token request!");
                return None;
            }
        };

        let mut hsm_lock = self.hsm.lock().await;
        let mut dbtxn = self.db.write().await;

        let cookie = self
            .client
            .unix_user_prt_cookie(
                &account_id,
                Some(&token),
                sso_nonce,
                &mut dbtxn,
                hsm_lock.deref_mut(),
                &self.machine_key,
            )
            .await;

        drop(hsm_lock);
        if dbtxn.commit().is_err() {
            error!("Failed to commit user token DB transaction");
            return None;
        }

        match cookie {
            Ok(cookie) => Some(cookie),
            Err(e) => {
                error!("Failed to fetch prt sso cookie: {:?}", e);
                None
            }
        }
    }

    pub async fn change_auth_token(
        &self,
        account_id: &str,
        token: &UnixUserToken,
        new_tok: &str,
    ) -> Result<bool, ()> {
        // Validate the user isn't in the nxset (aka, it's a local user or group).
        if self.check_nxset(Some(account_id), None).await {
            return Ok(false);
        }

        let mut hsm_lock = self.hsm.lock().await;
        let mut dbtxn = self.db.write().await;

        let res = self
            .client
            .change_auth_token(
                account_id,
                token,
                new_tok,
                &mut dbtxn,
                hsm_lock.deref_mut(),
                &self.machine_key,
            )
            .await;

        drop(hsm_lock);

        match res {
            Ok(res) => {
                dbtxn.commit().map_err(|_| ())?;
                Ok(res)
            }
            Err(e) => {
                trace!("change_auth_token error -> {:?}", e);
                Err(())
            }
        }
    }

    pub async fn offline_break_glass(&self, ttl: Option<u64>) -> Result<(), ()> {
        let res = self.client.offline_break_glass(ttl).await;

        res.map_err(|e| {
            trace!("offline_break_glass error -> {:?}", e);
        })
    }

    pub async fn get_usertoken(&self, account_id: Id) -> Result<Option<UserToken>, ()> {
        self.get_usertoken_with_cacheability(account_id)
            .await
            .map(|result| result.map(|(token, _)| token))
    }

    // Keep the result's persistence eligibility alongside the token so a
    // lookup-only response cannot inherit eligibility from an old database row.
    async fn get_usertoken_with_cacheability(
        &self,
        account_id: Id,
    ) -> Result<Option<(UserToken, bool)>, ()> {
        // Validate the user isn't in the nxset (aka, it's a local user or group).
        let (name, idnumber) = match account_id.clone() {
            Id::Name(name) => (Some(name), None),
            Id::Gid(idnumber) => (None, Some(idnumber)),
        };
        if self.check_nxset(name.as_deref(), idnumber).await {
            return Ok(None);
        }

        trace!("get_usertoken");
        // get the item from the cache
        let (expired, item) = self.get_cached_usertoken(&account_id).await.map_err(|e| {
            trace!("get_usertoken error -> {:?}", e);
        })?;

        let state = match account_id {
            Id::Name(ref name) => self.get_cachestate(Some(name)).await,
            Id::Gid(_) => match &item {
                Some(token) => self.get_cachestate(Some(&token.spn)).await,
                None => self.get_cachestate(None).await,
            },
        };

        // Expired records remain available for offline use, but must not
        // repopulate persistent NSS caches without a trusted refresh.
        let item = item.map(|token| (token, !expired));

        match (expired, state) {
            (_, CacheState::Offline) => {
                trace!("offline, returning cached item");
                Ok(item)
            }
            (false, CacheState::OfflineNextCheck(time)) => {
                trace!(
                    "offline valid, next check {:?}, returning cached item",
                    time
                );
                // Still valid within lifetime, return.
                Ok(item)
            }
            (false, CacheState::Online) => {
                trace!("online valid, returning cached item");
                // Still valid within lifetime, return.
                Ok(item)
            }
            (true, CacheState::OfflineNextCheck(time)) => {
                trace!("offline expired, next check {:?}, refresh cache", time);
                // Attempt to refresh the item
                // Return it.
                if SystemTime::now() >= time && self.test_connection().await {
                    // We brought ourselves online, lets go
                    self.refresh_usertoken_with_cacheability(&account_id, item)
                        .await
                } else {
                    // Unable to bring up connection, return cache.
                    Ok(item)
                }
            }
            (true, CacheState::Online) => {
                trace!("online expired, refresh cache");
                // Attempt to refresh the item
                // Return it.
                self.refresh_usertoken_with_cacheability(&account_id, item)
                    .await
            }
        }
        .map(|t| {
            trace!("token -> {:?}", t);
            t
        })
    }

    async fn get_grouptoken(&self, grp_id: Id) -> Result<Option<GroupToken>, ()> {
        trace!("get_grouptoken");
        let (expired, item) = self.get_cached_grouptoken(&grp_id).await.map_err(|e| {
            trace!("get_grouptoken error -> {:?}", e);
        })?;

        // In Himmelblau, we only ever utilize cached group tokens
        let state = CacheState::Offline;

        match (expired, state) {
            (_, CacheState::Offline) => {
                trace!("offline, returning cached item");
                Ok(item)
            }
            (false, CacheState::OfflineNextCheck(time)) => {
                trace!(
                    "offline valid, next check {:?}, returning cached item",
                    time
                );
                // Still valid within lifetime, return.
                Ok(item)
            }
            (false, CacheState::Online) => {
                trace!("online valid, returning cached item");
                // Still valid within lifetime, return.
                Ok(item)
            }
            (true, CacheState::OfflineNextCheck(time)) => {
                trace!("offline expired, next check {:?}, refresh cache", time);
                // Attempt to refresh the item
                // Return it.
                if SystemTime::now() >= time && self.test_connection().await {
                    // We brought ourselves online, lets go
                    self.refresh_grouptoken(&grp_id, item).await
                } else {
                    // Unable to bring up connection, return cache.
                    Ok(item)
                }
            }
            (true, CacheState::Online) => {
                trace!("online expired, refresh cache");
                // Attempt to refresh the item
                // Return it.
                self.refresh_grouptoken(&grp_id, item).await
            }
        }
    }

    pub async fn get_groupmembers(&self, g_uuid: Uuid) -> Vec<String> {
        let mut dbtxn = self.db.write().await;

        dbtxn
            .get_group_members(g_uuid)
            .unwrap_or_else(|_| Vec::new())
            .into_iter()
            .map(|ut| self.token_uidattr(&ut))
            .collect()
    }

    #[inline(always)]
    fn token_homedirectory_alias(&self, token: &UserToken) -> Option<String> {
        self.home_alias.map(|t| match t {
            // If we have an alias. use it.
            HomeAttr::Uuid => token.uuid.hyphenated().to_string(),
            HomeAttr::Spn => token.spn.as_str().to_string(),
            HomeAttr::Name => token.name.as_str().to_string(),
            HomeAttr::Cn => token.spn.split('@').collect::<Vec<&str>>()[0].to_string(),
        })
    }

    #[inline(always)]
    fn token_homedirectory_attr(&self, token: &UserToken) -> String {
        match self.home_attr {
            HomeAttr::Uuid => token.uuid.hyphenated().to_string(),
            HomeAttr::Spn => token.spn.as_str().to_string(),
            HomeAttr::Name => token.name.as_str().to_string(),
            HomeAttr::Cn => token.spn.split('@').collect::<Vec<&str>>()[0].to_string(),
        }
    }

    #[inline(always)]
    fn token_homedirectory(&self, token: &UserToken) -> String {
        self.token_homedirectory_alias(token)
            .unwrap_or_else(|| self.token_homedirectory_attr(token))
    }

    #[inline(always)]
    fn token_abs_homedirectory(&self, token: &UserToken) -> String {
        format!("{}{}", self.home_prefix, self.token_homedirectory(token))
    }

    #[inline(always)]
    fn token_uidattr(&self, token: &UserToken) -> String {
        match self.uid_attr_map {
            UidAttr::Spn => token.spn.as_str(),
            UidAttr::Name => token.name.as_str(),
        }
        .to_string()
    }

    pub async fn get_nssaccounts(&self) -> Result<Vec<NssUser>, ()> {
        self.get_unexpired_nssaccounts().await
    }

    pub async fn get_unexpired_nssaccounts(&self) -> Result<Vec<NssUser>, ()> {
        let now = SystemTime::now()
            .duration_since(SystemTime::UNIX_EPOCH)
            .map_err(|_| ())?
            .as_secs();
        let mut dbtxn = self.db.write().await;
        dbtxn
            .get_unexpired_accounts(now)
            .map(|l| {
                l.into_iter()
                    .map(|tok| self.nss_user_from_token(tok, true))
                    .collect()
            })
            .map_err(|_| ())
    }

    async fn get_nssaccount(&self, account_id: Id) -> Result<Option<NssUser>, ()> {
        self.get_usertoken_with_cacheability(account_id)
            .await
            .map(|result| result.map(|(tok, cacheable)| self.nss_user_from_token(tok, cacheable)))
    }

    fn nss_user_from_token(&self, tok: UserToken, cacheable: bool) -> NssUser {
        NssUser {
            homedir: self.token_abs_homedirectory(&tok),
            name: self.token_uidattr(&tok),
            uid: tok.gidnumber,
            gid: tok.real_gidnumber.unwrap_or(tok.gidnumber),
            gecos: tok.displayname,
            shell: tok.shell.unwrap_or_else(|| self.default_shell.clone()),
            cacheable,
        }
    }

    pub async fn get_nssaccount_name(&self, account_id: &str) -> Result<Option<NssUser>, ()> {
        self.get_nssaccount(Id::Name(account_id.to_string())).await
    }

    pub async fn get_nssaccount_gid(&self, gid: u32) -> Result<Option<NssUser>, ()> {
        self.get_nssaccount(Id::Gid(gid)).await
    }

    #[inline(always)]
    fn token_gidattr(&self, token: &GroupToken) -> String {
        match self.gid_attr_map {
            UidAttr::Spn => token.spn.as_str(),
            UidAttr::Name => token.name.as_str(),
        }
        .to_string()
    }

    pub async fn get_nssgroups(&self) -> Result<Vec<NssGroup>, ()> {
        let l = self.get_cached_grouptokens().await?;
        let mut r: Vec<_> = Vec::with_capacity(l.len());
        for tok in l.into_iter() {
            let members = self.get_groupmembers(tok.uuid).await;
            r.push(NssGroup {
                name: self.token_gidattr(&tok),
                gid: tok.gidnumber,
                members,
            })
        }
        Ok(r)
    }

    async fn get_nssgroup(&self, grp_id: Id) -> Result<Option<NssGroup>, ()> {
        let token = self.get_grouptoken(grp_id).await?;
        // Get members set.
        match token {
            Some(tok) => {
                let members = self.get_groupmembers(tok.uuid).await;
                Ok(Some(NssGroup {
                    name: self.token_gidattr(&tok),
                    gid: tok.gidnumber,
                    members,
                }))
            }
            None => Ok(None),
        }
    }

    pub async fn get_nssgroup_name(&self, grp_id: &str) -> Result<Option<NssGroup>, ()> {
        self.get_nssgroup(Id::Name(grp_id.to_string())).await
    }

    pub async fn get_nssgroup_gid(&self, gid: u32) -> Result<Option<NssGroup>, ()> {
        self.get_nssgroup(Id::Gid(gid)).await
    }

    pub async fn get_initgroups(&self, account_id: &str) -> Result<Option<Vec<u32>>, ()> {
        let token = self.get_usertoken(Id::Name(account_id.to_string())).await?;
        let Some(tok) = token else {
            return Ok(None);
        };
        if self.initgroups_mode == InitgroupsMode::Full {
            return Ok(Some(tok.groups.iter().map(|g| g.gidnumber).collect()));
        }
        let mut named = Vec::with_capacity(tok.groups.len());
        for group in &tok.groups {
            match self.get_nssgroup_gid(group.gidnumber).await {
                Ok(Some(nss_group)) if !nss_group.name.is_empty() => {
                    named.push(group.gidnumber);
                }
                Ok(Some(_)) | Ok(None) | Err(_) => {
                    debug!(
                        gid = group.gidnumber,
                        "skipping supplementary group with no NSS name"
                    );
                }
            }
        }
        Ok(Some(named))
    }

    pub async fn pam_account_allowed(&self, account_id: &str) -> Result<Option<bool>, ()> {
        let token = self.get_usertoken(Id::Name(account_id.to_string())).await?;

        if self.pam_allow_groups.is_empty() {
            // An empty allow list permits all users
            Ok(Some(true))
        } else {
            Ok(token.map(|tok| {
                // Never ever EVER list Entra group names in the allowed groups
                // set. This is a SECURITY RISK! See CVE-2025-49012. Group
                // names ARE NOT unique in Entra Id. Only group Object Ids may
                // be listed here. Generic OIDC group claim values are accepted
                // only when OIDC authentication is configured, not for Entra
                // object-id groups.
                let user_set: BTreeSet<_> = tok
                    .groups
                    .iter()
                    .flat_map(|g| {
                        let mut ids = vec![g.uuid.hyphenated().to_string()];
                        if self.oidc_auth {
                            ids.push(g.spn.clone());
                        }
                        ids
                    })
                    .chain(std::iter::once(account_id.to_string()))
                    .collect();

                debug!(
                    "Checking if user is in allowed groups ({:?}) -> {:?}",
                    self.pam_allow_groups,
                    user_set
                        .iter()
                        .filter(|s| s.as_str() != account_id)
                        .cloned(),
                );
                let intersection_count = user_set.intersection(&self.pam_allow_groups).count();
                debug!("Number of intersecting groups: {}", intersection_count);
                debug!("User has valid token: {}", tok.valid);

                intersection_count > 0 && tok.valid
            }))
        }
    }

    pub async fn pam_account_authenticate_init(
        &self,
        account_id: &str,
        service: &str,
        no_hello_pin: bool,
        force_reauth: bool,
        shutdown_rx: broadcast::Receiver<()>,
    ) -> Result<(AuthSession, PamAuthResponse), ()> {
        // Setup an auth session. If possible bring the resolver online.
        // Further steps won't attempt to bring the cache online to prevent
        // weird interactions - they should assume online/offline only for
        // the duration of their operation. A failure of connectivity during
        // an online operation will take the cache offline however.

        // Skip the whole auth dance if this user is in the nxset (aka, it's a
        // local user or group).
        if self.check_nxset(Some(account_id), None).await {
            return Ok((AuthSession::Denied, PamAuthResponse::Unknown));
        }

        // An offline session must not overwrite an identity replaced after its lookup.
        let cache_generation = self.password_generation.fetch_add(1, Ordering::Relaxed);
        let id = Id::Name(account_id.to_string());
        let (_expired, token) = self.get_cached_usertoken(&id).await?;
        // If we don't have a token here, then NSS has yet to be called. Failing
        // to request a token now will result in an auth failure in pam_account_authenticate_step.
        let token = match token {
            Some(token) => Some(token),
            None => self.refresh_usertoken(&id, None).await?,
        };
        let state = self.get_cachestate(Some(account_id)).await;

        let online_at_init = if !matches!(state, CacheState::Online) {
            // Attempt a cache online.
            self.test_connection().await
        } else {
            true
        };

        let maybe_err = if online_at_init {
            let online_result = {
                let mut hsm_lock = self.hsm.lock().await;
                let mut dbtxn = self.db.write().await;

                self.client
                    .unix_user_online_auth_init(
                        account_id,
                        token.as_ref(),
                        service,
                        no_hello_pin,
                        force_reauth,
                        &mut dbtxn,
                        hsm_lock.deref_mut(),
                        &self.machine_key,
                        &shutdown_rx,
                    )
                    .await
            };

            match online_result {
                Ok(res) => Ok(res),
                Err(e) => {
                    if force_reauth {
                        // force_reauth requires online auth, do not fall back
                        // to offline, as that cannot satisfy Entra sign-in
                        // frequency policy.
                        Err(e)
                    } else {
                        // Check if the failure is because we went offline
                        match self.get_cachestate(Some(account_id)).await {
                            CacheState::Offline | CacheState::OfflineNextCheck(_) => {
                                // Attempt to proceed offline
                                let mut dbtxn = self.db.write().await;
                                self.client
                                    .unix_user_offline_auth_init(
                                        account_id,
                                        token.as_ref(),
                                        service,
                                        no_hello_pin,
                                        &mut dbtxn,
                                    )
                                    .await
                            }
                            _ => Err(e),
                        }
                    }
                }
            }
        } else if force_reauth {
            // force_reauth requires online connectivity, so refuse to proceed
            // offline since cached auth cannot satisfy Entra sign-in frequency.
            return Ok((
                AuthSession::Denied,
                PamAuthResponse::InitDenied {
                    msg: "Re-authentication requires network connectivity.".to_string(),
                },
            ));
        } else {
            let mut dbtxn = self.db.write().await;

            // Can the auth proceed offline?
            self.client
                .unix_user_offline_auth_init(
                    account_id,
                    token.as_ref(),
                    service,
                    no_hello_pin,
                    &mut dbtxn,
                )
                .await
        };

        match maybe_err {
            Ok((next_req, cred_handler)) => {
                let auth_session = AuthSession::InProgress {
                    account_id: account_id.to_string(),
                    service: service.to_string(),
                    id,
                    token: token.map(Box::new),
                    pending_password: None,
                    cache_generation,
                    identity_staged: false,
                    online_at_init,
                    cred_handler,
                    shutdown_rx,
                    no_hello_pin,
                    force_reauth,
                };

                // Now identify what credentials are needed next. The auth session tells
                // us this.

                Ok((auth_session, next_req.into()))
            }
            Err(IdpError::NotFound { what, where_ }) => Ok((
                AuthSession::Denied,
                PamAuthResponse::InitDenied {
                    msg: format!("NotFound: {} in {}", what, where_),
                },
            )),
            Err(e) => {
                error!("{:?}", e);
                Err(())
            }
        }
    }

    pub async fn pam_account_authenticate_step(
        &self,
        auth_session: &mut AuthSession,
        pam_next_req: PamAuthRequest,
    ) -> Result<PamAuthResponse, ()> {
        let state = match auth_session {
            AuthSession::InProgress {
                account_id,
                service: _,
                id: _,
                token: _,
                pending_password: _,
                cache_generation: _,
                identity_staged: _,
                online_at_init: _,
                cred_handler: _,
                shutdown_rx: _,
                no_hello_pin: _,
                force_reauth: _,
            } => self.get_cachestate(Some(account_id)).await,
            _ => self.get_cachestate(None).await,
        };

        let maybe_err = match (&mut *auth_session, state) {
            (
                &mut AuthSession::InProgress {
                    ref account_id,
                    ref service,
                    id: _,
                    token: Some(ref token),
                    ref mut pending_password,
                    ref mut cache_generation,
                    ref mut identity_staged,
                    online_at_init: true,
                    ref mut cred_handler,
                    ref shutdown_rx,
                    no_hello_pin,
                    force_reauth: _,
                },
                CacheState::Online,
            ) => {
                let mut hsm_lock = self.hsm.lock().await;
                let mut dbtxn = self.db.write().await;

                let maybe_cache_action = self
                    .client
                    .unix_user_online_auth_step(
                        account_id,
                        token,
                        service,
                        no_hello_pin,
                        cred_handler,
                        pam_next_req,
                        &mut dbtxn,
                        hsm_lock.deref_mut(),
                        &self.machine_key,
                        shutdown_rx,
                    )
                    .await;

                // Order accepted credentials before releasing the provider locks.
                // A password staged for PIN setup retains this generation, so
                // completing an older session cannot restore a revoked verifier.
                let observation = self.password_generation.fetch_add(1, Ordering::Relaxed);
                // Local PIN/TOTP setup may take several steps and retries. None
                // of them re-authenticates the staged remote identity or password.
                let generation = if *identity_staged {
                    *cache_generation
                } else {
                    observation
                };
                if matches!(
                    &maybe_cache_action,
                    Ok((
                        AuthResult::Success { .. }
                            | AuthResult::Next(
                                AuthRequest::SetupPin { .. } | AuthRequest::HelloTOTP { .. }
                            ),
                        _
                    ))
                ) {
                    *cache_generation = generation;
                }
                if matches!(
                    &maybe_cache_action,
                    Ok((
                        AuthResult::Next(
                            AuthRequest::SetupPin { .. } | AuthRequest::HelloTOTP { .. }
                        ),
                        _
                    ))
                ) {
                    *identity_staged = true;
                }
                drop(hsm_lock);
                dbtxn.commit().map_err(|_| ())?;

                match maybe_cache_action {
                    Ok((res, AuthCacheAction::None)) => Ok(res),
                    Ok((
                        AuthResult::Success { token },
                        AuthCacheAction::PasswordHashUpdate { cred },
                    )) => {
                        *pending_password = Some((generation, Zeroizing::new(cred)));
                        Ok(AuthResult::Success { token })
                    }
                    Ok((
                        next @ AuthResult::Next(AuthRequest::SetupPin { .. }),
                        AuthCacheAction::PasswordHashUpdate { cred },
                    )) => {
                        // Wait until the PIN setup completes before caching credentials.
                        *pending_password = Some((generation, Zeroizing::new(cred)));
                        Ok(next)
                    }
                    // Password verifiers may only be persisted after the complete
                    // remote authentication flow succeeds. Other `Next` variants
                    // still represent an authentication step such as MFA.
                    Ok((_, AuthCacheAction::PasswordHashUpdate { .. })) => {
                        error!("provider gave back illogical password hash update with a nonsuccess condition");
                        Err(IdpError::BadRequest)
                    }
                    Err(e) => Err(e),
                }
            }
            /*
            (
                &mut AuthSession::InProgress {
                    account_id: _,
                    id: _,
                    token: _,
                    online_at_init: true,
                    cred_handler: _,
                },
                _,
            ) => {
                // Fail, we went offline.
                error!("Unable to proceed with authentication, resolver has gone offline");
                Err(IdpError::Transport)
            }
            */
            (
                &mut AuthSession::InProgress {
                    ref account_id,
                    service: _,
                    id: _,
                    token: Some(ref token),
                    pending_password: _,
                    cache_generation: _,
                    identity_staged: _,
                    online_at_init,
                    ref mut cred_handler,
                    // Only need in online auth.
                    shutdown_rx: _,
                    no_hello_pin: _,
                    force_reauth,
                },
                _,
            ) => {
                // force_reauth requires online auth, refuse offline fallback.
                if force_reauth {
                    return Ok(PamAuthResponse::Denied(
                        "Re-authentication requires network connectivity.".to_string(),
                    ));
                }

                // We are offline, continue. Remember, authsession should have
                // *everything you need* to proceed here!
                //
                // Rather than calling client, should this actually be self
                // contained to the resolver so that it has generic offline-paths
                // that are possible?
                match (&cred_handler, &pam_next_req) {
                    (AuthCredHandler::ReauthPassword { .. }, _) => {
                        // Password-based Hello reauthentication must complete online so
                        // that the provider can enforce the remaining MFA requirements.
                        return Err(());
                    }
                    (_, PamAuthRequest::Password { cred }) => {
                        match self.check_cache_userpassword(token.uuid, cred).await {
                            Ok(true) => Ok(AuthResult::Success {
                                token: *token.clone(),
                            }),
                            Ok(false) => Ok(AuthResult::Denied("Offline auth failed".to_string())),
                            Err(()) => {
                                // We had a genuine backend error of some description.
                                return Err(());
                            }
                        }
                    }
                    (AuthCredHandler::MFA { .. }, _) => {
                        // AuthCredHandler::MFA is invalid for offline auth
                        return Err(());
                    }
                    (AuthCredHandler::SetupPin { .. }, _) => {
                        // AuthCredHandler::SetupPin is invalid for offline auth
                        return Err(());
                    }
                    (AuthCredHandler::ChangePassword { .. }, _) => {
                        // AuthCredHandler::ChangePassword is invalid for offline auth
                        return Err(());
                    }
                    (_, PamAuthRequest::Pin { .. }) | (_, PamAuthRequest::HelloTOTP { .. }) => {
                        // The Pin acts as a single device password, and can be
                        // used to unlock the TPM to validate the authentication.
                        let mut hsm_lock = self.hsm.lock().await;
                        let mut dbtxn = self.db.write().await;

                        let auth_result = self
                            .client
                            .unix_user_offline_auth_step(
                                account_id,
                                token,
                                cred_handler,
                                pam_next_req,
                                &mut dbtxn,
                                hsm_lock.deref_mut(),
                                &self.machine_key,
                                online_at_init,
                            )
                            .await;

                        drop(hsm_lock);
                        dbtxn.commit().map_err(|_| ())?;

                        auth_result
                    }
                    (AuthCredHandler::HelloTOTP { .. }, _) => {
                        // AuthCredHandler::HelloTOTP with anything other than HelloTOTP is invalid
                        return Err(());
                    }
                    (AuthCredHandler::None, PamAuthRequest::Input { .. }) => {
                        // AuthCredHandler::None is invalid with Input
                        return Err(());
                    }
                    (AuthCredHandler::None, PamAuthRequest::MFAPoll { .. }) => {
                        // AuthCredHandler::None is invalid with MFAPoll
                        return Err(());
                    }
                    (AuthCredHandler::None, PamAuthRequest::SetupPin { .. }) => {
                        // AuthCredHandler::None is invalid with SetupPin
                        return Err(());
                    }
                    (AuthCredHandler::None, PamAuthRequest::Fido { .. }) => {
                        // AuthCredHandler::None is invalid with Fido
                        return Err(());
                    }
                    (AuthCredHandler::None, PamAuthRequest::FidoUnavailable) => {
                        return Err(());
                    }
                    (AuthCredHandler::PasswordFirst { .. }, _) => {
                        // AuthCredHandler::PasswordFirst with anything other than
                        // PamAuthRequest::Password is invalid.
                        return Err(());
                    }
                }
            }
            (&mut AuthSession::InProgress { token: None, .. }, state) => {
                // Can't do much with online/offline auth when there is no token ...
                match state {
                    CacheState::Online => {
                        warn!("Unable to proceed with online auth, no token available");
                    }
                    CacheState::Offline | CacheState::OfflineNextCheck(_) => {
                        warn!("Unable to proceed with offline auth, no token available");
                    }
                }
                Err(IdpError::NotFound {
                    what: "token".to_string(),
                    where_: "AuthSession".to_string(),
                })
            }
            (&mut AuthSession::Success(_), _) | (&mut AuthSession::Denied, _) => {
                Err(IdpError::BadRequest)
            }
        };

        match maybe_err {
            // What did the provider direct us to do next?
            Ok(AuthResult::Success { mut token }) => {
                if self
                    .check_nxset(Some(&token.name), Some(token.gidnumber))
                    .await
                {
                    // Refuse to release the token, it's in the denied set.
                    self.delete_cache_usertoken(token.uuid).await?;
                    *auth_session = AuthSession::Denied;

                    Ok(PamAuthResponse::Unknown)
                } else {
                    trace!("provider authentication success.");
                    let (generation, pending_password) = match &*auth_session {
                        AuthSession::InProgress {
                            cache_generation,
                            pending_password,
                            ..
                        } => (
                            pending_password
                                .as_ref()
                                .map_or(*cache_generation, |(generation, _)| *generation),
                            pending_password.as_ref().map(|(_, cred)| cred.as_str()),
                        ),
                        _ => return Err(()),
                    };
                    if self
                        .set_cache_usertoken_guarded(&mut token, generation, pending_password)
                        .await?
                        == CacheUpdateResult::IdentityChanged
                    {
                        // Success(name) would let the old session sign in as the
                        // replacement identity even if no cache write occurred.
                        *auth_session = AuthSession::Denied;
                        return Ok(PamAuthResponse::Denied(
                            "Account identity changed during authentication; sign in again."
                                .to_string(),
                        ));
                    }
                    *auth_session = AuthSession::Success(token.spn);

                    Ok(PamAuthResponse::Success)
                }
            }
            Ok(AuthResult::Denied(msg)) => {
                *auth_session = AuthSession::Denied;
                Ok(PamAuthResponse::Denied(msg))
            }
            Ok(AuthResult::Next(req)) => Ok(req.into()),
            Err(IdpError::NotFound { what, where_ }) => Ok(PamAuthResponse::InitDenied {
                msg: format!("NotFound: {} in {}", what, where_),
            }),
            Err(e) => {
                error!("{:?}", e);
                Err(())
            }
        }
    }

    /// One-shot PIN-based unseal. Every invocation validates the PIN and
    /// restores valid cached SSO material through a dedicated provider path.
    /// An expired Entra PRT is renewed with the Hello key when the provider is
    /// online. A cached user record is refreshed online only when cache_timeout
    /// has elapsed.
    pub async fn pam_try_unseal(&self, account_id: &str, cred: &str) -> Result<bool, ()> {
        let id = Id::Name(account_id.to_string());
        let (expired, token) = self.get_cached_usertoken(&id).await?;
        let Some(token) = token else {
            debug!("pam_try_unseal: no cached user token");
            return Ok(false);
        };

        let state = self.get_cachestate(Some(account_id)).await;
        let online_at_init = self.test_connection_for_state(state).await;

        let mut hsm_lock = self.hsm.lock().await;
        let mut dbtxn = self.db.write().await;
        let unseal_result = self
            .client
            .unix_user_try_unseal(
                account_id,
                cred,
                &mut dbtxn,
                hsm_lock.deref_mut(),
                &self.machine_key,
                online_at_init,
            )
            .await;

        drop(hsm_lock);
        dbtxn.commit().map_err(|_| ())?;

        match unseal_result {
            Ok(true) => {
                if expired && online_at_init {
                    // This consumes the PRT restored above. Provider failures
                    // fall back to the cached user without extending its
                    // cache_timeout, so a later invocation can retry.
                    if self.refresh_usertoken(&id, Some(token)).await.is_err() {
                        debug!("pam_try_unseal: timed online refresh failed");
                    }
                }
                Ok(true)
            }
            Ok(false) => {
                debug!("pam_try_unseal: PIN auth denied");
                Ok(false)
            }
            Err(e) => {
                debug!("pam_try_unseal: local unseal failed: {:?}", e);
                Ok(false)
            }
        }
    }

    pub async fn pam_account_beginsession(
        &self,
        account_id: &str,
    ) -> Result<Option<HomeDirectoryInfo>, ()> {
        let token = self.get_usertoken(Id::Name(account_id.to_string())).await?;
        Ok(token.as_ref().map(|tok| HomeDirectoryInfo {
            uid: tok.gidnumber,
            gid: tok.real_gidnumber.unwrap_or(tok.gidnumber),
            name: self.token_homedirectory_attr(tok),
            aliases: self
                .token_homedirectory_alias(tok)
                .map(|s| vec![s])
                .unwrap_or_default(),
        }))
    }

    pub async fn test_connection(&self) -> bool {
        let state = self.get_cachestate(None).await;
        self.test_connection_for_state(state).await
    }

    async fn test_connection_for_state(&self, state: CacheState) -> bool {
        match state {
            CacheState::Offline => {
                trace!("Offline -> no change");
                false
            }
            CacheState::OfflineNextCheck(time) => {
                let now = SystemTime::now();
                if now < time {
                    trace!(?time, "Offline -> next check not due");
                    return false;
                }

                let mut hsm_lock = self.hsm.lock().await;

                let res = self.client.check_online(hsm_lock.deref_mut(), now).await;

                drop(hsm_lock);

                res
            }
            CacheState::Online => {
                trace!("Online, no change");
                true
            }
        }
    }
}
