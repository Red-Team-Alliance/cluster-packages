/*
   Unix Azure Entra ID implementation
   Copyright (C) David Mulder <dmulder@samba.org> 2024

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
use super::interface::{
    AuthCacheAction, AuthCredHandler, AuthRequest, AuthResult, CacheState, GroupToken, Id,
    IdProvider, IdpError, UserToken,
};
use crate::auth_handle_mfa_resp;
use crate::config::split_username;
use crate::config::HimmelblauConfig;
use crate::config::IdAttr;
use crate::constants::DEFAULT_APP_ID;
use crate::constants::EDGE_BROWSER_CLIENT_ID;
use crate::constants::ID_MAP_CACHE;
use crate::db::KeyStoreTxn;
use crate::i18n::{tr, tr_fmt};
use crate::idmap_cache::StaticIdCache;
use crate::idprovider::common::build_online_probe_client;
use crate::idprovider::common::flip_displayname_comma;
use crate::idprovider::common::should_block_hello_pin_attempts;
use crate::idprovider::common::KeyType;
use crate::idprovider::common::RefreshCacheEntry;
use crate::idprovider::common::TotpEnrollmentRecord;
use crate::idprovider::common::PRT_REFRESH_AGE;
use crate::idprovider::common::{BadPinCounter, RefreshCache};
use crate::idprovider::interface::{tpm, UserTokenState};
use crate::idprovider::openidconnect::OidcProvider;
use crate::reserved_ids::{is_systemd_dynamic_id, SYSTEMD_DYNAMIC_ID_MAX, SYSTEMD_DYNAMIC_ID_MIN};
use crate::tpm::confidential_client_creds;
use crate::unix_passwd::parse_etc_passwd;
use crate::unix_proto::PamAuthRequest;
use crate::user_map::UserMap;
use crate::{
    check_hello_totp_enabled, check_hello_totp_setup, entra_id_prt_token_fetch,
    entra_id_refresh_token_token_fetch, extract_base_url, handle_hello_bad_pin_count,
    impl_change_auth_token, impl_check_online, impl_create_decoupled_hello_key,
    impl_handle_hello_pin_totp_auth, impl_himmelblau_hello_key_helpers,
    impl_himmelblau_offline_auth_init, impl_himmelblau_offline_auth_step,
    impl_himmelblau_try_unseal, impl_offline_break_glass, impl_provision_hello_key,
    impl_provision_or_create_hello_key, impl_setup_hello_totp, impl_unix_user_access,
    load_cached_prt, load_cached_prt_for_try_unseal, seal_prt_with_existing_hello_key,
};
use anyhow::{anyhow, Result};
use async_trait::async_trait;
use himmelblau::auth::{
    BrokerClientApplication, PublicClientApplication, UserToken as UnixUserToken, BROKER_APP_ID,
};
use himmelblau::discovery::EnrollAttrs;
use himmelblau::error::{MsalError, DEVICE_AUTH_FAIL};
use himmelblau::graph::UserObject;
use himmelblau::graph::{DirectoryObject, Graph};
use himmelblau::intune::{fetch_intune_portal_versions, IntuneForLinux};
use himmelblau::{AuthOption, MFAAuthContinue};
use himmelblau::{ClientToken, ConfidentialClientApplication};
use idmap::{AadSid, Idmap};
use kanidm_hsm_crypto::{
    structures::LoadableMsDeviceEnrolmentKey, structures::LoadableMsHelloKey,
    structures::LoadableMsOapxbcRsaKey, structures::SealedData, PinValue,
};
use libkrimes::proto::KerberosCredentials;
use rand::RngExt;
use reqwest::Url;
use std::collections::HashMap;
use std::sync::Arc;
use std::thread::sleep;
use std::time::Duration;
use std::time::SystemTime;
use tokio::sync::{broadcast, Mutex, OnceCell};
use totp_rs::{Algorithm, Secret, TOTP};
use uuid::Uuid;
use zeroize::Zeroizing;

fn local_user_ids_from_passwd(contents: &[u8], username: &str) -> Option<(u32, u32)> {
    contents
        .split(|byte| *byte == b'\n')
        .filter_map(|line| parse_etc_passwd(line).ok())
        .flatten()
        .find(|user| user.name == username && !user.name.starts_with(['+', '-']))
        .map(|user| (user.uid, user.gid))
}

// AADSTS65002: Consent between first party application and resource is required.
// This occurs when a tenant has not granted consent for an application to access
// the Graph API. When this happens, we should gracefully fallback and continue
// authentication without group name resolution.
const CONSENT_REQUIRED: u32 = 65002;
// AADSTS50125: PasswordResetRegistrationRequiredInterrupt
const PASSWORD_RESET_REGISTRATION_REQUIRED: u32 = 50125;
// AADSTS50072/50074/50076: Strong auth/MFA is required for this request.
const MFA_REQUIRED_FOR_ENROLLMENT: [u32; 3] = [50072, 50074, 50076];
// AADSTS90055: TenantThrottlingError - There are too many incoming requests.
const THROTTLING_ERROR: u32 = 90055;
// AADSTS90006: ExternalServerRetryableError - The service is temporarily unavailable.
const RETRYABLE_ERROR: u32 = 90006;

fn is_unavailable_mfa_method_error(msg: &str, requested_method: &str) -> bool {
    let expected_prefix =
        format!("Requested MFA method '{requested_method}' not available. Available methods: ");
    msg.starts_with(&expected_prefix)
}

fn mfa_flow_uses_push_hint(flow: &MFAAuthContinue) -> bool {
    flow.get_default_mfa_method_details()
        .map(|method| {
            matches!(
                method.auth_method_id.as_str(),
                "PhoneAppNotification" | "CompanionAppsNotification"
            )
        })
        .unwrap_or(false)
}

fn is_mfa_required_for_enrollment(e: &MsalError) -> bool {
    match e {
        MsalError::AcquireTokenFailed(resp) => resp
            .error_codes
            .iter()
            .any(|code| MFA_REQUIRED_FOR_ENROLLMENT.contains(code)),
        MsalError::AADSTSError(aadsts_err) => {
            MFA_REQUIRED_FOR_ENROLLMENT.contains(&aadsts_err.code)
        }
        MsalError::MFARequired => true,
        _ => false,
    }
}

fn password_change_required(
    cred_handler: &mut AuthCredHandler,
    old_cred: String,
) -> (AuthResult, AuthCacheAction) {
    *cred_handler = AuthCredHandler::ChangePassword { old_cred };
    (
        AuthResult::Next(AuthRequest::ChangePassword {
            msg: tr("Update your password\nYou need to update your password because this is\nthe first time you are signing in, or because your\npassword has expired."),
        }),
        AuthCacheAction::None,
    )
}

/// Convert an MsalError to a short, user-friendly message for PAM display.
/// This intentionally ignores the internal string contents of error variants
/// to avoid leaking verbose or sensitive information to the user.
fn msal_error_to_user_message(e: &MsalError) -> String {
    match e {
        MsalError::InvalidJson(_)
        | MsalError::InvalidBase64(_)
        | MsalError::InvalidParse(_)
        | MsalError::InvalidRegex(_)
        | MsalError::FormatError(_) => tr("Authentication failed: Invalid server response."),
        MsalError::AcquireTokenFailed(error_response) => {
            if error_response
                .error_codes
                .contains(&PASSWORD_RESET_REGISTRATION_REQUIRED)
            {
                return tr("Password reset registration required. Complete setup at https://aka.ms/ssprsetup from another device, then try again.");
            }
            // This case is typically handled separately with error_description,
            // but provide a fallback if it reaches this function.
            error_response.error_description.to_string()
        }
        MsalError::RequestFailed(_) => {
            tr("Authentication failed: Unable to reach authentication server.")
        }
        MsalError::AuthTypeUnsupported => {
            tr("Authentication failed: Authentication method not supported.")
        }
        MsalError::TPMFail(_) => tr("Authentication failed: Security hardware error."),
        MsalError::URLFormatFailed(_) => tr("Authentication failed: Configuration error."),
        MsalError::DeviceEnrollmentFail(_) => {
            tr("Device enrollment failed. Please contact your administrator.")
        }
        MsalError::CryptoFail(_) => tr("Authentication failed: Cryptographic error."),
        MsalError::ConfigError(_) => tr("Authentication failed: Configuration error."),
        MsalError::MFAPollContinue => {
            // This is an internal state, should not reach the user.
            tr("Authentication in progress.")
        }
        MsalError::AADSTSError(aadsts_err) => {
            if aadsts_err.code == PASSWORD_RESET_REGISTRATION_REQUIRED {
                return tr("Password reset registration required. Complete setup at https://aka.ms/ssprsetup from another device, then try again.");
            }
            // AADSTSError has a useful description from Azure AD
            aadsts_err.to_string()
        }
        MsalError::Missing(_) => tr("Authentication failed: Missing required data."),
        MsalError::ChangePassword => {
            // Internal state, should not bubble up to user.
            tr("Password change required. Please contact your administrator.")
        }
        MsalError::PasswordRequired => {
            // Internal state, should not bubble up to user.
            tr("Password entry required.")
        }
        MsalError::ConsentRequested(_) => {
            // Internal state, should not bubble up to user.
            tr("Consent required. Please contact your administrator.")
        }
        MsalError::AuthCodeReceived(_) => {
            // Internal state, should not bubble up to user.
            tr("Authentication in progress.")
        }
        MsalError::MFARequired => {
            // Internal state, should not bubble up to user.
            tr("Multi-factor authentication required.")
        }
        _ => tr("Authentication failed. Please contact your administrator."),
    }
}

#[allow(clippy::large_enum_variant)]
enum Providers {
    Oidc(OidcProvider),
    Himmelblau(HimmelblauProvider),
}

pub struct HimmelblauMultiProvider {
    config: Arc<Mutex<HimmelblauConfig>>,
    providers: Arc<Mutex<HashMap<String, Arc<Providers>>>>,
}

impl HimmelblauMultiProvider {
    pub async fn new<D: KeyStoreTxn + Send>(
        config_filename: &str,
        keystore: &mut D,
    ) -> Result<Self> {
        let config = match HimmelblauConfig::new(Some(config_filename)) {
            Ok(config) => Arc::new(Mutex::new(config)),
            Err(e) => return Err(anyhow!("{}", e)),
        };
        let idmap = match Idmap::new() {
            Ok(idmap) => Arc::new(Mutex::new(idmap)),
            Err(e) => return Err(anyhow!("{:?}", e)),
        };

        let providers = HashMap::new();
        let domains = config.lock().await.get_configured_domains();
        if domains.is_empty() {
            warn!("No domains configured in himmelblau.conf.");
        }

        let providers = HimmelblauMultiProvider {
            config: config.clone(),
            providers: Arc::new(Mutex::new(providers)),
        };

        let oidc_issuer_url = config.lock().await.get_oidc_issuer_url();
        if oidc_issuer_url.is_none() {
            for domain in domains {
                debug!("Adding provider for domain {}", domain);
                let (authority_host, tenant_id, graph_url, odc_provider, app_id, ip_versions) = {
                    let cfg = config.lock().await;
                    (
                        cfg.get_authority_host(&domain),
                        cfg.get_tenant_id(&domain),
                        cfg.get_graph_url(&domain),
                        cfg.get_odc_provider(&domain),
                        cfg.get_app_id(&domain),
                        cfg.get_ip_versions(),
                    )
                };
                let request_timeout = config.lock().await.get_request_timeout();
                let graph = match Graph::new(
                    &odc_provider,
                    &domain,
                    Some(&authority_host),
                    tenant_id.as_deref(),
                    graph_url.as_deref(),
                    Duration::from_secs(request_timeout),
                    &ip_versions,
                )
                .await
                {
                    Ok(graph) => graph,
                    Err(e) => {
                        error!("Failed initializing provider: {:?}", e);
                        continue;
                    }
                };
                let app = BrokerClientApplication::new(
                    None,
                    app_id.as_deref(),
                    None,
                    None,
                    Duration::from_secs(request_timeout),
                    &ip_versions,
                )
                .map_err(|e| {
                    error!("Failed initializing provider: {:?}", e);
                    anyhow!("{:?}", e)
                })?;
                let provider = HimmelblauProvider::new(app, &config, &domain, graph, &idmap)
                    .map_err(|e| {
                        error!("Failed to initialize the provider: {:?}", e);
                        anyhow!("Failed to initialize the provider")
                    })?;
                {
                    // A client write lock is required here.
                    let mut client = provider.client.lock().await;
                    if let Ok(transport_key) =
                        provider.fetch_loadable_transport_key_from_keystore(keystore)
                    {
                        client.set_transport_key(transport_key);
                    }
                    if let Ok(cert_key) = provider.fetch_loadable_cert_key_from_keystore(keystore) {
                        client.set_cert_key(cert_key);
                    }
                }
                providers.providers.lock().await.insert(
                    domain.to_string(),
                    Arc::new(Providers::Himmelblau(provider)),
                );
            }
        } else {
            // Add the oidc provider, if present
            let provider = OidcProvider::new(&config, "oidc", &idmap).map_err(|e| {
                error!("Failed initializing OIDC provider: {:?}", e);
                anyhow!("{:?}", e)
            })?;

            providers
                .providers
                .lock()
                .await
                .insert("oidc".to_string(), Arc::new(Providers::Oidc(provider)));
        }
        if providers.providers.lock().await.is_empty() {
            return Err(anyhow!("No provider was configured!"));
        }

        // Spawn periodic cookie clearing loop (Fixes bugs #591 and #491)
        let providers_ref = providers.providers.clone();
        tokio::spawn(async move {
            loop {
                tokio::time::sleep(std::time::Duration::from_secs(12 * 60 * 60)).await;
                let providers: Vec<_> = providers_ref.lock().await.values().cloned().collect();
                for provider in providers {
                    match provider.as_ref() {
                        Providers::Oidc(_) => {}
                        Providers::Himmelblau(provider) => {
                            let app = provider.client.lock().await;
                            app.clear_cookies();
                        }
                    }
                }
            }
        });

        Ok(providers)
    }

    async fn find_provider(&self, domain: &str) -> Result<Arc<Providers>, IdpError> {
        if let Some(provider) = self.providers.lock().await.get(domain).cloned() {
            return Ok(provider);
        }

        let primary_domain = {
            let mut cfg = self.config.lock().await;
            cfg.get_primary_domain_from_alias(domain).await
        };

        if let Some(domain) = primary_domain {
            /* NEVER introduce a new tenant here: Advisory GHSA-q746-m2wv-qh4v */
            if let Some(provider) = self.providers.lock().await.get(&domain).cloned() {
                return Ok(provider);
            }
        }

        Err(IdpError::NotFound {
            what: format!("domain: {}", domain),
            where_: "providers".to_string(),
        })
    }
}

macro_rules! idp_get_domain_for_account {
    ($hmp:ident, $account_id:expr) => {{
        let oidc_issuer_url = $hmp.config.lock().await.get_oidc_issuer_url();
        if oidc_issuer_url.is_some() {
            Ok("oidc")
        } else {
            match split_username($account_id) {
                Some((_sam, domain)) => Ok(domain),
                None => {
                    debug!("Authentication ignored for local user");
                    Err(IdpError::NotFound {
                        what: "domain".to_string(),
                        where_: format!("account_id: {}", $account_id),
                    })
                }
            }
        }
    }};
}

#[async_trait]
impl IdProvider for HimmelblauMultiProvider {
    async fn offline_break_glass(&self, ttl: Option<u64>) -> Result<(), IdpError> {
        let providers: Vec<_> = self.providers.lock().await.values().cloned().collect();
        for provider in providers {
            match provider.as_ref() {
                Providers::Oidc(provider) => provider.offline_break_glass(ttl).await?,
                Providers::Himmelblau(provider) => {
                    provider.offline_break_glass(ttl).await?;
                }
            }
        }
        Ok(())
    }

    /* TODO: Kanidm should be modified to provide the account_id to
     * provider_authenticate, so that we can test the correct provider here.
     * Currently we go offline if ANY provider is down, which could be
     * incorrect. */
    async fn check_online(&self, tpm: &mut tpm::provider::BoxedDynTpm, now: SystemTime) -> bool {
        let providers: Vec<_> = self.providers.lock().await.values().cloned().collect();
        for provider in providers {
            match provider.as_ref() {
                Providers::Oidc(provider) => {
                    if !provider.check_online(tpm, now).await {
                        return false;
                    }
                }
                Providers::Himmelblau(provider) => {
                    if !provider.check_online(tpm, now).await {
                        return false;
                    }
                }
            }
        }
        true
    }

    async fn unix_user_access<D: KeyStoreTxn + Send>(
        &self,
        id: &Id,
        scopes: Vec<String>,
        old_token: Option<&UserToken>,
        client_id: Option<String>,
        redirect_uri: Option<String>,
        req_cnf: Option<String>,
        keystore: &mut D,
        tpm: &mut tpm::provider::BoxedDynTpm,
        machine_key: &tpm::structures::StorageKey,
    ) -> Result<UnixUserToken, IdpError> {
        let account_id = match old_token {
            Some(token) => token.spn.clone(),
            None => id.to_string().clone(),
        };
        let domain = idp_get_domain_for_account!(self, &account_id)?;
        let provider = self.find_provider(domain).await?;

        match provider.as_ref() {
            Providers::Oidc(provider) => {
                provider
                    .unix_user_access(
                        id,
                        scopes,
                        old_token,
                        client_id,
                        redirect_uri,
                        req_cnf,
                        keystore,
                        tpm,
                        machine_key,
                    )
                    .await
            }
            Providers::Himmelblau(provider) => {
                provider
                    .unix_user_access(
                        id,
                        scopes,
                        old_token,
                        client_id,
                        redirect_uri,
                        req_cnf,
                        keystore,
                        tpm,
                        machine_key,
                    )
                    .await
            }
        }
    }

    async fn unix_user_tgts<D: KeyStoreTxn + Send>(
        &self,
        id: &Id,
        old_token: Option<&UserToken>,
        keystore: &mut D,
        tpm: &mut tpm::provider::BoxedDynTpm,
        machine_key: &tpm::structures::StorageKey,
    ) -> (
        Option<Box<KerberosCredentials>>,
        Option<Box<KerberosCredentials>>,
        Option<String>,
        Option<String>,
    ) {
        let account_id = match old_token {
            Some(token) => token.spn.clone(),
            None => id.to_string().clone(),
        };
        let empty = (None, None, None, None);
        let Ok(domain) = idp_get_domain_for_account!(self, &account_id) else {
            return empty;
        };

        let Ok(provider) = self.find_provider(domain).await else {
            return empty;
        };

        match provider.as_ref() {
            Providers::Oidc(provider) => {
                provider
                    .unix_user_tgts(id, old_token, keystore, tpm, machine_key)
                    .await
            }
            Providers::Himmelblau(provider) => {
                provider
                    .unix_user_tgts(id, old_token, keystore, tpm, machine_key)
                    .await
            }
        }
    }

    async fn unix_user_prt_cookie<D: KeyStoreTxn + Send>(
        &self,
        id: &Id,
        old_token: Option<&UserToken>,
        sso_nonce: Option<&str>,
        keystore: &mut D,
        tpm: &mut tpm::provider::BoxedDynTpm,
        machine_key: &tpm::structures::StorageKey,
    ) -> Result<String, IdpError> {
        let account_id = match old_token {
            Some(token) => token.spn.clone(),
            None => id.to_string().clone(),
        };
        let domain = idp_get_domain_for_account!(self, &account_id)?;
        let provider = self.find_provider(domain).await?;

        match provider.as_ref() {
            Providers::Oidc(provider) => {
                provider
                    .unix_user_prt_cookie(id, old_token, sso_nonce, keystore, tpm, machine_key)
                    .await
            }
            Providers::Himmelblau(provider) => {
                provider
                    .unix_user_prt_cookie(id, old_token, sso_nonce, keystore, tpm, machine_key)
                    .await
            }
        }
    }

    async fn change_auth_token<D: KeyStoreTxn + Send>(
        &self,
        account_id: &str,
        token: &UnixUserToken,
        new_tok: &str,
        keystore: &mut D,
        tpm: &mut tpm::provider::BoxedDynTpm,
        machine_key: &tpm::structures::StorageKey,
    ) -> Result<bool, IdpError> {
        let domain = idp_get_domain_for_account!(self, account_id)?;
        let provider = self.find_provider(domain).await?;

        match provider.as_ref() {
            Providers::Oidc(provider) => {
                provider
                    .change_auth_token(account_id, token, new_tok, keystore, tpm, machine_key)
                    .await
            }
            Providers::Himmelblau(provider) => {
                provider
                    .change_auth_token(account_id, token, new_tok, keystore, tpm, machine_key)
                    .await
            }
        }
    }

    async fn unix_user_get<D: KeyStoreTxn + Send>(
        &self,
        id: &Id,
        old_token: Option<&UserToken>,
        keystore: &mut D,
        tpm: &mut tpm::provider::BoxedDynTpm,
        machine_key: &tpm::structures::StorageKey,
    ) -> Result<UserTokenState, IdpError> {
        /* AAD doesn't permit user listing (must use cache entries from auth) */
        let account_id = match old_token {
            Some(token) => token.spn.clone(),
            None => id.to_string().clone(),
        };
        let domain = idp_get_domain_for_account!(self, &account_id)?;
        let provider = self.find_provider(domain).await?;

        match provider.as_ref() {
            Providers::Oidc(provider) => {
                provider
                    .unix_user_get(id, old_token, keystore, tpm, machine_key)
                    .await
            }
            Providers::Himmelblau(provider) => {
                provider
                    .unix_user_get(id, old_token, keystore, tpm, machine_key)
                    .await
            }
        }
    }

    async fn unix_user_online_auth_init<D: KeyStoreTxn + Send>(
        &self,
        account_id: &str,
        token: Option<&UserToken>,
        service: &str,
        no_hello_pin: bool,
        force_reauth: bool,
        keystore: &mut D,
        tpm: &mut tpm::provider::BoxedDynTpm,
        machine_key: &tpm::structures::StorageKey,
        shutdown_rx: &broadcast::Receiver<()>,
    ) -> Result<(AuthRequest, AuthCredHandler), IdpError> {
        let domain = idp_get_domain_for_account!(self, account_id)?;
        let provider = self.find_provider(domain).await?;

        match provider.as_ref() {
            Providers::Oidc(provider) => {
                provider
                    .unix_user_online_auth_init(
                        account_id,
                        token,
                        service,
                        no_hello_pin,
                        force_reauth,
                        keystore,
                        tpm,
                        machine_key,
                        shutdown_rx,
                    )
                    .await
            }
            Providers::Himmelblau(provider) => {
                provider
                    .unix_user_online_auth_init(
                        account_id,
                        token,
                        service,
                        no_hello_pin,
                        force_reauth,
                        keystore,
                        tpm,
                        machine_key,
                        shutdown_rx,
                    )
                    .await
            }
        }
    }

    async fn unix_user_online_auth_step<D: KeyStoreTxn + Send>(
        &self,
        account_id: &str,
        old_token: &UserToken,
        service: &str,
        no_hello_pin: bool,
        cred_handler: &mut AuthCredHandler,
        pam_next_req: PamAuthRequest,
        keystore: &mut D,
        tpm: &mut tpm::provider::BoxedDynTpm,
        machine_key: &tpm::structures::StorageKey,
        shutdown_rx: &broadcast::Receiver<()>,
    ) -> Result<(AuthResult, AuthCacheAction), IdpError> {
        let domain = idp_get_domain_for_account!(self, account_id)?;
        let provider = self.find_provider(domain).await?;

        match provider.as_ref() {
            Providers::Oidc(provider) => {
                provider
                    .unix_user_online_auth_step(
                        account_id,
                        old_token,
                        service,
                        no_hello_pin,
                        cred_handler,
                        pam_next_req,
                        keystore,
                        tpm,
                        machine_key,
                        shutdown_rx,
                    )
                    .await
            }
            Providers::Himmelblau(provider) => {
                provider
                    .unix_user_online_auth_step(
                        account_id,
                        old_token,
                        service,
                        no_hello_pin,
                        cred_handler,
                        pam_next_req,
                        keystore,
                        tpm,
                        machine_key,
                        shutdown_rx,
                    )
                    .await
            }
        }
    }

    async fn unix_user_offline_auth_init<D: KeyStoreTxn + Send>(
        &self,
        account_id: &str,
        token: Option<&UserToken>,
        service: &str,
        no_hello_pin: bool,
        keystore: &mut D,
    ) -> Result<(AuthRequest, AuthCredHandler), IdpError> {
        let domain = idp_get_domain_for_account!(self, account_id)?;
        let provider = self.find_provider(domain).await?;

        match provider.as_ref() {
            Providers::Oidc(provider) => {
                provider
                    .unix_user_offline_auth_init(account_id, token, service, no_hello_pin, keystore)
                    .await
            }
            Providers::Himmelblau(provider) => {
                provider
                    .unix_user_offline_auth_init(account_id, token, service, no_hello_pin, keystore)
                    .await
            }
        }
    }

    async fn unix_user_offline_auth_step<D: KeyStoreTxn + Send>(
        &self,
        account_id: &str,
        token: &UserToken,
        cred_handler: &mut AuthCredHandler,
        pam_next_req: PamAuthRequest,
        keystore: &mut D,
        tpm: &mut tpm::provider::BoxedDynTpm,
        machine_key: &tpm::structures::StorageKey,
        online_at_init: bool,
    ) -> Result<AuthResult, IdpError> {
        let domain = idp_get_domain_for_account!(self, account_id)?;
        let provider = self.find_provider(domain).await?;

        match provider.as_ref() {
            Providers::Oidc(provider) => {
                provider
                    .unix_user_offline_auth_step(
                        account_id,
                        token,
                        cred_handler,
                        pam_next_req,
                        keystore,
                        tpm,
                        machine_key,
                        online_at_init,
                    )
                    .await
            }
            Providers::Himmelblau(provider) => {
                provider
                    .unix_user_offline_auth_step(
                        account_id,
                        token,
                        cred_handler,
                        pam_next_req,
                        keystore,
                        tpm,
                        machine_key,
                        online_at_init,
                    )
                    .await
            }
        }
    }

    async fn unix_user_try_unseal<D: KeyStoreTxn + Send>(
        &self,
        account_id: &str,
        cred: &str,
        keystore: &mut D,
        tpm: &mut tpm::provider::BoxedDynTpm,
        machine_key: &tpm::structures::StorageKey,
        online: bool,
    ) -> Result<bool, IdpError> {
        let domain = idp_get_domain_for_account!(self, account_id)?;
        let provider = self.find_provider(domain).await?;

        match provider.as_ref() {
            Providers::Oidc(provider) => {
                provider
                    .unix_user_try_unseal(account_id, cred, keystore, tpm, machine_key, online)
                    .await
            }
            Providers::Himmelblau(provider) => {
                provider
                    .unix_user_try_unseal(account_id, cred, keystore, tpm, machine_key, online)
                    .await
            }
        }
    }

    async fn unix_group_get(
        &self,
        _id: &Id,
        _tpm: &mut tpm::provider::BoxedDynTpm,
    ) -> Result<GroupToken, IdpError> {
        /* AAD doesn't permit group listing (must use cache entries from auth) */
        debug!("Group fetching not supported for HimmelblauMultiProvider");
        Err(IdpError::BadRequest)
    }

    async fn get_cachestate<D: KeyStoreTxn + Send>(
        &self,
        account_id: Option<&str>,
        keystore: &mut D,
    ) -> CacheState {
        match account_id {
            Some(account_id) => match idp_get_domain_for_account!(self, account_id) {
                Ok(domain) => match self.find_provider(domain).await {
                    Ok(provider) => match provider.as_ref() {
                        Providers::Oidc(provider) => {
                            return provider.get_cachestate(Some(account_id), keystore).await
                        }
                        Providers::Himmelblau(provider) => {
                            return provider.get_cachestate(Some(account_id), keystore).await
                        }
                    },
                    Err(..) => return CacheState::Offline,
                },
                Err(..) => return CacheState::Offline,
            },
            None => {
                let providers: Vec<_> = self.providers.lock().await.values().cloned().collect();
                for provider in providers {
                    match provider.as_ref() {
                        Providers::Oidc(provider) => {
                            match provider.get_cachestate(None, keystore).await {
                                CacheState::Offline => return CacheState::Offline,
                                CacheState::OfflineNextCheck(time) => {
                                    return CacheState::OfflineNextCheck(time)
                                }
                                _ => continue,
                            }
                        }
                        Providers::Himmelblau(provider) => {
                            match provider.get_cachestate(None, keystore).await {
                                CacheState::Offline => return CacheState::Offline,
                                CacheState::OfflineNextCheck(time) => {
                                    return CacheState::OfflineNextCheck(time)
                                }
                                _ => continue,
                            }
                        }
                    }
                }
            }
        }
        CacheState::Online
    }

    async fn export_broker_prts(&self) -> Result<Vec<u8>, serde_json::Error> {
        let providers: Vec<_> = self
            .providers
            .lock()
            .await
            .iter()
            .map(|(domain, provider)| (domain.clone(), provider.clone()))
            .collect();
        let mut all: HashMap<String, Vec<u8>> = HashMap::new();
        for (domain, provider) in providers {
            if let Providers::Himmelblau(p) = provider.as_ref() {
                let data = p.export_broker_prts().await?;
                all.insert(domain, data);
            }
        }
        serde_json::to_vec(&all)
    }

    async fn import_broker_prts(&self, data: &[u8]) -> Result<(), serde_json::Error> {
        let all: HashMap<String, Vec<u8>> = serde_json::from_slice(data)?;
        let providers = self.providers.lock().await.clone();
        for (domain, blob) in &all {
            if let Some(provider) = providers.get(domain) {
                let Providers::Himmelblau(p) = provider.as_ref() else {
                    continue;
                };
                if let Err(e) = p.import_broker_prts(blob).await {
                    tracing::warn!("Failed to import PRTs for domain {}: {:?}", domain, e);
                }
            }
        }
        Ok(())
    }
}

// If the provider is offline, we need to backoff and wait a bit.
const OFFLINE_NEXT_CHECK: Duration = Duration::from_secs(15);

pub struct HimmelblauProvider {
    state: Mutex<CacheState>,
    client: Mutex<BrokerClientApplication>,
    config: Arc<Mutex<HimmelblauConfig>>,
    domain: String,
    graph: Graph,
    refresh_cache: RefreshCache,
    idmap: Arc<Mutex<Idmap>>,
    init: OnceCell<()>,
    bad_pin_counter: BadPinCounter,
}

impl HimmelblauProvider {
    pub fn new(
        client: BrokerClientApplication,
        config: &Arc<Mutex<HimmelblauConfig>>,
        domain: &str,
        graph: Graph,
        idmap: &Arc<Mutex<Idmap>>,
    ) -> Result<Self, IdpError> {
        Ok(HimmelblauProvider {
            state: Mutex::new(CacheState::OfflineNextCheck(SystemTime::now())),
            client: Mutex::new(client),
            config: config.clone(),
            domain: domain.to_string(),
            graph,
            refresh_cache: RefreshCache::new(),
            idmap: idmap.clone(),
            init: OnceCell::new(),
            bad_pin_counter: BadPinCounter::new(),
        })
    }

    /// Export PRT entries for FD store persistence.
    pub async fn export_broker_prts(&self) -> Result<Vec<u8>, serde_json::Error> {
        self.refresh_cache.export_broker_prts().await
    }

    /// Import PRT entries from FD store data.
    pub async fn import_broker_prts(&self, data: &[u8]) -> Result<(), serde_json::Error> {
        self.refresh_cache.import_broker_prts(data).await
    }

    async fn domains_are_aliases(&self, domain1: &str, domain2: &str) -> bool {
        let mut cfg = self.config.lock().await;
        cfg.domains_are_aliases(domain1, domain2).await
    }

    /// Initiate MFA flow with automatic fallback if the requested method is unavailable.
    /// If a specific MFA method is requested but not available, this will automatically
    /// retry with no method specified (allowing Azure to choose the default).
    async fn initiate_mfa_flow_with_fallback(
        &self,
        account_id: &str,
        password: Option<&str>,
        auth_options: &[AuthOption],
        auth_init: Option<himmelblau::auth::AuthInit>,
        mfa_method: Option<String>,
    ) -> Result<himmelblau::auth::MFAAuthContinue, MsalError> {
        let result = self
            .client
            .lock()
            .await
            .initiate_acquire_token_by_mfa_flow_for_device_enrollment(
                account_id,
                password,
                auth_options,
                auth_init.clone(),
                mfa_method.as_deref(),
            )
            .await;

        match result {
            Ok(flow) => Ok(flow),
            Err(MsalError::GeneralFailure(ref msg))
                if mfa_method
                    .as_deref()
                    .map(|method| is_unavailable_mfa_method_error(msg, method))
                    .unwrap_or(false) =>
            {
                // Requested MFA method not available, fall back to default
                warn!("{} Retrying with default MFA method.", msg);
                self.client
                    .lock()
                    .await
                    .initiate_acquire_token_by_mfa_flow_for_device_enrollment(
                        account_id,
                        password,
                        auth_options,
                        auth_init,
                        None, // Retry without specifying MFA method
                    )
                    .await
            }
            Err(e) => Err(e),
        }
    }
}

enum TokenOrObj {
    UserToken(Box<UnixUserToken>),
    UserObj((ClientToken, UserObject)),
}

macro_rules! check_new_device_enrollment_required {
    ($aadsts_err:expr, $self:expr, $keystore:expr) => {{
        if $aadsts_err.error_codes.contains(&(135011 as u32))
            || $aadsts_err.error_codes.contains(&DEVICE_AUTH_FAIL)
        {
            let csr_tag = $self.fetch_cert_key_tag();
            if let Err(e) = $keystore.delete_tagged_hsm_key(&csr_tag) {
                error!("Failed to delete CSR key: {:?}", e);
                return Ok((
                    AuthResult::Denied(
                        msal_error_to_user_message(&MsalError::AcquireTokenFailed($aadsts_err))
                            + " "
                            + &tr("Failed to delete CSR key"),
                    ),
                    AuthCacheAction::None,
                ));
            }
            let intune_tag = $self.fetch_intune_key_tag();
            if let Err(e) = $keystore.delete_tagged_hsm_key(&intune_tag) {
                error!("Failed to delete intune key: {:?}", e);
                return Ok((
                    AuthResult::Denied(
                        msal_error_to_user_message(&MsalError::AcquireTokenFailed($aadsts_err))
                            + " "
                            + &tr("Failed to delete intune key"),
                    ),
                    AuthCacheAction::None,
                ));
            }

            return Ok((
                AuthResult::Denied(
                    tr("Device has been removed from the domain.")
                        + " "
                        + &msal_error_to_user_message(&MsalError::AcquireTokenFailed($aadsts_err)),
                ),
                AuthCacheAction::None,
            ));
        }
        return Ok((
            AuthResult::Denied(msal_error_to_user_message(&MsalError::AcquireTokenFailed(
                $aadsts_err,
            ))),
            AuthCacheAction::None,
        ));
    }};
}

fn is_sspr_required(e: &MsalError) -> bool {
    match e {
        MsalError::AcquireTokenFailed(resp) => resp
            .error_codes
            .contains(&PASSWORD_RESET_REGISTRATION_REQUIRED),
        MsalError::AADSTSError(err) => err.code == PASSWORD_RESET_REGISTRATION_REQUIRED,
        _ => false,
    }
}

fn throttle_backoff_delay(attempt: usize) -> Duration {
    let base_ms = match attempt {
        0 => 1_000,
        1 => 3_000,
        _ => 7_000,
    };

    let jitter_ms = rand::rng().random_range(250..=750);

    Duration::from_millis(base_ms + jitter_ms)
}

#[async_trait]
impl IdProvider for HimmelblauProvider {
    async fn offline_break_glass(&self, ttl: Option<u64>) -> Result<(), IdpError> {
        impl_offline_break_glass!(self, ttl)
    }

    #[instrument(level = "debug", skip_all)]
    async fn check_online(&self, tpm: &mut tpm::provider::BoxedDynTpm, now: SystemTime) -> bool {
        impl_check_online!(self, tpm, now)
    }

    #[instrument(skip(
        self,
        id,
        old_token,
        _keystore,
        tpm,
        machine_key,
        redirect_uri,
        req_cnf
    ))]
    async fn unix_user_access<D: KeyStoreTxn + Send>(
        &self,
        id: &Id,
        scopes: Vec<String>,
        old_token: Option<&UserToken>,
        client_id: Option<String>,
        redirect_uri: Option<String>,
        req_cnf: Option<String>,
        _keystore: &mut D,
        tpm: &mut tpm::provider::BoxedDynTpm,
        machine_key: &tpm::structures::StorageKey,
    ) -> Result<UnixUserToken, IdpError> {
        // Opportunistic PRT renewal: if the cached PRT is older than 4 hours,
        // attempt to refresh it before using it for access-token acquisition.
        // Renewal failure is non-fatal, as the existing (stale but still valid)
        // PRT will be used.
        let account_id = match old_token {
            Some(token) => token.spn.clone(),
            None => id.to_string().clone(),
        };
        if let Some(age) = self.refresh_cache.prt_age(&account_id).await {
            if age >= PRT_REFRESH_AGE {
                debug!(
                    "PRT for {} is {:?} old (>= {:?}), attempting renewal",
                    account_id, age, PRT_REFRESH_AGE
                );
                if let Ok(RefreshCacheEntry::Prt(old_prt)) =
                    self.refresh_cache.refresh_token(&account_id).await
                {
                    match self
                        .client
                        .lock()
                        .await
                        .exchange_prt_for_prt(&old_prt, tpm, machine_key, true)
                        .await
                    {
                        Ok(new_prt) => {
                            self.refresh_cache
                                .add(&account_id, &RefreshCacheEntry::Prt(new_prt))
                                .await;
                            info!("Opportunistic PRT renewal succeeded for {}", account_id);
                        }
                        Err(e) => {
                            warn!(
                                "Opportunistic PRT renewal failed for {} (will use existing PRT): {:?}",
                                account_id, e
                            );
                        }
                    }
                }
            }
        }

        impl_unix_user_access!(
            self,
            old_token,
            scopes,
            client_id,
            redirect_uri,
            req_cnf,
            id,
            tpm,
            machine_key,
            entra_id_prt_token_fetch,
            entra_id_refresh_token_token_fetch
        )
    }

    #[instrument(skip_all)]
    async fn unix_user_tgts<D: KeyStoreTxn + Send>(
        &self,
        id: &Id,
        old_token: Option<&UserToken>,
        _keystore: &mut D,
        tpm: &mut tpm::provider::BoxedDynTpm,
        machine_key: &tpm::structures::StorageKey,
    ) -> (
        Option<Box<KerberosCredentials>>,
        Option<Box<KerberosCredentials>>,
        Option<String>,
        Option<String>,
    ) {
        if (self.delayed_init().await).is_err() {
            // We can't fetch krb5 tgts when initialization hasn't
            // completed. This only happens when we're offline during first
            // startup. This should never happen!
            return (None, None, None, None);
        }

        if !self.check_online(tpm, SystemTime::now()).await {
            // We can't fetch krb5 tgts when offline
            return (None, None, None, None);
        }

        let account_id = match old_token {
            Some(token) => token.spn.clone(),
            None => id.to_string().clone(),
        };
        let refresh_cache_entry = match self.refresh_cache.refresh_token(&account_id).await {
            Ok(refresh_cache_entry) => refresh_cache_entry,
            Err(e) => {
                error!(
                    "Failed fetching refresh cache entry for Kerberos CCache: {:?}",
                    e
                );
                return (None, None, None, None);
            }
        };
        let prt = match refresh_cache_entry {
            RefreshCacheEntry::Prt(prt) => prt,
            RefreshCacheEntry::RefreshToken(_) => {
                // We need a PRT to fetch Kerberos CCaches
                return (None, None, None, None);
            }
        };
        let cloud_ccache = self
            .client
            .lock()
            .await
            .fetch_cloud_tgt(&prt, tpm, machine_key)
            .ok();
        let ad_ccache = self
            .client
            .lock()
            .await
            .fetch_ad_tgt(&prt, tpm, machine_key)
            .ok();
        let top_level_names = self
            .client
            .lock()
            .await
            .unseal_prt_kerberos_top_level_names(&prt, tpm, machine_key)
            .ok();
        let tenant_id = match old_token {
            Some(t) => t.tenant_id.map(|u| u.to_string()),
            None => match self.config.lock().await.get_tenant_id(&self.domain) {
                Some(t) => Some(t),
                None => self.graph.tenant_id().await.ok(),
            },
        };

        (cloud_ccache, ad_ccache, top_level_names, tenant_id)
    }

    #[instrument(skip_all)]
    async fn unix_user_prt_cookie<D: KeyStoreTxn + Send>(
        &self,
        id: &Id,
        old_token: Option<&UserToken>,
        sso_nonce: Option<&str>,
        _keystore: &mut D,
        tpm: &mut tpm::provider::BoxedDynTpm,
        machine_key: &tpm::structures::StorageKey,
    ) -> Result<String, IdpError> {
        if (self.delayed_init().await).is_err() {
            // We can't fetch a PRT cookie when initialization hasn't
            // completed. This only happens when we're offline during first
            // startup. This should never happen!
            debug!("Provider not initialized");
            return Err(IdpError::BadRequest);
        }

        /* Use the prt mem cache to generate the sso cookie */
        let account_id = match old_token {
            Some(token) => token.spn.clone(),
            None => id.to_string().clone(),
        };

        // PRTs are persisted via memfd/FileDescriptorStore.
        let prt = match self.refresh_cache.refresh_token(&account_id).await {
            Ok(RefreshCacheEntry::Prt(prt)) => prt,
            _ => {
                debug!("No PRT available in refresh cache");
                return Err(IdpError::NotFound {
                    what: "account_id".to_string(),
                    where_: "refresh_cache".to_string(),
                });
            }
        };

        self.client
            .lock()
            .await
            .acquire_prt_sso_cookie_with_nonce(&prt, sso_nonce, tpm, machine_key)
            .await
            .map_err(|e| {
                error!("Failed to request prt cookie: {:?}", e);
                IdpError::BadRequest
            })
    }

    #[instrument(skip_all)]
    async fn change_auth_token<D: KeyStoreTxn + Send>(
        &self,
        account_id: &str,
        token: &UnixUserToken,
        new_tok: &str,
        keystore: &mut D,
        tpm: &mut tpm::provider::BoxedDynTpm,
        machine_key: &tpm::structures::StorageKey,
    ) -> Result<bool, IdpError> {
        impl_change_auth_token!(
            self,
            account_id,
            token,
            new_tok,
            keystore,
            tpm,
            machine_key,
            token.amr_ngcmfa().map_err(|e| {
                error!("{:?}", e);
                IdpError::NotFound {
                    what: "NGC MFA authorization in UnixUserToken".to_string(),
                    where_: format!("access token ({})", token.token_type),
                }
            })?,
            impl_provision_or_create_hello_key
        )
    }

    #[instrument(skip_all)]
    async fn unix_user_get<D: KeyStoreTxn + Send>(
        &self,
        id: &Id,
        old_token: Option<&UserToken>,
        keystore: &mut D,
        tpm: &mut tpm::provider::BoxedDynTpm,
        machine_key: &tpm::structures::StorageKey,
    ) -> Result<UserTokenState, IdpError> {
        macro_rules! net_down_check {
            ($res:expr, $($pat:pat => $result:expr),*) => {
                match $res {
                    Ok(val) => val,
                    Err(MsalError::RequestFailed(msg)) => {
                        let url = extract_base_url!(msg);
                        info!(?url, "Network down detected");
                        let mut state = self.state.lock().await;
                        *state = CacheState::OfflineNextCheck(SystemTime::now() + OFFLINE_NEXT_CHECK);
                        return Ok(UserTokenState::UseCached)
                    },
                    $($pat => $result),*
                }
            }
        }

        if (self.delayed_init().await).is_err() {
            // Initialization failed. Report that the system is offline. We
            // can't proceed with initialization until the system is online.
            info!("Network down detected");
            let mut state = self.state.lock().await;
            *state = CacheState::OfflineNextCheck(SystemTime::now() + OFFLINE_NEXT_CHECK);
            return Ok(UserTokenState::UseCached);
        }

        if !self.check_online(tpm, SystemTime::now()).await {
            // We are offline, return that we should use a cached token.
            return Ok(UserTokenState::UseCached);
        }

        // Look for common names of local systemd, sssd, etc users, and warn
        // that the nss configuration is possibly incorrect.
        let account_id = match old_token {
            Some(token) => token.spn.clone(),
            None => id.to_string().clone(),
        };
        if let Some((cn, _)) = split_username(&account_id) {
            let other_module_warn_users =
                ["gdm", "sssd", "gnome-initial-setup", "systemd-coredump"];
            if other_module_warn_users.contains(&cn) {
                warn!(
                    "'{}' appears to be a systemd or other local user \
                      account. Please reconfigure your nsswitch.conf to \
                      place himmelblau at the end",
                    cn
                );
            }
        }

        macro_rules! fetch_user_confidential_client {
            ($client_id:expr, $client_credential:expr) => {{
                let (authority_host, tenant_id, ip_versions) = {
                    let cfg = self.config.lock().await;
                    let authority_host = cfg.get_authority_host(&self.domain);
                    let tenant_id = cfg.get_tenant_id(&self.domain).ok_or_else(|| {
                        error!("tenant_id not found");
                        IdpError::BadRequest
                    })?;
                    let ip_versions = cfg.get_ip_versions();
                    (authority_host, tenant_id, ip_versions)
                };
                let authority = format!("https://{}/{}", authority_host, tenant_id);
                let request_timeout = self.config.lock().await.get_request_timeout();
                let app = ConfidentialClientApplication::new(
                    $client_id,
                    Some(&authority),
                    $client_credential,
                    Duration::from_secs(request_timeout),
                    &ip_versions,
                )
                .map_err(|e| {
                    error!(?e, "Failed initializing confidential client");
                    IdpError::BadRequest
                })?;

                match app
                    .acquire_token_silent(
                        vec!["00000003-0000-0000-c000-000000000000/.default"],
                        Some(tpm),
                )
                .await
                {
                    Ok(token) => {
                        match self.graph.request_user(&token.access_token, &account_id).await {
                            Ok(userobj) => {
                                match self
                                    .user_token_from_unix_user_token(
                                        &account_id,
                                        TokenOrObj::UserObj((token, userobj)),
                                        old_token,
                                    )
                                    .await
                                {
                                    Ok(mut token) => {
                                        /* Set the GECOS from the old_token, since MS doesn't
                                         * provide this during a silent acquire
                                         */
                                        if let Some(old_token) = old_token {
                                            token.displayname.clone_from(&old_token.displayname)
                                        }
                                        // App credentials authenticate the directory lookup,
                                        // not this user on the host. Only user authentication
                                        // or a refresh-token-backed result may populate the cache.
                                        return Ok(UserTokenState::LookupOnly(token));
                                    }
                                    Err(e) => {
                                        error!(?e, "Failed to obtain token from user object using confidential client");
                                    }
                                }
                            }
                            Err(e) => {
                                error!(?e, "Failed to acquire user object from graph using confidential client creds");
                            }
                        }
                    }
                    Err(e) => {
                        error!(?e, "Failed to acquire token silently using confidential client");
                    }
                }
            }};
        }

        // If we have ConfidentialClient creds, use those
        if let Ok(Some((client_id, creds))) =
            confidential_client_creds(tpm, keystore, machine_key, &self.domain)
        {
            fetch_user_confidential_client!(&client_id, creds)
        }

        let idmap_cache = StaticIdCache::new(ID_MAP_CACHE, false).map_err(|e| {
            error!("Failed reading from the idmap cache: {:?}", e);
            IdpError::BadRequest
        })?;

        macro_rules! fake_user {
            () => {
                match old_token {
                    // If we have an existing token, keep it without extending
                    // cache_timeout: no online validation succeeded.
                    Some(_) => return Ok(UserTokenState::UseCached),
                    // Otherwise, see if we should fake it
                    None => {
                        let apply_policy = self.config.lock().await.get_apply_policy();
                        let mut auth_options = vec![];
                        if apply_policy {
                            auth_options.push(AuthOption::IntuneEnable);
                        }
                        // This existence probe can report a false positive.
                        // Never cache the locally fabricated identity it
                        // permits us to return.
                        let auth_init = net_down_check!(
                            self.client
                                .lock()
                                .await
                                .check_user_exists(&account_id, &auth_options)
                                .await,
                            Err(e) => {
                                error!("Failed checking if the user exists: {:?}", e);
                                return Err(IdpError::BadRequest);
                            }
                        );
                        if auth_init.try_exists().map_err(|e| {
                            error!(?e, "Failed checking user existence");
                            IdpError::BadRequest
                        })? {
                            // Generate a lookup-only UserToken. Its real UUID
                            // requires a provider-backed token.
                            let id_attr_map = self.config.lock().await.get_id_attr_map();
                            let (uid, gid) = match idmap_cache.get_user_by_name(&account_id) {
                                Some(user) => {
                                    (user.uid, user.gid)
                                },
                                None => match id_attr_map {
                                    IdAttr::Uuid => {
                                        // Attempt to map the UPN to an Object Id.
                                        let sidtoname = self.client
                                            .lock()
                                            .await
                                            .resolve_nametosid(
                                                &account_id,
                                                tpm,
                                                machine_key
                                            )
                                            .await
                                            .map_err(|e| {
                                                error!("Failed mapping UPN to Object Id: {:?}", e);
                                                IdpError::BadRequest
                                            })?;
                                        let sid = AadSid::from_sid_str(&sidtoname.sid).map_err(|e| {
                                            error!("Failed parsing SID: {:?}", e);
                                            IdpError::BadRequest
                                        })?;
                                        let uid = self.idmap.lock().await.object_id_to_unix_id(&self.graph.tenant_id().await.map_err(|e| {
                                            error!("Failed fetching tenant id: {:?}", e);
                                            IdpError::BadRequest
                                        })?, &sid).map_err(|e| {
                                            error!("Failed mapping object id to uid: {:?}", e);
                                            IdpError::BadRequest
                                        })?;
                                        (uid, uid)
                                    },
                                    IdAttr::Name | IdAttr::Rfc2307 => {
                                        let gid = self.idmap.lock().await.gen_to_unix(&self.graph.tenant_id().await.map_err(|e| {
                                            error!("{:?}", e);
                                            IdpError::BadRequest
                                        })?, &account_id).map_err(
                                            |e| {
                                                error!("{:?}", e);
                                                IdpError::BadRequest
                                            },
                                        )?;
                                        (gid, gid)
                                    }
                                },
                            };
                            let fake_uuid = Uuid::new_v4();
                            let groups = vec![GroupToken {
                                name: account_id.clone(),
                                spn: account_id.clone(),
                                uuid: fake_uuid,
                                gidnumber: uid,
                            }];
                            return Ok(UserTokenState::LookupOnly(UserToken {
                                name: account_id.clone(),
                                spn: account_id.clone(),
                                uuid: fake_uuid,
                                real_gidnumber: Some(gid),
                                gidnumber: uid,
                                displayname: "".to_string(),
                                shell: Some(self.config.lock().await.get_shell(Some(&self.domain))),
                                groups,
                                tenant_id: Some(Uuid::parse_str(&self.graph.tenant_id().await.map_err(|e| {
                                        error!("{:?}", e);
                                        IdpError::BadRequest
                                    })?).map_err(|e| {
                                    error!("{:?}", e);
                                    IdpError::BadRequest
                                })?),
                                valid: true,
                            }));
                        } else {
                            // This is the one time we really should return
                            // UserTokenState::NotFound, because this user doesn't exist.
                            return Ok(UserTokenState::NotFound);
                        }
                    }
                }
            };
        }
        let refresh_cache_entry = match self.refresh_cache.refresh_token(&account_id).await {
            Ok(refresh_cache_entry) => refresh_cache_entry,
            Err(_) => fake_user!(),
        };
        // If an app_id is defined in the config, the app should have the
        // GroupMember.Read.All API permission.
        let (client_id, scopes) = if self.config.lock().await.get_app_id(&self.domain).is_some() {
            (None, vec!["GroupMember.Read.All"])
        } else {
            (
                Some(EDGE_BROWSER_CLIENT_ID),
                vec!["https://graph.microsoft.com/.default"],
            )
        };
        let token = match refresh_cache_entry {
            RefreshCacheEntry::Prt(prt) => {
                let mtoken = self
                    .client
                    .lock()
                    .await
                    .exchange_prt_for_access_token(
                        &prt,
                        scopes.clone(),
                        None,
                        client_id,
                        tpm,
                        machine_key,
                        None,
                        None,
                    )
                    .await;
                match mtoken {
                    Ok(val) => val,
                    Err(MsalError::RequestFailed(_)) => {
                        // Retry on network failure, as these can be rather common
                        sleep(Duration::from_millis(500));
                        net_down_check!(
                            self.client
                                .lock()
                                .await
                                .exchange_prt_for_access_token(&prt, scopes, None, client_id, tpm, machine_key, None, None)
                                .await,
                            Err(e) => {
                                error!("{:?}", e);
                                // Never return IdpError::NotFound. This deletes the existing
                                // user from the cache.
                                fake_user!()
                            }
                        )
                    }
                    Err(MsalError::AcquireTokenFailed(err_resp))
                        if err_resp.error_codes.contains(&CONSENT_REQUIRED) =>
                    {
                        /* Consent has not been granted for the application
                         * to access the Graph API. Retry without Graph API
                         * scopes - authentication can still proceed but group
                         * names will not be resolved. */
                        warn!(
                            "Consent not granted for Graph API access. \
                               Retrying token exchange without Graph API scopes."
                        );
                        match self
                            .client
                            .lock()
                            .await
                            .exchange_prt_for_access_token(
                                &prt,
                                vec![],
                                None,
                                None,
                                tpm,
                                machine_key,
                                None,
                                None,
                            )
                            .await
                        {
                            Ok(val) => val,
                            Err(e) => {
                                error!("{:?}", e);
                                // Never return IdpError::NotFound. This deletes the existing
                                // user from the cache.
                                fake_user!()
                            }
                        }
                    }
                    Err(MsalError::AcquireTokenFailed(err_resp))
                        if client_id == Some(EDGE_BROWSER_CLIENT_ID) =>
                    {
                        /* Authentication failed with Edge Browser client ID.
                         * Fall back to default app ID - group names may not
                         * be resolved but authentication can proceed. */
                        info!(
                            "Token acquisition failed with Edge Browser app ({}). \
                             Retrying with default app ID.",
                            err_resp.error_description
                        );
                        match self
                            .client
                            .lock()
                            .await
                            .exchange_prt_for_access_token(
                                &prt,
                                scopes,
                                None,
                                Some(DEFAULT_APP_ID),
                                tpm,
                                machine_key,
                                None,
                                None,
                            )
                            .await
                        {
                            Ok(val) => val,
                            Err(e) => {
                                error!("{:?}", e);
                                // Never return IdpError::NotFound. This deletes the existing
                                // user from the cache.
                                fake_user!()
                            }
                        }
                    }
                    Err(MsalError::AADSTSError(_)) if client_id == Some(EDGE_BROWSER_CLIENT_ID) => {
                        /* AADSTS error with Edge Browser client ID (e.g. CA
                         * policy requiring device compliance). Fall back to
                         * default app ID. */
                        info!(
                            "AADSTS error with Edge Browser app. \
                             Retrying with default app ID."
                        );
                        match self
                            .client
                            .lock()
                            .await
                            .exchange_prt_for_access_token(
                                &prt,
                                scopes,
                                None,
                                Some(DEFAULT_APP_ID),
                                tpm,
                                machine_key,
                                None,
                                None,
                            )
                            .await
                        {
                            Ok(val) => val,
                            Err(e) => {
                                error!("{:?}", e);
                                // Never return IdpError::NotFound. This deletes the existing
                                // user from the cache.
                                fake_user!()
                            }
                        }
                    }
                    Err(e) => {
                        error!("{:?}", e);
                        // Never return IdpError::NotFound. This deletes the existing
                        // user from the cache.
                        fake_user!()
                    }
                }
            }
            RefreshCacheEntry::RefreshToken(refresh_token) => {
                let (ip_versions, request_timeout) = {
                    let cfg = self.config.lock().await;
                    (cfg.get_ip_versions(), cfg.get_request_timeout())
                };
                let client = PublicClientApplication::new(
                    BROKER_APP_ID,
                    None,
                    Duration::from_secs(request_timeout),
                    &ip_versions,
                )
                .map_err(|e| {
                    error!("Failed to create public client application: {:?}", e);
                    IdpError::BadRequest
                })?;
                let mtoken = client
                    .acquire_token_by_refresh_token(&refresh_token, vec![])
                    .await;
                match mtoken {
                    Ok(val) => val,
                    Err(MsalError::RequestFailed(_)) => {
                        // Retry on network failure, as these can be rather common
                        sleep(Duration::from_millis(500));
                        net_down_check!(
                            client
                                .acquire_token_by_refresh_token(
                                    &refresh_token,
                                    vec![],
                                )
                                .await,
                            Err(e) => {
                                error!("{:?}", e);
                                // Never return IdpError::NotFound. This deletes the existing
                                // user from the cache.
                                fake_user!()
                            }
                        )
                    }
                    Err(e) => {
                        error!("{:?}", e);
                        // Never return IdpError::NotFound. This deletes the existing
                        // user from the cache.
                        fake_user!()
                    }
                }
            }
        };
        match self.token_validate(&account_id, &token, old_token).await {
            Ok(AuthResult::Success { mut token }) => {
                /* Set the GECOS from the old_token, since MS doesn't
                 * provide this during a silent acquire
                 */
                if let Some(old_token) = old_token {
                    token.displayname.clone_from(&old_token.displayname)
                }
                Ok(UserTokenState::Update(token))
            }
            // Never return IdpError::NotFound. This deletes the existing
            // user from the cache.
            Ok(AuthResult::Denied(_)) | Ok(AuthResult::Next(_)) => fake_user!(),
            Err(_) => fake_user!(),
        }
    }

    #[instrument(skip(self, account_id, _token, keystore, tpm, _machine_key, _shutdown_rx))]
    async fn unix_user_online_auth_init<D: KeyStoreTxn + Send>(
        &self,
        account_id: &str,
        _token: Option<&UserToken>,
        service: &str,
        no_hello_pin: bool,
        force_reauth: bool,
        keystore: &mut D,
        tpm: &mut tpm::provider::BoxedDynTpm,
        _machine_key: &tpm::structures::StorageKey,
        _shutdown_rx: &broadcast::Receiver<()>,
    ) -> Result<(AuthRequest, AuthCredHandler), IdpError> {
        macro_rules! net_down_check {
            ($res:expr, $($pat:pat => $result:expr),*) => {
                match $res {
                    Ok(val) => val,
                    Err(MsalError::RequestFailed(msg)) => {
                        let url = extract_base_url!(msg);
                        info!(?url, "Network down detected");
                        let mut state = self.state.lock().await;
                        *state = CacheState::OfflineNextCheck(SystemTime::now() + OFFLINE_NEXT_CHECK);
                        return Ok((
                            AuthRequest::InitDenied {
                                msg: "Network outage detected."
                                    .to_string(),
                            },
                            AuthCredHandler::None,
                        ));
                    },
                    $($pat => $result),*
                }
            }
        }

        let hello_key = match self.fetch_hello_key(account_id, keystore) {
            Ok((hello_key, _keytype)) => Some(hello_key),
            Err(_) => None,
        };
        let remote_services = self
            .config
            .lock()
            .await
            .get_password_only_remote_services_deny_list();
        // Check if this is a remote service:
        // - Service starts with "remote:" (set by PAM module when PAM_RHOST is set)
        // - Service name contains any entry from remote_services_deny_list
        let is_remote_service = service.starts_with("remote:")
            || remote_services
                .iter()
                .any(|s| !s.is_empty() && service.contains(s));
        let hello_totp_enabled = check_hello_totp_enabled!(self);
        let console_password_only = self.config.lock().await.get_allow_console_password_only();
        let allow_remote_hello = self.config.lock().await.get_allow_remote_hello();
        // Skip Hello authentication if it is disabled by config
        let hello_enabled = self.config.lock().await.get_enable_hello();
        let hello_pin_retry_count = self.config.lock().await.get_hello_pin_retry_count();
        let intune_enrollment_required =
            self.config.lock().await.get_apply_policy() && !self.is_intune_enrolled(keystore).await;
        if !self.is_domain_joined(keystore).await
            || hello_key.is_none()
            || !hello_enabled
            || (is_remote_service && !hello_totp_enabled && !allow_remote_hello)
            || should_block_hello_pin_attempts(
                self.bad_pin_counter.bad_pin_count(account_id).await,
                hello_pin_retry_count,
            )
            || intune_enrollment_required
            || no_hello_pin
            || force_reauth
        {
            if (self.delayed_init().await).is_err() {
                // Initialization failed. Report that the system is offline. We
                // can't proceed with initialization until the system is online.
                info!("Network down detected");
                let mut state = self.state.lock().await;
                *state = CacheState::OfflineNextCheck(SystemTime::now() + OFFLINE_NEXT_CHECK);
                return Ok((
                    AuthRequest::InitDenied {
                        msg: tr("Network outage detected."),
                    },
                    AuthCredHandler::None,
                ));
            }
            // For remote connections (SSH), force MFA to ensure security.
            // For local terminal authentication (GDM, etc.), don't force MFA
            // to allow natural passwordless flow without prematurely triggering
            // MFA notifications.
            debug!(
                "Service '{}' remote_service={} console_password_only={}",
                service, is_remote_service, console_password_only
            );
            if self.config.lock().await.get_enable_experimental_mfa() {
                let mut auth_options = vec![];
                if self.config.lock().await.get_enable_passwordless() {
                    auth_options.push(AuthOption::Passwordless);
                }
                if !is_remote_service {
                    auth_options.push(AuthOption::Fido);
                    let cfg = self.config.lock().await;
                    if cfg.get_enable_experimental_passwordless_fido() {
                        auth_options.push(AuthOption::PasswordlessFido);
                    }
                    if cfg.get_enable_passwordless_security_key() {
                        auth_options.push(AuthOption::PasswordlessSecurityKey);
                    }
                    if cfg.get_enable_passwordless_qr_bluetooth() {
                        auth_options.push(AuthOption::PasswordlessQrBluetooth);
                    }
                }

                if is_remote_service || !console_password_only {
                    auth_options.push(AuthOption::ForceMFA);
                }
                if is_remote_service {
                    auth_options.push(AuthOption::RemoteSession);
                }
                let apply_policy = self.config.lock().await.get_apply_policy();
                if apply_policy {
                    auth_options.push(AuthOption::IntuneEnable);
                }

                let mut attempts = 0;
                let auth_init = loop {
                    let auth_init_attempt = net_down_check!(
                        self.client
                            .lock()
                            .await
                            .check_user_exists(account_id, &auth_options)
                            .await,
                        Err(e) => {
                            error!("{:?}", e);
                            return Err(IdpError::BadRequest);
                        }
                    );
                    let delay = throttle_backoff_delay(attempts);
                    attempts += 1;
                    match auth_init_attempt.try_exists() {
                        Ok(_) => break auth_init_attempt,
                        Err(MsalError::AADSTSError(e)) => {
                            if attempts > 2 {
                                error!("{:?}", e);
                                return Ok((
                                    AuthRequest::InitDenied {
                                        msg: tr("Authentication service is temporarily unavailable. Please try again shortly."),
                                    },
                                    AuthCredHandler::None,
                                ));
                            }
                            match e.code {
                                THROTTLING_ERROR => {
                                    info!(?e, "Throttling authentication attempt");
                                    tokio::time::sleep(delay).await;
                                    continue;
                                }
                                RETRYABLE_ERROR => {
                                    info!(?e, "Transient error, retrying");
                                    tokio::time::sleep(delay).await;
                                    continue;
                                }
                                _ => {
                                    error!("{:?}", e);
                                    return Err(IdpError::BadRequest);
                                }
                            }
                        }
                        Err(e) => {
                            error!("{:?}", e);
                            return Err(IdpError::BadRequest);
                        }
                    }
                };

                // Sign-in frequency optimization: For console logins with password_only mode,
                // request password first and use PasswordFirst handler. This allows us to
                // validate the password via ROPC and check PRT for sign-in frequency before
                // potentially skipping MFA (if the frequency is satisfied).
                if console_password_only && !is_remote_service && !auth_init.passwordless() {
                    debug!(
                        "Console password-only mode: requesting password first to check sign-in frequency",
                    );
                    // Check if the network is up before prompting for password
                    if !self.attempt_online(tpm, SystemTime::now()).await {
                        return Ok((
                            AuthRequest::InitDenied {
                                msg: tr("Network outage detected."),
                            },
                            AuthCredHandler::None,
                        ));
                    }
                    let is_domain_joined = self.is_domain_joined(keystore).await;
                    return Ok((
                        AuthRequest::Password {
                            prompt: None,
                            long_prompt: None,
                        },
                        AuthCredHandler::PasswordFirst {
                            auth_options,
                            is_domain_joined,
                        },
                    ));
                }

                if !auth_init.passwordless() {
                    // Check if the network is even up prior to sending a
                    // password prompt.
                    if !self.attempt_online(tpm, SystemTime::now()).await {
                        return Ok((
                            AuthRequest::InitDenied {
                                msg: tr("Network outage detected."),
                            },
                            AuthCredHandler::None,
                        ));
                    }
                    Ok((
                        AuthRequest::Password {
                            prompt: None,
                            long_prompt: None,
                        },
                        AuthCredHandler::None,
                    ))
                } else {
                    let mfa_method = self.config.lock().await.get_mfa_method();
                    let flow = net_down_check!(
                        self.initiate_mfa_flow_with_fallback(
                                account_id,
                                None,
                                &auth_options,
                                Some(auth_init),
                                mfa_method
                            )
                            .await,
                        Err(MsalError::PasswordRequired) => {
                            return Ok((
                                AuthRequest::Password {
                                    prompt: None,
                                    long_prompt: None,
                                },
                                AuthCredHandler::None,
                            ));
                        },
                        Err(e) => {
                            error!("{:?}", e);
                            return Err(IdpError::BadRequest);
                        }
                    );
                    // Check if Azure provided FIDO credentials (passwordless FIDO)
                    if let (Some(fido_challenge), Some(fido_allow_list)) =
                        (flow.fido_challenge.clone(), flow.fido_allow_list.clone())
                    {
                        let has_physical_security_key = flow.has_physical_security_key;
                        let has_cross_device = flow.has_cross_device_passkey;
                        return Ok((
                            AuthRequest::Fido {
                                fido_challenge,
                                fido_allow_list,
                                has_physical_security_key,
                                has_cross_device,
                            },
                            AuthCredHandler::MFA {
                                flow: Box::new(flow),
                                password: None,
                                extra_data: None,
                                reauth_hello_pin: None,
                            },
                        ));
                    }
                    let msg = flow.msg.clone();
                    let polling_interval = flow.polling_interval.unwrap_or(5000);
                    Ok((
                        AuthRequest::MFAPoll {
                            msg,
                            // Kanidm pam expects a polling_interval in
                            // seconds, not milliseconds.
                            polling_interval: polling_interval / 1000,
                            show_push_hint: mfa_flow_uses_push_hint(&flow),
                        },
                        AuthCredHandler::MFA {
                            flow: Box::new(flow),
                            password: None,
                            extra_data: None,
                            reauth_hello_pin: None,
                        },
                    ))
                }
            } else {
                let mut auth_options = vec![];
                if is_remote_service || !console_password_only {
                    auth_options.push(AuthOption::ForceMFA);
                }
                if is_remote_service {
                    auth_options.push(AuthOption::RemoteSession);
                }
                let resp = net_down_check!(
                    self.client
                        .lock()
                        .await
                        .initiate_device_flow_for_device_enrollment(&auth_options)
                        .await,
                    Err(e) => {
                        error!("{:?}", e);
                        return Err(IdpError::BadRequest);
                    }
                );
                let flow: MFAAuthContinue = resp.into();
                let msg = flow.msg.clone();
                let polling_interval = flow.polling_interval.unwrap_or(5000);
                Ok((
                    AuthRequest::MFAPoll {
                        msg,
                        // Kanidm pam expects a polling_interval in
                        // seconds, not milliseconds.
                        polling_interval: polling_interval / 1000,
                        show_push_hint: false,
                    },
                    AuthCredHandler::MFA {
                        flow: Box::new(flow),
                        password: None,
                        extra_data: None,
                        reauth_hello_pin: None,
                    },
                ))
            }
        } else {
            // Check if the network is even up prior to sending a PIN prompt,
            // otherwise we duplicate the PIN prompt when the network goes down.
            if !self.attempt_online(tpm, SystemTime::now()).await {
                // We are offline, fail the authentication now
                debug!("Network down encountered during online auth init");
                return Err(IdpError::BadRequest);
            }

            Ok((AuthRequest::Pin, AuthCredHandler::None))
        }
    }

    #[instrument(skip(
        self,
        account_id,
        old_token,
        cred_handler,
        pam_next_req,
        keystore,
        tpm,
        machine_key,
        _shutdown_rx
    ))]
    async fn unix_user_online_auth_step<D: KeyStoreTxn + Send>(
        &self,
        account_id: &str,
        old_token: &UserToken,
        service: &str,
        no_hello_pin: bool,
        cred_handler: &mut AuthCredHandler,
        pam_next_req: PamAuthRequest,
        keystore: &mut D,
        tpm: &mut tpm::provider::BoxedDynTpm,
        machine_key: &tpm::structures::StorageKey,
        _shutdown_rx: &broadcast::Receiver<()>,
    ) -> Result<(AuthResult, AuthCacheAction), IdpError> {
        macro_rules! net_down_check {
            ($res:expr, $($pat:pat => $result:expr),*) => {
                match $res {
                    Err(MsalError::RequestFailed(msg)) => {
                        let url = extract_base_url!(msg);
                        info!(?url, "Network down detected");
                        let mut state = self.state.lock().await;
                        *state = CacheState::OfflineNextCheck(SystemTime::now() + OFFLINE_NEXT_CHECK);
                        // Report the network outage to the user via PAM INFO.
                        return Ok((AuthResult::Denied(tr("Network outage detected.")), AuthCacheAction::None));
                    },
                    Err(MsalError::AcquireTokenFailed(e)) => {
                        check_new_device_enrollment_required!(e, self, keystore)
                    },
                    $($pat => $result),*
                }
            }
        }

        if (self.delayed_init().await).is_err() {
            // Initialization failed. Report that the system is offline. We
            // can't proceed with initialization until the system is online.
            info!("Network down detected");
            let mut state = self.state.lock().await;
            *state = CacheState::OfflineNextCheck(SystemTime::now() + OFFLINE_NEXT_CHECK);
            // Report the network outage to the user via PAM INFO.
            return Ok((
                AuthResult::Denied(tr("Network outage detected.")),
                AuthCacheAction::None,
            ));
        }

        let remote_services = self
            .config
            .lock()
            .await
            .get_password_only_remote_services_deny_list();
        let is_remote_service = service.starts_with("remote:")
            || remote_services
                .iter()
                .any(|s| !s.is_empty() && service.contains(s));
        let hello_totp_enabled = check_hello_totp_enabled!(self);
        let console_password_only = self.config.lock().await.get_allow_console_password_only();
        let require_hello_totp =
            hello_totp_enabled && (is_remote_service || !console_password_only);

        macro_rules! intune_enroll {
            ($token:ident) => {
                match self
                    .intune_enroll(None, None, tpm, &$token, machine_key)
                    .await
                {
                    Ok((intune_key, intune_device_id)) => {
                        {
                            let mut config = self.config.lock().await;
                            config.set(&self.domain, "intune_device_id", &intune_device_id);
                            if let Err(e) = config.write_server_config() {
                                error!(?e, "Failed to write Intune join configuration.");
                                return Ok((
                                    AuthResult::Denied(tr("Failed to save device configuration. Please contact your administrator.")),
                                    AuthCacheAction::None,
                                ));
                            }
                        }
                        let intune_tag = self.fetch_intune_key_tag();
                        if let Err(e) = keystore.insert_tagged_hsm_key(&intune_tag, &intune_key) {
                            error!(?e, "Failed inserting the intune key into the keystore.");
                            return Ok((
                                AuthResult::Denied(tr("Failed to store device credentials. Please contact your administrator.")),
                                AuthCacheAction::None,
                            ));
                        }
                    }
                    Err(IdpError::NotFound { .. }) => {}
                    Err(e) => {
                        error!(?e, "Failed to enroll in Intune, will retry later.");
                    }
                }
            };
        }
        macro_rules! enroll_and_obtain_enrolled_token {
            ($token:ident, $cred:expr) => {{
                if !self.is_domain_joined(keystore).await {
                    debug!("Device is not enrolled. Enrolling now.");
                    if let Err(e) = self.join_domain(tpm, &$token, keystore, machine_key).await {
                        if is_mfa_required_for_enrollment(&e) {
                            info!("Device enrollment requires MFA; restarting authentication with ForceMFA.");

                            let (
                                console_password_only,
                                remote_services,
                                enable_experimental_passwordless_fido,
                                enable_passwordless_security_key,
                                enable_passwordless_qr_bluetooth,
                                enable_passwordless,
                                mfa_method,
                                apply_policy,
                            ) = {
                                let cfg = self.config.lock().await;
                                (
                                    cfg.get_allow_console_password_only(),
                                    cfg.get_password_only_remote_services_deny_list(),
                                    cfg.get_enable_experimental_passwordless_fido(),
                                    cfg.get_enable_passwordless_security_key(),
                                    cfg.get_enable_passwordless_qr_bluetooth(),
                                    cfg.get_enable_passwordless(),
                                    cfg.get_mfa_method(),
                                    cfg.get_apply_policy(),
                                )
                            };
                            let is_remote_service = service.starts_with("remote:")
                                || remote_services
                                    .iter()
                                    .any(|s| !s.is_empty() && service.contains(s));
                            let mut auth_options = vec![AuthOption::ForceMFA];
                            if enable_passwordless {
                                auth_options.push(AuthOption::Passwordless);
                            }
                            if !is_remote_service {
                                auth_options.push(AuthOption::Fido);
                                if enable_experimental_passwordless_fido {
                                    auth_options.push(AuthOption::PasswordlessFido);
                                }
                                if enable_passwordless_security_key {
                                    auth_options.push(AuthOption::PasswordlessSecurityKey);
                                }
                                if enable_passwordless_qr_bluetooth {
                                    auth_options.push(AuthOption::PasswordlessQrBluetooth);
                                }
                            }
                            if is_remote_service {
                                auth_options.push(AuthOption::RemoteSession);
                            } else if console_password_only {
                                debug!(
                                    "Forcing MFA for device enrollment despite console password-only mode."
                                );
                            }
                            if apply_policy {
                                auth_options.push(AuthOption::IntuneEnable);
                            }

                            let enrollment_cred: Option<String> = $cred;
                            let flow = net_down_check!(
                                self.initiate_mfa_flow_with_fallback(
                                    account_id,
                                    enrollment_cred.as_deref(),
                                    &auth_options,
                                    None,
                                    mfa_method,
                                )
                                .await,
                                Ok(flow) => flow,
                                Err(MsalError::ChangePassword) => {
                                    if let Some(old_cred) = enrollment_cred.as_ref() {
                                        return Ok(password_change_required(cred_handler, old_cred.clone()));
                                    }
                                    error!("Password change required, but no old password is available.");
                                    return Ok((
                                        AuthResult::Denied(msal_error_to_user_message(&MsalError::ChangePassword)),
                                        AuthCacheAction::None,
                                    ));
                                },
                                Err(e) => {
                                    error!("MFA flow initiation failed after enrollment MFA demand: {:?}", e);
                                    return Ok((
                                        AuthResult::Denied(msal_error_to_user_message(&e)),
                                        AuthCacheAction::None,
                                    ));
                                }
                            );
                            nested_auth_handle_mfa_resp!(flow, enrollment_cred)
                        }
                        error!("Failed to join domain: {:?}", e);
                        return Ok((
                            AuthResult::Denied(tr("Failed to join domain. Please contact your administrator.")),
                            AuthCacheAction::None,
                        ));
                    }
                } else if !self.is_intune_enrolled(keystore).await {
                    intune_enroll!($token);
                }
                // If an app_id is defined in the config, the app should have the
                // GroupMember.Read.All API permission.
                let (client_id, scopes) = if self.config.lock().await.get_app_id(&self.domain).is_some() {
                    (None, vec!["GroupMember.Read.All"])
                } else {
                    (
                        Some(EDGE_BROWSER_CLIENT_ID),
                        vec!["https://graph.microsoft.com/.default"],
                    )
                };
                let mtoken2 = self
                    .client
                    .lock()
                    .await
                    .acquire_token_by_refresh_token(
                        &$token.refresh_token,
                        scopes.clone(),
                        None,
                        client_id,
                        tpm,
                        machine_key,
                    )
                    .await;
                net_down_check!(mtoken2,
                    Ok(token) => token,
                    Err(e) => {
                        error!("{:?}", e);
                        match e {
                            MsalError::AcquireTokenFailed(err_resp) => {
                                if err_resp.error_codes.contains(&DEVICE_AUTH_FAIL) {
                                    /* A device authentication failure may happen
                                     * if Azure hasn't finished replicating the new
                                     * device object. Wait 5 seconds and try again. */
                                    info!("Azure hasn't finished replicating the device...");
                                    info!("Retrying in 5 seconds");
                                    sleep(Duration::from_secs(5));
                                    net_down_check!(
                                        self.client
                                            .lock()
                                            .await
                                            .acquire_token_by_refresh_token(
                                                &$token.refresh_token,
                                                scopes,
                                                None,
                                                client_id,
                                                tpm,
                                                machine_key,
                                            )
                                            .await,
                                        Ok(token) => token,
                                        Err(e) => {
                                            error!("{:?}", e);
                                            return Ok((
                                                AuthResult::Denied(msal_error_to_user_message(&e)),
                                                AuthCacheAction::None,
                                            ));
                                        }
                                    )
                                } else if err_resp.error_codes.contains(&CONSENT_REQUIRED) {
                                    /* Consent has not been granted for the application
                                     * to access the Graph API. Continue authentication
                                     * without group name resolution - groups will use
                                     * object_id as the name instead. */
                                    warn!("Consent not granted for Graph API access. \
                                           Group names will not be resolved.");
                                    $token.clone()
                                } else if client_id == Some(EDGE_BROWSER_CLIENT_ID) {
                                    /* Authentication failed with Edge Browser client ID.
                                     * Fall back to default app ID - group names may not
                                     * be resolved but authentication can proceed. */
                                    info!(
                                        "Token acquisition failed with Edge Browser app ({}). \
                                         Retrying with default app ID.",
                                        err_resp.error_description
                                    );
                                    match self.client
                                        .lock()
                                        .await
                                        .acquire_token_by_refresh_token(
                                            &$token.refresh_token,
                                            scopes,
                                            None,
                                            Some(DEFAULT_APP_ID),
                                            tpm,
                                            machine_key,
                                        )
                                        .await
                                    {
                                        Ok(token) => token,
                                        Err(e) => {
                                            error!("{:?}", e);
                                            return Ok((
                                                AuthResult::Denied(msal_error_to_user_message(&e)),
                                                AuthCacheAction::None,
                                            ));
                                        }
                                    }
                                } else {
                                    // Return the AAD error description to the user
                                    return Ok((
                                        AuthResult::Denied(err_resp.error_description.clone()),
                                        AuthCacheAction::None,
                                    ));
                                }
                            }
                            MsalError::AADSTSError(_)
                                if client_id == Some(EDGE_BROWSER_CLIENT_ID) =>
                            {
                                /* AADSTS error with Edge Browser client ID
                                 * (e.g. CA policy). Fall back to default app ID. */
                                info!(
                                    "AADSTS error with Edge Browser app. \
                                     Retrying with default app ID."
                                );
                                match self.client
                                    .lock()
                                    .await
                                    .acquire_token_by_refresh_token(
                                        &$token.refresh_token,
                                        scopes,
                                        None,
                                        Some(DEFAULT_APP_ID),
                                        tpm,
                                        machine_key,
                                    )
                                    .await
                                {
                                    Ok(token) => token,
                                    Err(e) => {
                                        error!("{:?}", e);
                                        return Ok((
                                            AuthResult::Denied(msal_error_to_user_message(&e)),
                                            AuthCacheAction::None,
                                        ));
                                    }
                                }
                            }
                            _ => {
                                // Return a user-friendly error message
                                return Ok((
                                    AuthResult::Denied(msal_error_to_user_message(&e)),
                                    AuthCacheAction::None,
                                ));
                            }
                        }
                    }
                )
            }};
        }
        // Issue #1051: Initiate online re-authentication when the cached
        // PRT/refresh token has expired but the Hello key and PIN are still valid.
        // The validated PIN is carried through so the new PRT can be sealed with
        // the existing Hello key after successful re-authentication.
        //
        // When experimental_mfa is enabled, uses the interactive MFA flow (push
        // notification, FIDO, code entry) for a smoother UX. Otherwise falls
        // back to Device Authorization Grant (DAG) which requires the user to
        // authenticate via browser on another device.
        macro_rules! request_reauth {
            ($reauth_pin:expr) => {{
                let reauth_pin_value = Zeroizing::new($reauth_pin);
                let (
                    console_password_only,
                    remote_services,
                    enable_experimental_mfa,
                    enable_experimental_passwordless_fido,
                    enable_passwordless_security_key,
                    enable_passwordless_qr_bluetooth,
                    enable_passwordless,
                    mfa_method,
                    apply_policy,
                ) = {
                    let cfg = self.config.lock().await;
                    (
                        cfg.get_allow_console_password_only(),
                        cfg.get_password_only_remote_services_deny_list(),
                        cfg.get_enable_experimental_mfa(),
                        cfg.get_enable_experimental_passwordless_fido(),
                        cfg.get_enable_passwordless_security_key(),
                        cfg.get_enable_passwordless_qr_bluetooth(),
                        cfg.get_enable_passwordless(),
                        cfg.get_mfa_method(),
                        cfg.get_apply_policy(),
                    )
                };
                let is_remote_service = service.starts_with("remote:")
                    || remote_services
                        .iter()
                        .any(|s| !s.is_empty() && service.contains(s));

                if enable_experimental_mfa {
                    // Interactive MFA flow: supports push notifications, FIDO,
                    // and code entry. Better UX than DAG for most users.
                    let mut auth_options = vec![];
                    if enable_passwordless {
                        auth_options.push(AuthOption::Passwordless);
                    }
                    if !is_remote_service {
                        auth_options.push(AuthOption::Fido);
                        if enable_experimental_passwordless_fido {
                            auth_options.push(AuthOption::PasswordlessFido);
                        }
                        if enable_passwordless_security_key {
                            auth_options.push(AuthOption::PasswordlessSecurityKey);
                        }
                        if enable_passwordless_qr_bluetooth {
                            auth_options.push(AuthOption::PasswordlessQrBluetooth);
                        }
                    }
                    if is_remote_service || !console_password_only {
                        auth_options.push(AuthOption::ForceMFA);
                    }
                    if is_remote_service {
                        auth_options.push(AuthOption::RemoteSession);
                    }
                    if apply_policy {
                        auth_options.push(AuthOption::IntuneEnable);
                    }

                    let flow = match self
                        .initiate_mfa_flow_with_fallback(
                            account_id,
                            None, // No password — we only have the PIN
                            &auth_options,
                            None, // No auth_init — user already exists
                            mfa_method
                        )
                        .await
                    {
                        Ok(flow) => flow,
                        Err(MsalError::RequestFailed(msg)) => {
                            let url = extract_base_url!(msg);
                            info!(?url, "Network down detected during reauth MFA initiation");
                            let mut state = self.state.lock().await;
                            *state = CacheState::OfflineNextCheck(
                                SystemTime::now() + OFFLINE_NEXT_CHECK,
                            );
                            return Ok((
                                AuthResult::Denied(tr("Network outage detected.")),
                                AuthCacheAction::None,
                            ));
                        }
                        Err(MsalError::PasswordRequired) => {
                            // Azure requires a password for this flow. Prompt for
                            // password and continue with the regular password+MFA
                            // path so we can avoid DAG when possible.
                            debug!("MFA flow requires password; prompting password reauth.");
                            *cred_handler = AuthCredHandler::ReauthPassword {
                                reauth_hello_pin: reauth_pin_value,
                            };
                            return Ok((
                                AuthResult::Next(AuthRequest::Password {
                                    prompt: None,
                                    long_prompt: None,
                                }),
                                AuthCacheAction::None,
                            ));
                        }
                        Err(e) => {
                            error!("Failed to initiate reauth MFA flow: {:?}", e);
                            return Ok((
                                AuthResult::Denied(
                                    tr("Your session has expired. Please sign in again."),
                                ),
                                AuthCacheAction::None,
                            ));
                        }
                    };

                    // Check if Azure provided FIDO credentials
                    if let (Some(fido_challenge), Some(fido_allow_list)) =
                        (flow.fido_challenge.clone(), flow.fido_allow_list.clone())
                    {
                        let has_physical_security_key = flow.has_physical_security_key;
                        let has_cross_device = flow.has_cross_device_passkey;
                        *cred_handler = AuthCredHandler::MFA {
                            flow: Box::new(flow),
                            password: None,
                            extra_data: None,
                            reauth_hello_pin: Some(reauth_pin_value.clone()),
                        };
                        debug!("Session expired, initiating FIDO re-authentication with existing Hello key.");
                        return Ok((
                            AuthResult::Next(AuthRequest::Fido {
                                fido_challenge,
                                fido_allow_list,
                                has_physical_security_key,
                                has_cross_device,
                            }),
                            AuthCacheAction::None,
                        ));
                    }

                    let msg = flow.msg.clone();
                    let polling_interval = flow.polling_interval.unwrap_or(5000);
                    let show_push_hint = mfa_flow_uses_push_hint(&flow);
                    *cred_handler = AuthCredHandler::MFA {
                        flow: Box::new(flow),
                        password: None,
                        extra_data: None,
                        reauth_hello_pin: Some(reauth_pin_value.clone()),
                    };
                    debug!("Session expired, initiating MFA re-authentication with existing Hello key.");
                    return Ok((
                        AuthResult::Next(AuthRequest::MFAPoll {
                            msg,
                            // Kanidm pam expects a polling_interval in
                            // seconds, not milliseconds.
                            polling_interval: polling_interval / 1000,
                            show_push_hint,
                        }),
                        AuthCacheAction::None,
                    ));
                } else {
                    // DAG fallback: works in all configurations but requires
                    // the user to authenticate via browser on another device.
                    let mut auth_options = vec![];
                    if is_remote_service || !console_password_only {
                        auth_options.push(AuthOption::ForceMFA);
                    }
                    if is_remote_service {
                        auth_options.push(AuthOption::RemoteSession);
                    }
                    let resp = match self
                        .client
                        .lock()
                        .await
                        .initiate_device_flow_for_device_enrollment(&auth_options)
                        .await
                    {
                        Ok(resp) => resp,
                        Err(MsalError::RequestFailed(msg)) => {
                            let url = extract_base_url!(msg);
                            info!(?url, "Network down detected during reauth DAG initiation");
                            let mut state = self.state.lock().await;
                            *state = CacheState::OfflineNextCheck(
                                SystemTime::now() + OFFLINE_NEXT_CHECK,
                            );
                            return Ok((
                                AuthResult::Denied(tr("Network outage detected.")),
                                AuthCacheAction::None,
                            ));
                        }
                        Err(e) => {
                            error!("Failed to initiate reauth device flow: {:?}", e);
                            return Ok((
                                AuthResult::Denied(
                                    tr("Your session has expired. Please sign in again."),
                                ),
                                AuthCacheAction::None,
                            ));
                        }
                    };
                    let flow: MFAAuthContinue = resp.into();
                    let msg = flow.msg.clone();
                    let polling_interval = flow.polling_interval.unwrap_or(5000);
                    *cred_handler = AuthCredHandler::MFA {
                        flow: Box::new(flow),
                        password: None,
                        extra_data: None,
                        reauth_hello_pin: Some(reauth_pin_value),
                    };
                    debug!("Session expired, initiating DAG re-authentication with existing Hello key.");
                    return Ok((
                        AuthResult::Next(AuthRequest::MFAPoll {
                            msg,
                            // Kanidm pam expects a polling_interval in
                            // seconds, not milliseconds.
                            polling_interval: polling_interval / 1000,
                            show_push_hint: false,
                        }),
                        AuthCacheAction::None,
                    ));
                }
            }};
        }
        macro_rules! sspr_demand_hello_fallback {
            ($cred:ident, $require_hello_totp:expr) => {{
                // Hello authentication already succeeded,
                // but SSPR demand was sent. Proceed and permit
                // this authentication so the user has the opportunity
                // to fix this (SSO will fail until this is fixed).
                warn!(
                    "AADSTS{} (SSPR required) encountered; permitting auth via local Hello Pin",
                    PASSWORD_RESET_REGISTRATION_REQUIRED
                );
                if $require_hello_totp {
                    if !check_hello_totp_setup!(self, account_id, keystore) {
                        return impl_setup_hello_totp!(
                            self,
                            account_id,
                            keystore,
                            old_token,
                            $cred,
                            tpm,
                            machine_key,
                            cred_handler
                        );
                    } else {
                        *cred_handler = AuthCredHandler::HelloTOTP {
                            cred: $cred.clone(),
                            pending_sealed_totp: None,
                        };
                        return Ok((
                            AuthResult::Next(AuthRequest::HelloTOTP {
                                msg: tr(
                                    "Please enter your Hello TOTP code from your Authenticator:",
                                ) + " ",
                            }),
                            AuthCacheAction::None,
                        ));
                    }
                } else {
                    return Ok((
                        AuthResult::Success {
                            token: old_token.clone(),
                        },
                        AuthCacheAction::None,
                    ));
                }
            }};
        }
        macro_rules! auth_and_validate_hello_key {
            ($hello_key:ident, $keytype:ident, $cred:ident, $require_hello_totp:expr) => {{
                // CRITICAL: Validate that we can load the key, otherwise the offline
                // fallback will allow the user to authenticate with a bad PIN here.
                // `acquire_token_by_hello_for_business_key` CAN (and probably will)
                // respond with a `RequestFailed` prior to validating the PIN, since
                // the Nonce request will fail (which is sent prior to validation).
                let pin = match PinValue::new(&$cred) {
                    Ok(pin) => pin,
                    Err(e) => {
                        error!("Failed setting pin value: {:?}", e);
                        handle_hello_bad_pin_count!(self, account_id, keystore, |msg: &str| {
                            Ok((AuthResult::Denied(msg.to_string()), AuthCacheAction::None))
                        });
                        return Ok((
                            AuthResult::Denied(tr("Failed to authenticate with Hello PIN.")),
                            AuthCacheAction::None,
                        ));
                    }
                };
                if let Err(e) = tpm.ms_hello_key_load(machine_key, &$hello_key, &pin) {
                    error!("{:?}", e);
                    handle_hello_bad_pin_count!(self, account_id, keystore, |msg: &str| {
                        Ok((AuthResult::Denied(msg.to_string()), AuthCacheAction::None))
                    });
                    return Ok((
                        AuthResult::Denied(tr("Failed to authenticate with Hello PIN.")),
                        AuthCacheAction::None,
                    ));
                }

                // If an app_id is defined in the config, the app should have the
                // GroupMember.Read.All API permission.
                let (client_id, scopes) = if self.config.lock().await.get_app_id(&self.domain).is_some() {
                    (None, vec!["GroupMember.Read.All"])
                } else {
                    (
                        Some(EDGE_BROWSER_CLIENT_ID),
                        vec!["https://graph.microsoft.com/.default"],
                    )
                };
                let token = if $keytype == KeyType::Hello {
                    match self
                        .client
                        .lock()
                        .await
                        .acquire_token_by_hello_for_business_key(
                            account_id,
                            &$hello_key,
                            scopes,
                            None,
                            client_id,
                            tpm,
                            machine_key,
                            &$cred,
                        )
                        .await
                    {
                        Ok(token) => {
                            self.bad_pin_counter.reset_bad_pin_count(account_id).await;
                            token
                        }
                        // If the network goes down during an online PIN auth, we can downgrade to an
                        // offline auth and permit the authentication to proceed.
                        Err(MsalError::RequestFailed(msg)) => {
                            let url = extract_base_url!(msg);
                            info!(?url, "Network down detected");
                            let mut state = self.state.lock().await;
                            *state =
                                CacheState::OfflineNextCheck(SystemTime::now() + OFFLINE_NEXT_CHECK);
                            if $require_hello_totp {
                                if !check_hello_totp_setup!(self, account_id, keystore) {
                                    return impl_setup_hello_totp!(
                                        self,
                                        account_id,
                                        keystore,
                                        old_token,
                                        $cred,
                                        tpm,
                                        machine_key,
                                        cred_handler
                                    );
                                } else {
                                    *cred_handler = AuthCredHandler::HelloTOTP {
                                        cred: $cred.clone(),
                                        pending_sealed_totp: None,
                                    };
                                    return Ok((AuthResult::Next(AuthRequest::HelloTOTP {
                                        msg: tr("Please enter your Hello TOTP code from your Authenticator:") + " ",
                                    }), AuthCacheAction::None));
                                }
                            } else {
                                return Ok((
                                    AuthResult::Success {
                                        token: old_token.clone(),
                                    },
                                    AuthCacheAction::None,
                                ));
                            }
                        }
                        // The SSPR cached-token fallback exists only to let a user reach a
                        // browser on the local machine and complete SSPR enrollment.
                        Err(ref e) if is_sspr_required(e) && !is_remote_service => {
                            sspr_demand_hello_fallback!($cred, $require_hello_totp)
                        }
                        Err(ref e) if is_sspr_required(e) && is_remote_service => {
                            return Ok((
                                AuthResult::Denied(msal_error_to_user_message(e)),
                                AuthCacheAction::None,
                            ));
                        }
                        Err(MsalError::AcquireTokenFailed(e)) => {
                            if e.error_codes.contains(&CONSENT_REQUIRED) {
                                /* Consent has not been granted for the application
                                 * to access the Graph API. Retry without Graph API
                                 * scopes - authentication can still proceed but group
                                 * names will not be resolved. */
                                warn!("Consent not granted for Graph API access. \
                                       Retrying authentication without Graph API scopes.");
                                match self
                                    .client
                                    .lock()
                                    .await
                                    .acquire_token_by_hello_for_business_key(
                                        account_id,
                                        &$hello_key,
                                        vec![],
                                        None,
                                        None,
                                        tpm,
                                        machine_key,
                                        &$cred,
                                    )
                                    .await
                                {
                                    Ok(token) => {
                                        self.bad_pin_counter.reset_bad_pin_count(account_id).await;
                                        token
                                    }
                                    Err(e) => {
                                        error!("Failed to authenticate with hello key (retry): {:?}", e);
                                        let err_msg = msal_error_to_user_message(&e);
                                        handle_hello_bad_pin_count!(self, account_id, keystore, |msg: &str| {
                                            Ok((AuthResult::Denied(msg.to_string() + " " + &err_msg), AuthCacheAction::None))
                                        });
                                        return Ok((
                                            AuthResult::Denied(
                                                tr("Failed to authenticate with Hello PIN."),
                                            ),
                                            AuthCacheAction::None,
                                        ));
                                    }
                                }
                            } else if client_id == Some(EDGE_BROWSER_CLIENT_ID) {
                                /* Authentication failed with Edge Browser client ID.
                                 * Fall back to default app ID - group names may not
                                 * be resolved but authentication can proceed. */
                                info!(
                                    "Token acquisition failed with Edge Browser app ({}). \
                                     Retrying with default app ID.",
                                    e.error_description
                                );
                                match self
                                    .client
                                    .lock()
                                    .await
                                    .acquire_token_by_hello_for_business_key(
                                        account_id,
                                        &$hello_key,
                                        vec!["https://graph.microsoft.com/.default"],
                                        None,
                                        Some(DEFAULT_APP_ID),
                                        tpm,
                                        machine_key,
                                        &$cred,
                                    )
                                    .await
                                {
                                    Ok(token) => {
                                        self.bad_pin_counter.reset_bad_pin_count(account_id).await;
                                        token
                                    }
                                    Err(e) => {
                                        error!("Failed to authenticate with hello key (fallback): {:?}", e);
                                        let err_msg = msal_error_to_user_message(&e);
                                        handle_hello_bad_pin_count!(self, account_id, keystore, |msg: &str| {
                                            Ok((AuthResult::Denied(msg.to_string() + " " + &err_msg), AuthCacheAction::None))
                                        });
                                        return Ok((
                                            AuthResult::Denied(
                                                tr("Failed to authenticate with Hello PIN."),
                                            ),
                                            AuthCacheAction::None,
                                        ));
                                    }
                                }
                            } else {
                                check_new_device_enrollment_required!(e, self, keystore)
                            }
                        }
                        Err(MsalError::AADSTSError(_))
                            if client_id == Some(EDGE_BROWSER_CLIENT_ID) =>
                        {
                            /* AADSTS error with Edge Browser client ID
                             * (e.g. CA policy). Fall back to default app ID. */
                            info!(
                                "AADSTS error with Edge Browser app. \
                                 Retrying with default app ID."
                            );
                            match self
                                .client
                                .lock()
                                .await
                                .acquire_token_by_hello_for_business_key(
                                    account_id,
                                    &$hello_key,
                                    vec!["https://graph.microsoft.com/.default"],
                                    None,
                                    Some(DEFAULT_APP_ID),
                                    tpm,
                                    machine_key,
                                    &$cred,
                                )
                                .await
                            {
                                Ok(token) => {
                                    self.bad_pin_counter.reset_bad_pin_count(account_id).await;
                                    token
                                }
                                Err(e) => {
                                    error!("Failed to authenticate with hello key (AADSTS fallback): {:?}", e);
                                    let err_msg = msal_error_to_user_message(&e);
                                    handle_hello_bad_pin_count!(self, account_id, keystore, |msg: &str| {
                                        Ok((AuthResult::Denied(msg.to_string() + " " + &err_msg), AuthCacheAction::None))
                                    });
                                    return Ok((
                                        AuthResult::Denied(
                                            tr("Failed to authenticate with Hello PIN."),
                                        ),
                                        AuthCacheAction::None,
                                    ));
                                }
                            }
                        }
                        Err(e) => {
                            error!("Failed to authenticate with hello key: {:?}", e);
                            let err_msg = msal_error_to_user_message(&e);
                            handle_hello_bad_pin_count!(self, account_id, keystore, |msg: &str| {
                                Ok((AuthResult::Denied(msg.to_string() + " " + &err_msg), AuthCacheAction::None))
                            });
                            return Ok((
                                AuthResult::Denied(
                                    tr("Failed to authenticate with Hello PIN."),
                                ),
                                AuthCacheAction::None,
                            ));
                        }
                    }
                } else { // This Hello key is decoupled
                    // Check for and decrypt any cached tokens
                    let hello_prt_tag = self.fetch_hello_prt_key_tag(account_id);
                    let hello_refresh_token_tag = self.fetch_hello_refresh_token_key_tag(account_id);
                    let refresh_cache_entry = match keystore.get_tagged_hsm_key(&hello_prt_tag) {
                        Ok(Some(hello_prt)) => self
                            .client
                            .lock()
                            .await
                            .unseal_user_prt_with_hello_key(
                                &hello_prt,
                                &$hello_key,
                                &$cred,
                                tpm,
                                machine_key,
                            ).ok().map(|prt| RefreshCacheEntry::Prt(prt)),
                        // If we don't have a cached PRT, check for a cached refresh token
                        Err(_) | Ok(None) => {
                            match keystore.get_tagged_hsm_key(&hello_refresh_token_tag) {
                                Ok(Some(sealed_refresh_token)) => {
                                    let pin = PinValue::new(&$cred).map_err(|e| {
                                        error!("Failed initializing pin value: {:?}", e);
                                        IdpError::Tpm
                                    })?;
                                    let (_key, win_hello_storage_key) = tpm
                                        .ms_hello_key_load(machine_key, &$hello_key, &pin)
                                        .map_err(|e| {
                                            error!("Failed loading hello key for prt cache: {:?}", e);
                                            IdpError::Tpm
                                        })?;
                                    match tpm.unseal_data(&win_hello_storage_key, &sealed_refresh_token) {
                                        Ok(refresh_token_bytes) => {
                                            let refresh_token = String::from_utf8(
                                                refresh_token_bytes.to_vec(),
                                            ).map_err(|e| {
                                                error!("Failed converting refresh token to string: {:?}", e);
                                                IdpError::Tpm
                                            })?;
                                            Some(RefreshCacheEntry::RefreshToken(refresh_token))
                                        }
                                        Err(_) => self.refresh_cache.refresh_token(account_id).await.ok(),
                                    }
                                }
                                // If we just authenticated for the first time, the PRT is instead
                                // in the mem cache.
                                Err(_) | Ok(None) => self.refresh_cache.refresh_token(account_id).await.ok(),
                            }
                        },
                    };
                    if let Some(RefreshCacheEntry::Prt(prt)) = refresh_cache_entry {
                        let prt_exchange_result = self
                            .client
                            .lock()
                            .await
                            .exchange_prt_for_access_token(
                                &prt,
                                scopes,
                                None,
                                client_id,
                                tpm,
                                machine_key,
                                None,
                                None,
                            ).await;
                        // The MutexGuard from .lock() above is dropped here
                        // (before the match), so we can re-lock inside the
                        // match arms without deadlocking.
                        match prt_exchange_result {
                                Ok(mut token) => {
                                    // Request a new PRT to attach to the token (kick
                                    // the can down the road). Use a timeout so a slow
                                    // or hanging Entra endpoint does not block auth,
                                    // as this is an optimization step.
                                    match tokio::time::timeout(
                                        Duration::from_secs(10),
                                        self.client
                                            .lock()
                                            .await
                                            .exchange_prt_for_prt(
                                                &prt,
                                                tpm,
                                                machine_key,
                                                true,
                                            ),
                                    ).await {
                                        Ok(Ok(new_prt)) => {
                                            token.prt = Some(new_prt);
                                        }
                                        Ok(Err(e)) => {
                                            warn!("PRT renewal failed (non-fatal): {:?}", e);
                                        }
                                        Err(_) => {
                                            warn!("PRT renewal timed out after 10s (non-fatal)");
                                        }
                                    }
                                    self.bad_pin_counter.reset_bad_pin_count(account_id).await;
                                    token
                                }
                                // If the network goes down during an online exchange auth, we can
                                // downgrade to an offline auth and permit the authentication to proceed.
                                Err(MsalError::RequestFailed(msg)) => {
                                    let url = extract_base_url!(msg);
                                    info!(?url, "Network down detected");
                                    let mut state = self.state.lock().await;
                                    *state =
                                        CacheState::OfflineNextCheck(SystemTime::now() + OFFLINE_NEXT_CHECK);
                                    if $require_hello_totp {
                                        if !check_hello_totp_setup!(self, account_id, keystore) {
                                            return impl_setup_hello_totp!(
                                                self,
                                                account_id,
                                                keystore,
                                                old_token,
                                                $cred,
                                                tpm,
                                                machine_key,
                                                cred_handler
                                            );
                                        } else {
                                            *cred_handler = AuthCredHandler::HelloTOTP {
                                                cred: $cred.clone(),
                                                pending_sealed_totp: None,
                                            };
                                            return Ok((AuthResult::Next(AuthRequest::HelloTOTP {
                                                msg: tr("Please enter your Hello TOTP code from your Authenticator:") + " ",
                                            }), AuthCacheAction::None));
                                        }
                                    } else {
                                        return Ok((
                                            AuthResult::Success {
                                                token: old_token.clone(),
                                            },
                                            AuthCacheAction::None,
                                        ));
                                    }
                                }
                                Err(ref e) if is_sspr_required(e) && !is_remote_service => {
                                    sspr_demand_hello_fallback!($cred, $require_hello_totp)
                                }
                                Err(ref e) if is_sspr_required(e) && is_remote_service => {
                                    return Ok((
                                        AuthResult::Denied(msal_error_to_user_message(e)),
                                        AuthCacheAction::None,
                                    ));
                                }
                                Err(MsalError::AcquireTokenFailed(e)) => {
                                    if e.error_codes.contains(&CONSENT_REQUIRED) {
                                        /* Consent has not been granted for the application
                                         * to access the Graph API. Retry without Graph API
                                         * scopes - authentication can still proceed but group
                                         * names will not be resolved. */
                                        warn!("Consent not granted for Graph API access. \
                                               Retrying token exchange without Graph API scopes.");
                                        match self
                                            .client
                                            .lock()
                                            .await
                                            .exchange_prt_for_access_token(
                                                &prt,
                                                vec![],
                                                None,
                                                None,
                                                tpm,
                                                machine_key,
                                                None,
                                                None,
                                            ).await {
                                                Ok(mut token) => {
                                                    if let Ok(new_prt) = self
                                                        .client
                                                        .lock()
                                                        .await
                                                        .exchange_prt_for_prt(
                                                            &prt,
                                                            tpm,
                                                            machine_key,
                                                            true,
                                                        ).await {
                                                            token.prt = Some(new_prt);
                                                        };
                                                    self.bad_pin_counter.reset_bad_pin_count(account_id).await;
                                                    token
                                                }
                                                Err(e) => {
                                                    error!("Failed to exchange PRT (retry): {:?}", e);
                                                    let err_msg = msal_error_to_user_message(&e);
                                                    return Ok((
                                                        AuthResult::Denied(tr("Authentication failed. Please try signing in again.") + " " + &err_msg),
                                                        AuthCacheAction::None,
                                                    ));
                                                }
                                            }
                                    } else {
                                        check_new_device_enrollment_required!(e, self, keystore)
                                    }
                                },
                                Err(e) => {
                                    error!("Failed to exchange PRT for access token: {:?}", e);
                                    // Issue #1051: Access token request for this PRT failed.
                                    // Delete the expired PRT but KEEP the Hello key so the
                                    // user can reuse their existing PIN after re-authenticating.
                                    keystore
                                        .delete_tagged_hsm_key(&hello_prt_tag)
                                        .map_err(|e| {
                                            error!("Failed to delete hello prt: {:?}", e);
                                            IdpError::Tpm
                                        })?;
                                    self.bad_pin_counter.reset_bad_pin_count(account_id).await;
                                    request_reauth!($cred.clone());
                                }
                            }
                    } else if let Some(RefreshCacheEntry::RefreshToken(refresh_token)) = refresh_cache_entry {
                        // We have a refresh token, exchange that for an access token
                        let (ip_versions, request_timeout) = {
                            let cfg = self.config.lock().await;
                            (cfg.get_ip_versions(), cfg.get_request_timeout())
                        };
                        let app = match PublicClientApplication::new(
                            BROKER_APP_ID,
                            None,
                            std::time::Duration::from_secs(request_timeout),
                            &ip_versions,
                        ) {
                            Ok(app) => app,
                            Err(e) => {
                                error!("Failed to create PublicClientApplication: {:?}", e);
                                return Ok((
                                    AuthResult::Denied(tr("Authentication service unavailable. Please try again later.")),
                                    AuthCacheAction::None,
                                ));
                            }
                        };
                        match app.acquire_token_by_refresh_token(
                            &refresh_token,
                            vec![],
                        ).await {
                            Ok(token) => {
                                self.bad_pin_counter.reset_bad_pin_count(account_id).await;
                                token
                            },
                            // If the network goes down during an online exchange auth, we can
                            // downgrade to an offline auth and permit the authentication to proceed.
                            Err(MsalError::RequestFailed(msg)) => {
                                let url = extract_base_url!(msg);
                                info!(?url, "Network down detected");
                                let mut state = self.state.lock().await;
                                *state =
                                    CacheState::OfflineNextCheck(SystemTime::now() + OFFLINE_NEXT_CHECK);
                                if $require_hello_totp {
                                    if !check_hello_totp_setup!(self, account_id, keystore) {
                                        return impl_setup_hello_totp!(
                                            self,
                                            account_id,
                                            keystore,
                                            old_token,
                                            $cred,
                                            tpm,
                                            machine_key,
                                            cred_handler
                                        );
                                    } else {
                                        *cred_handler = AuthCredHandler::HelloTOTP {
                                            cred: $cred.clone(),
                                            pending_sealed_totp: None,
                                        };
                                        return Ok((AuthResult::Next(AuthRequest::HelloTOTP {
                                            msg: tr("Please enter your Hello TOTP code from your Authenticator:") + " ",
                                        }), AuthCacheAction::None));
                                    }
                                } else {
                                    return Ok((
                                        AuthResult::Success {
                                            token: old_token.clone(),
                                        },
                                        AuthCacheAction::None,
                                    ));
                                }
                            }
                            Err(ref e) if is_sspr_required(e) && !is_remote_service => {
                                sspr_demand_hello_fallback!($cred, $require_hello_totp)
                            }
                            Err(ref e) if is_sspr_required(e) && is_remote_service => {
                                return Ok((
                                    AuthResult::Denied(msal_error_to_user_message(e)),
                                    AuthCacheAction::None,
                                ));
                            }
                            Err(e) => {
                                error!("Failed to exchange refresh token for access token: {:?}", e);
                                // Issue #1051: Delete the expired refresh token but KEEP the
                                // Hello key so the user can reuse their existing PIN after
                                // re-authenticating online.
                                keystore
                                    .delete_tagged_hsm_key(&hello_refresh_token_tag)
                                    .map_err(|e| {
                                        error!("Failed to delete hello refresh token: {:?}", e);
                                        IdpError::Tpm
                                    })?;
                                self.bad_pin_counter.reset_bad_pin_count(account_id).await;
                                request_reauth!($cred.clone());
                            }
                        }
                    } else {
                        // Issue #1051: No cached PRT or refresh token found, but the
                        // Hello key is still valid. Keep the key and initiate online
                        // re-authentication so the user can reuse their existing PIN.
                        debug!("No cached PRT/refresh token found; initiating reauth with existing Hello key.");
                        request_reauth!($cred.clone());
                    }
                };

                // Cache the PRT to disk for offline auth SSO
                if let Some(prt) = &token.prt {
                    match self.client.lock().await.seal_user_prt_with_hello_key(
                        prt,
                        &$hello_key,
                        &$cred,
                        tpm,
                        machine_key,
                    ) {
                        Ok(hello_prt) => {
                            let hello_prt_tag = self.fetch_hello_prt_key_tag(account_id);
                            keystore
                                .insert_tagged_hsm_key(&hello_prt_tag, &hello_prt)
                                .map_err(|e| {
                                    let uuid = token.uuid().map(|v| v.to_string()).unwrap_or("".to_string());
                                    error!("Failed to cache hello prt for {}: {:?}", uuid, e);
                                    IdpError::Tpm
                                })?;
                        }
                        Err(e) => {
                            let uuid = token.uuid().map(|v| v.to_string()).unwrap_or("".to_string());
                            error!("Failed to cache hello prt for {}: {:?}", uuid, e);
                        }
                    }
                } else {
                    // If there is no PRT, cache the refresh token instead
                    let pin = PinValue::new(&$cred).map_err(|e| {
                        error!("Failed initializing pin value: {:?}", e);
                        IdpError::Tpm
                    })?;
                    let (_key, win_hello_storage_key) = tpm
                        .ms_hello_key_load(machine_key, &$hello_key, &pin)
                        .map_err(|e| {
                            error!("Failed loading hello key for prt cache: {:?}", e);
                            IdpError::Tpm
                        })?;
                    let refresh_token_zeroizing =
                        zeroize::Zeroizing::new(token.refresh_token.as_bytes().to_vec());
                    tpm.seal_data(&win_hello_storage_key, refresh_token_zeroizing)
                        .map_err(|e| {
                            let uuid = token.uuid().map(|v| v.to_string()).unwrap_or("".to_string());
                            error!("Failed to seal refresh token for {}: {:?}", uuid, e);
                            IdpError::Tpm
                        })
                        .and_then(|sealed_prt| {
                            let hello_prt_tag = self.fetch_hello_refresh_token_key_tag(account_id);
                            keystore.insert_tagged_hsm_key(&hello_prt_tag, &sealed_prt).map_err(|e| {
                                let uuid = token.uuid().map(|v| v.to_string()).unwrap_or("".to_string());
                                error!("Failed to cache hello refresh token for {}: {:?}", uuid, e);
                                IdpError::Tpm
                            })
                        })?;
                }

                if !self.is_intune_enrolled(keystore).await {
                    intune_enroll!(token);
                }

                match self.token_validate(account_id, &token, None).await {
                    Ok(AuthResult::Success { token }) => {
                        if $require_hello_totp {
                            if !check_hello_totp_setup!(self, account_id, keystore) {
                                return impl_setup_hello_totp!(
                                    self,
                                    account_id,
                                    keystore,
                                    old_token,
                                    $cred,
                                    tpm,
                                    machine_key,
                                    cred_handler
                                );
                            } else {
                                *cred_handler = AuthCredHandler::HelloTOTP {
                                    cred: $cred.clone(),
                                    pending_sealed_totp: None,
                                };
                                return Ok((AuthResult::Next(AuthRequest::HelloTOTP {
                                    msg: tr("Please enter your Hello TOTP code from your Authenticator:") + " ",
                                }), AuthCacheAction::None));
                            }
                        } else {
                            debug!("Returning user token from successful Hello PIN authentication.");
                            Ok((AuthResult::Success { token }, AuthCacheAction::None))
                        }
                    }
                    /* This should never happen. It doesn't make sense to
                     * continue from a Pin auth. */
                    Ok(AuthResult::Next(_)) => {
                        debug!("Invalid additional authentication requested with Hello auth.");
                        Ok((
                            AuthResult::Denied(tr("Unexpected authentication step. Please try signing in again.")),
                            AuthCacheAction::None,
                        ))
                    }
                    Ok(auth_result) => {
                        debug!("Hello auth failed.");
                        Ok((auth_result, AuthCacheAction::None))
                    }
                    Err(e) => {
                        error!("Error encountered during Hello auth: {:?}", e);
                        Err(e)
                    }
                }
            }};
        }
        macro_rules! nested_auth_handle_mfa_resp {
            ($resp:ident, $cred:expr) => {
                nested_auth_handle_mfa_resp!($resp, $cred, None)
            };
            ($resp:ident, $cred:expr, $reauth_hello_pin:expr) => {{
                let password: Option<String> = $cred.into();
                let reauth_hello_pin: Option<Zeroizing<String>> = $reauth_hello_pin;
                auth_handle_mfa_resp!(
                    $resp,
                    // FIDO
                    {
                        let fido_challenge = match $resp.fido_challenge.clone() {
                            Some(challenge) => challenge,
                            None => {
                                debug!("FIDO challenge missing in MFA response");
                                return Ok((
                                    AuthResult::Denied(tr("FIDO authentication not available. Please try a different authentication method.")),
                                    AuthCacheAction::None,
                                ));
                            }
                        };

                        let fido_allow_list = match $resp.fido_allow_list.clone() {
                            Some(list) => list,
                            None => {
                                debug!("FIDO allow list missing in MFA response");
                                return Ok((
                                    AuthResult::Denied(tr("FIDO authentication not available. Please try a different authentication method.")),
                                    AuthCacheAction::None,
                                ));
                            }
                        };
                        *cred_handler = AuthCredHandler::MFA {
                            flow: Box::new($resp),
                            password,
                            extra_data: None,
                            reauth_hello_pin: reauth_hello_pin.clone(),
                        };
                        return Ok((
                            AuthResult::Next(AuthRequest::Fido {
                                fido_allow_list,
                                fido_challenge,
                                has_physical_security_key: false,
                                has_cross_device: false,
                            }),
                            // Do not cache the password until MFA succeeds.
                            AuthCacheAction::None,
                        ));
                    },
                    // PROMPT
                    {
                        let msg = $resp.msg.clone();
                        *cred_handler = AuthCredHandler::MFA {
                            flow: Box::new($resp),
                            password,
                            extra_data: None,
                            reauth_hello_pin: reauth_hello_pin.clone(),
                        };
                        return Ok((
                            AuthResult::Next(AuthRequest::Input {
                                msg,
                                echo_on: false,
                            }),
                            // Do not cache the password until MFA succeeds.
                            AuthCacheAction::None,
                        ));
                    },
                    // POLL
                    {
                        let msg = $resp.msg.clone();
                        let polling_interval = $resp.polling_interval.unwrap_or(5000);
                        let show_push_hint = mfa_flow_uses_push_hint(&$resp);
                        *cred_handler = AuthCredHandler::MFA {
                            flow: Box::new($resp),
                            password,
                            extra_data: None,
                            reauth_hello_pin: reauth_hello_pin.clone(),
                        };
                        return Ok((
                            AuthResult::Next(AuthRequest::MFAPoll {
                                msg,
                                // Kanidm pam expects a polling_interval in
                                // seconds, not milliseconds.
                                polling_interval: polling_interval / 1000,
                                show_push_hint,
                            }),
                            // Do not cache the password until MFA succeeds.
                            AuthCacheAction::None,
                        ));
                    }
                )
            }};
        }
        macro_rules! maybe_prompt_setup_pin_after_password_only_success {
            ($enrollment_token:expr, $success_token:expr, $action:expr, $msg:expr) => {{
                let action = $action;
                let hello_enabled = self.config.lock().await.get_enable_hello();
                let hello_key_missing = self.fetch_hello_key(account_id, keystore).is_err();
                if hello_enabled && !no_hello_pin && hello_key_missing {
                    info!($msg);
                    *cred_handler = AuthCredHandler::SetupPin {
                        token: Box::new(Some($enrollment_token)),
                    };
                    Ok((
                        AuthResult::Next(AuthRequest::SetupPin {
                            msg: tr("Set up a PIN\nA Hello PIN is a fast, secure way to sign in to your device, apps, and services."),
                        }),
                        action,
                    ))
                } else {
                    Ok((
                        AuthResult::Success {
                            token: $success_token,
                        },
                        action,
                    ))
                }
            }};
        }
        macro_rules! prt_signin_frequency_check {
            ($cred:ident) => {
                if let Some(prt_result) = self
                    .try_prt_signin_frequency_check(account_id, tpm, machine_key)
                    .await
                {
                    match prt_result {
                        Ok(msal_token) => {
                            // Sign-in frequency satisfied - no MFA needed!
                            info!("Sign-in frequency satisfied for user via PRT - skipping MFA");
                            return match self.token_validate(account_id, &msal_token, None).await {
                                Ok(AuthResult::Success { token }) => {
                                    let action = if self
                                        .config
                                        .lock()
                                        .await
                                        .get_offline_breakglass_enabled()
                                    {
                                        AuthCacheAction::PasswordHashUpdate { $cred }
                                    } else {
                                        AuthCacheAction::None
                                    };
                                    maybe_prompt_setup_pin_after_password_only_success!(
                                        msal_token,
                                        token,
                                        /* Cache the offline password hash for breakglass
                                         * conditions, if enabled. */
                                        action,
                                        "Password-only auth satisfied sign-in frequency without an existing Hello key; requesting PIN setup."
                                    )
                                }
                                Ok(auth_result) => Ok((auth_result, AuthCacheAction::None)),
                                Err(e) => Err(e),
                            };
                        }
                        Err(reason) => {
                            debug!(
                                "PRT sign-in frequency check failed: {} - proceeding with MFA flow",
                                reason
                            );
                            // Fall through to initiate MFA
                        }
                    }
                } else {
                    debug!("No PRT cached - proceeding with MFA flow",);
                    // Fall through to initiate MFA
                }
            };
        }
        macro_rules! reseal_prt_with_existing_hello_key_on_success {
            ($token:expr, $reauth_hello_pin:expr, $success_token:expr, $action:expr) => {{
                // Issue #1051: If this MFA flow was triggered by an expired
                // PRT/refresh token, re-seal the new PRT with the existing
                // Hello key instead of forcing PIN re-enrollment.
                if let Some(ref pin) = $reauth_hello_pin {
                    if let Ok((hello_key, _keytype)) = self.fetch_hello_key(account_id, keystore) {
                        seal_prt_with_existing_hello_key!(
                            self,
                            account_id,
                            $token,
                            &hello_key,
                            pin,
                            keystore,
                            tpm,
                            machine_key
                        );
                        self.bad_pin_counter.reset_bad_pin_count(account_id).await;
                        info!("Re-sealed PRT with existing Hello key after reauth");
                        return Ok((
                            AuthResult::Success {
                                token: $success_token,
                            },
                            $action,
                        ));
                    }
                    warn!(
                        "Existing Hello key not found after reauth; falling through to PIN setup"
                    );
                }
            }};
        }

        match (&mut *cred_handler, pam_next_req) {
            (AuthCredHandler::SetupPin { token }, PamAuthRequest::SetupPin { pin }) => {
                let token = match token.as_ref().clone() {
                    Some(t) => t,
                    None => {
                        error!("Missing enrollment token for Hello PIN setup.");
                        return Ok((
                            AuthResult::Denied(tr(
                                "PIN setup failed. Please try signing in again.",
                            )),
                            AuthCacheAction::None,
                        ));
                    }
                };
                // Skip Hello enrollment if the token doesn't have the ngcmfa amr
                let amr_ngcmfa = token.amr_ngcmfa().unwrap_or(false);
                let hello_tag = self.fetch_hello_key_tag(account_id, amr_ngcmfa);

                let (hello_key, keytype) = if amr_ngcmfa {
                    net_down_check!(
                        impl_provision_hello_key!(self, token, pin, tpm, machine_key),
                        Ok(hello_key) => (hello_key, KeyType::Hello),
                        Err(e) => {
                            return Ok((
                                AuthResult::Next(AuthRequest::SetupPin {
                                    msg: tr_fmt(
                                        "Failed to provision hello key: {error}\n{message}",
                                        &[
                                            ("error", format!("{e:?}")),
                                            (
                                                "message",
                                                tr("Create a PIN to use in place of passwords."),
                                            ),
                                        ],
                                    ),
                                }),
                                AuthCacheAction::None,
                            ));
                        }
                    )
                } else {
                    (
                        impl_create_decoupled_hello_key!(
                            self,
                            token,
                            amr_ngcmfa,
                            tpm,
                            machine_key,
                            pin,
                            IdpError::Tpm
                        ),
                        KeyType::Decoupled,
                    )
                };
                keystore
                    .insert_tagged_hsm_key(&hello_tag, &hello_key)
                    .map_err(|e| {
                        error!("Failed to provision hello key: {:?}", e);
                        IdpError::Tpm
                    })?;

                auth_and_validate_hello_key!(hello_key, keytype, pin, require_hello_totp)
            }
            (_, PamAuthRequest::Pin { cred }) => {
                let (hello_key, keytype) =
                    self.fetch_hello_key(account_id, keystore)
                        .inspect_err(|_| {
                            error!("Online authentication failed. Hello key missing.");
                        })?;

                auth_and_validate_hello_key!(hello_key, keytype, cred, require_hello_totp)
            }
            // Sign-in frequency optimization: Password-first flow for console logins.
            // This handler validates password via ROPC, then checks PRT for sign-in
            // frequency before potentially skipping MFA.
            (
                AuthCredHandler::PasswordFirst {
                    auth_options,
                    is_domain_joined,
                },
                PamAuthRequest::Password { cred },
            ) => {
                debug!("Console password-only mode: trying ROPC before MFA flow");

                // The broker's ROPC method requires device enrollment (cert_key).
                // If the device isn't enrolled, skip ROPC and go directly to MFA flow.
                let ropc_result = if *is_domain_joined {
                    // Step 1: Validate password via ROPC (Resource Owner Password Credentials)
                    Some(
                        self.client
                            .lock()
                            .await
                            .acquire_token_by_username_password(
                                account_id,
                                &cred,
                                vec![],
                                Some("https://graph.microsoft.com".to_string()),
                                None,
                                tpm,
                                machine_key,
                            )
                            .await,
                    )
                } else {
                    debug!("Device not enrolled - skipping ROPC, proceeding to MFA flow");
                    None
                };

                // Track whether ROPC was attempted (device enrolled). If ROPC told us
                // MFA is required and the PRT sign-in frequency check fails, we'll
                // need ForceMFA. If ROPC was skipped (device not enrolled), the
                // enrollment flow may be MFA or password-only per MS policy.
                let mfa_confirmed_required = ropc_result.is_some();

                match ropc_result {
                    Some(Ok(token)) => {
                        // Password validated and no MFA required - return success
                        debug!("ROPC succeeded - no MFA required");
                        let token2 = enroll_and_obtain_enrolled_token!(token, Some(cred.clone()));
                        return match self.token_validate(account_id, &token2, None).await {
                            Ok(AuthResult::Success { token }) => {
                                let action =
                                    if self.config.lock().await.get_offline_breakglass_enabled() {
                                        AuthCacheAction::PasswordHashUpdate { cred }
                                    } else {
                                        AuthCacheAction::None
                                    };
                                maybe_prompt_setup_pin_after_password_only_success!(
                                    token2,
                                    token,
                                    /* Cache the offline password hash for breakglass
                                     * conditions, if enabled. */
                                    action,
                                    "Password-only auth succeeded without an existing Hello key; requesting PIN setup."
                                )
                            }
                            Ok(auth_result) => Ok((auth_result, AuthCacheAction::None)),
                            Err(e) => Err(e),
                        };
                    }
                    Some(Err(MsalError::AADSTSError(ref aadsts_err)))
                        if [50072, 50074, 50076].contains(&aadsts_err.code) =>
                    {
                        // Password is valid but MFA is required by policy (AADSTS error).
                        // Check if sign-in frequency is satisfied via PRT exchange.
                        debug!(
                            "Password valid but MFA required (AADSTS{}). Checking sign-in frequency via PRT.",
                            aadsts_err.code
                        );

                        prt_signin_frequency_check!(cred)
                    }
                    Some(Err(MsalError::MFARequired)) => {
                        // Password is valid but MFA is required (ConvergedTFA response).
                        // Check if sign-in frequency is satisfied via PRT exchange.
                        debug!(
                            "Password valid but MFA required (ConvergedTFA). Checking sign-in frequency via PRT."
                        );

                        prt_signin_frequency_check!(cred)
                    }
                    Some(Err(MsalError::ChangePassword)) => {
                        return Ok(password_change_required(cred_handler, cred));
                    }
                    Some(Err(e)) => {
                        // ROPC failed - this could be a bad password or other error
                        debug!("ROPC failed: {:?} - authentication denied", e);
                        return Ok((
                            AuthResult::Denied(msal_error_to_user_message(&e)),
                            AuthCacheAction::None,
                        ));
                    }
                    None => {
                        // Device not enrolled - skip ROPC and start enrollment auth flow.
                        // The enrollment flow may be MFA or password-only depending on MS policy.
                        debug!("Skipping ROPC (device not enrolled) - starting MFA auth flow");
                    }
                }

                // For enrolled devices (ropc_result was Some), MFA has been positively
                // determined as required and the PRT sign-in frequency check didn't
                // satisfy it. We must force interactive MFA to get a session with MFA
                // claims. Without ForceMFA, Azure may return an auth code directly
                // (password-only session) which will fail when exchanging the PRT for
                // a Graph access token.
                //
                // For non-enrolled devices (ropc_result was None), do not force MFA so
                // that the enrollment flow can be MFA or password-only according to
                // Microsoft policy and allow_console_password_only behavior.
                if mfa_confirmed_required {
                    if !auth_options.contains(&AuthOption::ForceMFA) {
                        auth_options.push(AuthOption::ForceMFA);
                    }
                    debug!(
                        "Initiating MFA auth flow with ForceMFA (sign-in frequency not satisfied)"
                    );
                } else {
                    debug!(
                        "Initiating device-enrollment auth flow without ForceMFA (policy may allow password-only)"
                    );
                }

                // We pass `None` for auth_init to force a fresh
                // request_auth_config_internal() call that respects the current
                // auth_options (including ForceMFA when set). The original auth_init
                // from check_user_exists() was fetched without ForceMFA, so reusing
                // it would bypass the amr_values=ngcmfa parameter in the
                // /oauth2/authorize request.
                let mfa_method = self.config.lock().await.get_mfa_method();
                let flow = net_down_check!(
                    self.initiate_mfa_flow_with_fallback(
                            account_id,
                            Some(&cred),
                            auth_options,
                            None,
                            mfa_method.clone()
                        )
                        .await,
                    Ok(flow) => flow,
                    Err(MsalError::MFARequired) => {
                        // Azure told us MFA is required. Add ForceMFA (if not
                        // already set) and retry with a fresh auth config.
                        if !auth_options.contains(&AuthOption::ForceMFA) {
                            auth_options.push(AuthOption::ForceMFA);
                        }
                        net_down_check!(
                            self.initiate_mfa_flow_with_fallback(
                                    account_id,
                                    Some(&cred),
                                    auth_options,
                                    None,
                                    mfa_method
                                )
                                .await,
                            Ok(flow) => flow,
                            Err(MsalError::ChangePassword) => {
                                return Ok(password_change_required(cred_handler, cred));
                            },
                            Err(e) => {
                                error!("MFA flow initiation failed: {:?}", e);
                                return Ok((AuthResult::Denied(msal_error_to_user_message(&e)), AuthCacheAction::None));
                            }
                        )
                    },
                    Err(MsalError::ChangePassword) => {
                        return Ok(password_change_required(cred_handler, cred));
                    },
                    Err(MsalError::PasswordRequired) => {
                        // This shouldn't happen since we already validated the password
                        error!("Unexpected PasswordRequired error after ROPC validation");
                        return Ok((
                            AuthResult::Denied(tr("Authentication failed. Please try again.")),
                            AuthCacheAction::None,
                        ));
                    },
                    Err(e) => {
                        error!("MFA flow initiation failed: {:?}", e);
                        return Ok((AuthResult::Denied(msal_error_to_user_message(&e)), AuthCacheAction::None));
                    }
                );

                nested_auth_handle_mfa_resp!(flow, cred)
            }
            (change_password, PamAuthRequest::Password { cred }) => {
                let mut reauth_hello_pin: Option<Zeroizing<String>> = None;
                if let AuthCredHandler::ReauthPassword {
                    reauth_hello_pin: pin,
                } = change_password
                {
                    reauth_hello_pin = Some(pin.clone());
                }

                if let AuthCredHandler::ChangePassword { old_cred } = change_password {
                    // If the password change fails, show the provider error and
                    // prompt for another new password while keeping the old password.
                    let _ = net_down_check!(
                        self.client
                            .lock()
                            .await
                            .handle_password_change(account_id, old_cred, &cred)
                            .await,
                        Ok(_) => {},
                        Err(e) => {
                            error!("Failed to change user password: {:?}", e);
                            *cred_handler = AuthCredHandler::ChangePassword { old_cred: old_cred.to_string() };
                            return Ok((
                                AuthResult::Next(
                                    AuthRequest::ChangePassword { msg: tr_fmt(
                                        "Failed to change user password: {msg}",
                                        &[("msg", msal_error_to_user_message(&e))],
                                    )}
                                ),
                                AuthCacheAction::None,
                            ));
                        }
                    );
                }

                let mut opts = vec![];
                // Prohibit Fido over a remote service (since it can't work)
                let remote_services = self
                    .config
                    .lock()
                    .await
                    .get_password_only_remote_services_deny_list();
                // Check if this is a remote service:
                // - Service starts with "remote:" (set by PAM module when PAM_RHOST is set)
                // - Service name contains any entry from remote_services_deny_list
                let is_remote_service = service.starts_with("remote:")
                    || remote_services
                        .iter()
                        .any(|s| !s.is_empty() && service.contains(s));
                let console_password_only =
                    self.config.lock().await.get_allow_console_password_only();
                if !is_remote_service {
                    opts.push(AuthOption::Fido);
                    let cfg = self.config.lock().await;
                    if cfg.get_enable_experimental_passwordless_fido() {
                        opts.push(AuthOption::PasswordlessFido);
                    }
                    if cfg.get_enable_passwordless_security_key() {
                        opts.push(AuthOption::PasswordlessSecurityKey);
                    }
                    if cfg.get_enable_passwordless_qr_bluetooth() {
                        opts.push(AuthOption::PasswordlessQrBluetooth);
                    }
                }
                if is_remote_service || !console_password_only {
                    opts.push(AuthOption::ForceMFA);
                }
                if is_remote_service {
                    opts.push(AuthOption::RemoteSession);
                }
                // Do not use SFA fallback during Hello re-auth because we need
                // an MFA-capable result to preserve/re-seal the existing Hello
                // credentials.
                let sfa_enabled = if reauth_hello_pin.is_some() {
                    debug!("Hello reauth password flow: disabling SFA fallback.");
                    false
                } else {
                    self.config.lock().await.get_enable_sfa_fallback()
                };
                if sfa_enabled {
                    opts.push(AuthOption::NoDAGFallback);
                }
                let apply_policy = self.config.lock().await.get_apply_policy();
                if apply_policy {
                    opts.push(AuthOption::IntuneEnable);
                }

                // Call the appropriate method based on whether mfa_method is configured
                let mfa_method = self.config.lock().await.get_mfa_method();
                let mresp = self
                    .initiate_mfa_flow_with_fallback(
                        account_id,
                        Some(&cred),
                        &opts,
                        None,
                        mfa_method,
                    )
                    .await;

                // We need to wait to handle the response until after we've released
                // the write lock on the client, otherwise we will deadlock.
                let resp = net_down_check!(mresp,
                    Ok(resp) => resp,
                    Err(e) => {
                        // If SFA is disabled, we need to skip the SFA fallback.
                        let mtoken = if sfa_enabled {
                            // If we got an AADSTSError, then we don't want to
                            // perform a fallback, since the authentication
                            // legitimately failed.
                            if let MsalError::AADSTSError(ref e) = e {
                                // If the error is just requesting MFA (since we demanded it
                                // in the previous call), then continue with the SFA fallback.
                                // AADSTS50072: UserStrongAuthEnrollmentRequiredInterrupt
                                // AADSTS50074: UserStrongAuthClientAuthNRequiredInterrupt
                                // AADSTS50076: UserStrongAuthClientAuthNRequired
                                if ![50072, 50074, 50076].contains(&e.code) {
                                    error!(
                                        "Skipping SFA fallback because authentication failed: {:?}",
                                        e
                                    );
                                    return Ok((
                                        AuthResult::Denied(tr_fmt(
                                            "Authentication failed (AADSTS{code})",
                                            &[("code", e.code.to_string())],
                                        )),
                                        AuthCacheAction::None,
                                    ));
                                }
                            }
                            // We can only do a password auth for an enrolled device
                            if self.is_domain_joined(keystore).await {
                                warn!("MFA auth failed, falling back to SFA: {:?}", e);
                                // Again, we need to wait to handle the response until after
                                // we've released the write lock on the client, otherwise we
                                // will deadlock.
                                let res = self
                                    .client
                                    .lock()
                                    .await
                                    .acquire_token_by_username_password(
                                        account_id,
                                        &cred,
                                        vec![],
                                        Some("https://graph.microsoft.com".to_string()),
                                        None,
                                        tpm,
                                        machine_key,
                                    )
                                    .await;
                                net_down_check!(res,
                                    Ok(token) => Ok(token),
                                    Err(e) => {
                                        if let MsalError::ChangePassword = e {
                                            // The user needs to set a new password.
                                            *cred_handler =
                                                AuthCredHandler::ChangePassword { old_cred: cred };
                                            return Ok((
                                                AuthResult::Next(AuthRequest::ChangePassword {
                                                    msg: tr("Update your password\nYou need to update your password because this is\nthe first time you are signing in, or because your\npassword has expired."),
                                                }),
                                                AuthCacheAction::None,
                                            ));
                                        } else {
                                            Err(e)
                                        }
                                    }
                                )
                            } else {
                                error!("Single factor authentication is only permitted on an enrolled host: {:?}", e);
                                return Ok((AuthResult::Denied(msal_error_to_user_message(&e)), AuthCacheAction::None));
                            }
                        } else {
                            error!("{:?}", e);
                            return Ok((AuthResult::Denied(msal_error_to_user_message(&e)), AuthCacheAction::None));
                        };
                        let token = match mtoken {
                            Ok(token) => token,
                            Err(e) => {
                                error!("{:?}", e);
                                return Ok((AuthResult::Denied(msal_error_to_user_message(&e)), AuthCacheAction::None));
                            }
                        };
                        let token2 = enroll_and_obtain_enrolled_token!(token, Some(cred.clone()));
                        return match self.token_validate(account_id, &token2, None).await {
                            Ok(AuthResult::Success { token }) => {
                                // STOP! If we just enrolled with an SFA token, then we
                                // need to bail out here and refuse Hello enrollment
                                // (we can't enroll in Hello with an SFA token).
                                return Ok((
                                    AuthResult::Success { token },
                                    AuthCacheAction::PasswordHashUpdate { cred },
                                ));
                            }
                            Ok(auth_result) => Ok((auth_result, AuthCacheAction::None)),
                            Err(e) => Err(e),
                        };
                    }
                );
                nested_auth_handle_mfa_resp!(resp, cred, reauth_hello_pin)
            }
            (
                AuthCredHandler::MFA {
                    ref mut flow,
                    password,
                    ref reauth_hello_pin,
                    ..
                },
                PamAuthRequest::Input { cred },
            ) => {
                let reauth_hello_pin = reauth_hello_pin.clone();
                let token = net_down_check!(
                    self.client
                        .lock()
                        .await
                        .acquire_token_by_mfa_flow(account_id, Some(&cred), None, &mut *flow)
                        .await,
                    Ok(token) => token,
                    Err(e) => {
                        if let MsalError::ChangePassword = e {
                            if let Some(old_cred) = password {
                                // The user needs to set a new password.
                                *cred_handler = AuthCredHandler::ChangePassword {
                                    old_cred: old_cred.to_string(),
                                };
                                return Ok((
                                    AuthResult::Next(AuthRequest::ChangePassword {
                                        msg: tr("Update your password\nYou need to update your password because this is\nthe first time you are signing in, or because your\npassword has expired."),
                                    }),
                                    AuthCacheAction::None,
                                ));
                            } else {
                                error!("{:?}", e);
                                return Ok((AuthResult::Denied(msal_error_to_user_message(&e)), AuthCacheAction::None));
                            }
                        } else {
                            error!("{:?}", e);
                            return Ok((AuthResult::Denied(msal_error_to_user_message(&e)), AuthCacheAction::None));
                        }
                    }
                );
                let token2 = enroll_and_obtain_enrolled_token!(token, password.clone());
                match self.token_validate(account_id, &token2, None).await {
                    Ok(AuthResult::Success { token: token3 }) => {
                        let cache_action = match (
                            self.config.lock().await.get_offline_breakglass_enabled(),
                            password.as_ref(),
                        ) {
                            (true, Some(cred)) => {
                                AuthCacheAction::PasswordHashUpdate { cred: cred.clone() }
                            }
                            _ => AuthCacheAction::None,
                        };
                        reseal_prt_with_existing_hello_key_on_success!(
                            &token2,
                            reauth_hello_pin,
                            token3,
                            cache_action
                        );

                        // Skip Hello enrollment if it is disabled by config
                        let hello_enabled = self.config.lock().await.get_enable_hello();
                        if !hello_enabled || no_hello_pin {
                            info!("Skipping Hello enrollment because it is disabled");
                            return Ok((AuthResult::Success { token: token3 }, cache_action));
                        }
                        let hello_key_missing = self.fetch_hello_key(account_id, keystore).is_err();
                        if !hello_key_missing {
                            debug!("Skipping Hello enrollment because Hello is already configured");
                            return Ok((AuthResult::Success { token: token3 }, cache_action));
                        }

                        // Setup Windows Hello
                        *cred_handler = AuthCredHandler::SetupPin {
                            token: Box::new(Some(token)),
                        };
                        return Ok((
                            AuthResult::Next(AuthRequest::SetupPin {
                                msg: tr("Set up a PIN\nA Hello PIN is a fast, secure way to sign in to your device, apps, and services."),
                            }),
                            cache_action,
                        ));
                    }
                    Ok(auth_result) => Ok((auth_result, AuthCacheAction::None)),
                    Err(e) => Err(e),
                }
            }
            (
                AuthCredHandler::MFA {
                    ref mut flow,
                    password,
                    ref reauth_hello_pin,
                    ..
                },
                PamAuthRequest::MFAPoll { poll_attempt },
            ) => {
                let reauth_hello_pin = reauth_hello_pin.clone();
                let max_poll_attempts = flow.max_poll_attempts.unwrap_or(180);
                if poll_attempt > max_poll_attempts {
                    error!("MFA polling timed out");
                    return Ok((
                        AuthResult::Denied(tr("Authentication timed out. Please try again.")),
                        AuthCacheAction::None,
                    ));
                }
                let token = net_down_check!(
                    self.client
                        .lock()
                        .await
                        .acquire_token_by_mfa_flow(account_id, None, Some(poll_attempt), &mut *flow)
                        .await,
                    Ok(token) => token,
                    Err(e) => match e {
                        MsalError::ChangePassword => {
                            if let Some(old_cred) = password {
                                // The user needs to set a new password.
                                *cred_handler = AuthCredHandler::ChangePassword {
                                    old_cred: old_cred.to_string(),
                                };
                                return Ok((
                                    AuthResult::Next(AuthRequest::ChangePassword {
                                        msg: tr("Update your password\nYou need to update your password because this is\nthe first time you are signing in, or because your\npassword has expired."),
                                    }),
                                    AuthCacheAction::None,
                                ));
                            } else {
                                error!("{:?}", e);
                                return Ok((AuthResult::Denied(msal_error_to_user_message(&e)), AuthCacheAction::None));
                            }
                        }
                        MsalError::MFAPollContinue => {
                            return Ok((
                                AuthResult::Next(AuthRequest::MFAPollWait),
                                AuthCacheAction::None,
                            ));
                        }
                        MsalError::MFARequired => {
                            error!("MFA required but session lacks MFA claims. \
                                    This may indicate the MFA flow was initiated without ForceMFA.");
                            return Ok((
                                AuthResult::Denied(
                                    tr("Multi-factor authentication required. Please try signing in again."),
                                ),
                                AuthCacheAction::None,
                            ));
                        }
                        e => {
                            error!("{:?}", e);
                            return Ok((AuthResult::Denied(msal_error_to_user_message(&e)), AuthCacheAction::None));
                        }
                    }
                );
                // Check whether the token is a for the special MSA tenant,
                // meaning we need skip device enrollment (it's a personal
                // account).
                let msa_tenant = token.tenant_id().map_err(|e| {
                    error!("{:?}", e);
                    IdpError::NotFound {
                        what: "tenant_id from token".to_string(),
                        where_: "unix_user_online_auth_step".to_string(),
                    }
                })? == "9188040d-6c67-4c5b-b112-36a304b66dad";
                let token2 = if msa_tenant {
                    token.clone()
                } else {
                    enroll_and_obtain_enrolled_token!(token, password.clone())
                };
                match self.token_validate(account_id, &token2, None).await {
                    Ok(AuthResult::Success { token: token3 }) => {
                        let cache_action = match (
                            self.config.lock().await.get_offline_breakglass_enabled(),
                            password.as_ref(),
                        ) {
                            (true, Some(cred)) => {
                                AuthCacheAction::PasswordHashUpdate { cred: cred.clone() }
                            }
                            _ => AuthCacheAction::None,
                        };
                        reseal_prt_with_existing_hello_key_on_success!(
                            &token2,
                            reauth_hello_pin,
                            token3,
                            cache_action
                        );

                        // Skip Hello enrollment if it is disabled by config
                        let hello_enabled = self.config.lock().await.get_enable_hello();
                        if !hello_enabled || no_hello_pin {
                            info!("Skipping Hello enrollment because it is disabled");
                            return Ok((AuthResult::Success { token: token3 }, cache_action));
                        }
                        let hello_key_missing = self.fetch_hello_key(account_id, keystore).is_err();
                        if !hello_key_missing {
                            debug!("Skipping Hello enrollment because Hello is already configured");
                            return Ok((AuthResult::Success { token: token3 }, cache_action));
                        }

                        // Setup Windows Hello
                        *cred_handler = AuthCredHandler::SetupPin {
                            token: Box::new(Some(token)),
                        };
                        return Ok((
                            AuthResult::Next(AuthRequest::SetupPin {
                                msg: tr("Set up a PIN\nA Hello PIN is a fast, secure way to sign in to your device, apps, and services."),
                            }),
                            cache_action,
                        ));
                    }
                    Ok(auth_result) => Ok((auth_result, AuthCacheAction::None)),
                    Err(e) => Err(e),
                }
            }
            (AuthCredHandler::MFA { .. }, PamAuthRequest::FidoUnavailable) => {
                debug!("FIDO hardware unavailable on client, falling back to password");
                *cred_handler = AuthCredHandler::None;
                Ok((
                    AuthResult::Next(AuthRequest::Password {
                        prompt: None,
                        long_prompt: None,
                    }),
                    AuthCacheAction::None,
                ))
            }
            (
                AuthCredHandler::MFA {
                    ref mut flow,
                    password,
                    ref reauth_hello_pin,
                    ..
                },
                PamAuthRequest::Fido { assertion },
            ) => {
                let reauth_hello_pin = reauth_hello_pin.clone();
                let token = net_down_check!(
                    self.client
                        .lock()
                        .await
                        .acquire_token_by_mfa_flow(account_id, Some(&assertion), None, &mut *flow)
                        .await,
                    Ok(token) => token,
                    Err(e) => {
                        if let MsalError::ChangePassword = e {
                            if let Some(old_cred) = password {
                                // The user needs to set a new password.
                                *cred_handler = AuthCredHandler::ChangePassword {
                                    old_cred: old_cred.to_string(),
                                };
                                return Ok((
                                    AuthResult::Next(AuthRequest::ChangePassword {
                                        msg: tr("Update your password\nYou need to update your password because this is\nthe first time you are signing in, or because your\npassword has expired."),
                                    }),
                                    AuthCacheAction::None,
                                ));
                            } else {
                                error!("{:?}", e);
                                return Ok((AuthResult::Denied(msal_error_to_user_message(&e)), AuthCacheAction::None));
                            }
                        } else {
                            error!("{:?}", e);
                            return Ok((AuthResult::Denied(msal_error_to_user_message(&e)), AuthCacheAction::None));
                        }
                    }
                );
                let token2 = enroll_and_obtain_enrolled_token!(token, password.clone());
                match self.token_validate(account_id, &token2, None).await {
                    Ok(AuthResult::Success { token: token3 }) => {
                        let cache_action = match (
                            self.config.lock().await.get_offline_breakglass_enabled(),
                            password.as_ref(),
                        ) {
                            (true, Some(cred)) => {
                                AuthCacheAction::PasswordHashUpdate { cred: cred.clone() }
                            }
                            _ => AuthCacheAction::None,
                        };
                        reseal_prt_with_existing_hello_key_on_success!(
                            &token2,
                            reauth_hello_pin,
                            token3,
                            cache_action
                        );

                        // Skip Hello enrollment if it is disabled by config
                        let hello_enabled = self.config.lock().await.get_enable_hello();
                        if !hello_enabled || no_hello_pin {
                            info!("Skipping Hello enrollment because it is disabled");
                            return Ok((AuthResult::Success { token: token3 }, cache_action));
                        }
                        let hello_key_missing = self.fetch_hello_key(account_id, keystore).is_err();
                        if !hello_key_missing {
                            debug!("Skipping Hello enrollment because Hello is already configured");
                            return Ok((AuthResult::Success { token: token3 }, cache_action));
                        }

                        // Setup Windows Hello
                        *cred_handler = AuthCredHandler::SetupPin {
                            token: Box::new(Some(token)),
                        };
                        return Ok((
                            AuthResult::Next(AuthRequest::SetupPin {
                                msg: tr("Set up a PIN\nA Hello PIN is a fast, secure way to sign in to your device, apps, and services."),
                            }),
                            cache_action,
                        ));
                    }
                    Ok(auth_result) => Ok((auth_result, AuthCacheAction::None)),
                    Err(e) => Err(e),
                }
            }
            (
                AuthCredHandler::HelloTOTP {
                    cred: hello_pin,
                    pending_sealed_totp,
                },
                PamAuthRequest::HelloTOTP { cred },
            ) => {
                impl_handle_hello_pin_totp_auth!(
                    self,
                    account_id,
                    keystore,
                    old_token,
                    cred,
                    hello_pin,
                    tpm,
                    machine_key,
                    pending_sealed_totp,
                    |auth_result| { (auth_result, AuthCacheAction::None) }
                )
            }
            _ => {
                error!("Unexpected AuthCredHandler and PamAuthRequest pairing");
                Err(IdpError::NotFound {
                    what: "AuthCredHandler, PamAuthRequest".to_string(),
                    where_: "cred_handler, pam_next_req".to_string(),
                })
            }
        }
    }

    #[instrument(skip(self, account_id, _token, keystore))]
    async fn unix_user_offline_auth_init<D: KeyStoreTxn + Send>(
        &self,
        account_id: &str,
        _token: Option<&UserToken>,
        service: &str,
        no_hello_pin: bool,
        keystore: &mut D,
    ) -> Result<(AuthRequest, AuthCredHandler), IdpError> {
        impl_himmelblau_offline_auth_init!(self, account_id, service, no_hello_pin, keystore, true)
    }

    #[instrument(skip_all)]
    async fn unix_user_offline_auth_step<D: KeyStoreTxn + Send>(
        &self,
        account_id: &str,
        token: &UserToken,
        cred_handler: &mut AuthCredHandler,
        pam_next_req: PamAuthRequest,
        keystore: &mut D,
        tpm: &mut tpm::provider::BoxedDynTpm,
        machine_key: &tpm::structures::StorageKey,
        _online_at_init: bool,
    ) -> Result<AuthResult, IdpError> {
        impl_himmelblau_offline_auth_step!(
            cred_handler,
            pam_next_req,
            self,
            account_id,
            keystore,
            tpm,
            machine_key,
            token,
            load_cached_prt
        )
    }

    #[instrument(skip_all)]
    async fn unix_user_try_unseal<D: KeyStoreTxn + Send>(
        &self,
        account_id: &str,
        cred: &str,
        keystore: &mut D,
        tpm: &mut tpm::provider::BoxedDynTpm,
        machine_key: &tpm::structures::StorageKey,
        online: bool,
    ) -> Result<bool, IdpError> {
        impl_himmelblau_try_unseal!(
            self,
            account_id,
            cred,
            keystore,
            tpm,
            machine_key,
            online,
            load_cached_prt_for_try_unseal
        )
    }

    async fn unix_group_get(
        &self,
        _id: &Id,
        _tpm: &mut tpm::provider::BoxedDynTpm,
    ) -> Result<GroupToken, IdpError> {
        /* AAD doesn't permit group listing (must use cache entries from auth) */
        debug!("Group listing not supported in HimmelblauProvider");
        Err(IdpError::BadRequest)
    }

    async fn get_cachestate<D: KeyStoreTxn + Send>(
        &self,
        _account_id: Option<&str>,
        _keystore: &mut D,
    ) -> CacheState {
        (*self.state.lock().await).clone()
    }
}

impl HimmelblauProvider {
    #[instrument(level = "debug", skip_all)]
    async fn delayed_init(&self) -> Result<(), IdpError> {
        // The purpose of this function is to delay initialization as long as
        // possible. This permits the daemon to start, without requiring we be
        // connected to the internet. This way we can send messages to the user
        // via PAM indicating that the network is down.
        self.init
            .get_or_try_init(|| async {
                // Send the federation provider request, if necessary. If these were
                // cached previously, then a network connection is not necessary at
                // this moment. If they were not cached, and supplied to the graph
                // object, then we require a network connection now.
                let tenant_id = self.graph.tenant_id().await.map_err(|e| {
                    error!("Failed discovering the tenant_id: {}", e);
                    IdpError::BadRequest
                })?;
                let authority_host = self.graph.authority_host().await.map_err(|e| {
                    error!("Failed discovering the authority_host: {}", e);
                    IdpError::BadRequest
                })?;
                let graph_url = self.graph.graph_url().await.map_err(|e| {
                    error!("Failed discovering the graph_url: {}", e);
                    IdpError::BadRequest
                })?;

                // Initialize the idmap range
                let range = self.config.lock().await.get_idmap_range(&self.domain);
                let mut idmap = self.idmap.lock().await;
                idmap
                    .add_gen_domain(&self.domain, &tenant_id, range)
                    .map_err(|e| {
                        error!("Failed adding the idmap domain: {}", e);
                        IdpError::BadRequest
                    })?;
                drop(idmap);

                // Set the authority on the app
                let authority_url = format!("https://{}/{}", authority_host, tenant_id);
                // A client write lock is required here.
                self.client
                    .lock()
                    .await
                    .set_authority(&authority_url)
                    .map_err(|e| {
                        error!("Failed setting the authority_url: {}", e);
                        IdpError::BadRequest
                    })?;

                // Cache the federation provider responses
                let mut cfg = self.config.lock().await;
                cfg.set(&self.domain, "tenant_id", &tenant_id);
                debug!(
                    "Setting domain {} config tenant_id to {}",
                    self.domain, tenant_id
                );
                cfg.set(&self.domain, "authority_host", &authority_host);
                debug!(
                    "Setting domain {} config authority_host to {}",
                    self.domain, authority_host
                );
                cfg.set(&self.domain, "graph_url", &graph_url);
                debug!(
                    "Setting domain {} config graph_url to {}",
                    self.domain, graph_url
                );
                if let Err(e) = cfg.write_server_config() {
                    error!("Failed to write federation provider configuration: {:?}", e);
                }

                Ok(())
            })
            .await?;
        Ok(())
    }

    #[instrument(level = "debug", skip_all)]
    async fn attempt_online(&self, _tpm: &mut tpm::provider::BoxedDynTpm, now: SystemTime) -> bool {
        let authority_host = self
            .graph
            .authority_host()
            .await
            .unwrap_or(self.config.lock().await.get_authority_host(&self.domain));
        let request_timeout = self.config.lock().await.get_request_timeout();
        // The authority root may redirect to an unrelated, proxy-blocked host.
        // A response from the authority itself is sufficient for reachability.
        let client =
            match build_online_probe_client(request_timeout, reqwest::redirect::Policy::none()) {
                Ok(c) => c,
                Err(e) => {
                    error!(?e, "Failed to build HTTP client for online check");
                    let mut state = self.state.lock().await;
                    *state = CacheState::OfflineNextCheck(now + OFFLINE_NEXT_CHECK);
                    return false;
                }
            };
        match client
            .get(format!("https://{}", authority_host))
            .send()
            .await
        {
            Ok(_) => {
                debug!("provider is now online");
                let mut state = self.state.lock().await;
                *state = CacheState::Online;
                return true;
            }
            Err(err) => {
                error!(?err, "Provider online failed");
                let mut state = self.state.lock().await;
                *state = CacheState::OfflineNextCheck(now + OFFLINE_NEXT_CHECK);
                return false;
            }
        }
    }

    impl_himmelblau_hello_key_helpers!();

    fn fetch_cert_key_tag(&self) -> String {
        format!("{}/certificate", self.domain)
    }

    fn fetch_intune_key_tag(&self) -> String {
        format!("{}/intune", self.domain)
    }

    fn fetch_tranport_key_tag(&self) -> String {
        format!("{}/transport", self.domain)
    }

    #[instrument(level = "debug", skip_all)]
    fn fetch_loadable_transport_key_from_keystore<D: KeyStoreTxn + Send>(
        &self,
        keystore: &mut D,
    ) -> Result<Option<LoadableMsOapxbcRsaKey>, IdpError> {
        let transport_tag = self.fetch_tranport_key_tag();
        let loadable_id_key: Option<LoadableMsOapxbcRsaKey> = keystore
            .get_tagged_hsm_key(&transport_tag)
            .map_err(|ks_err| {
                error!(?ks_err);
                IdpError::KeyStore
            })?;

        Ok(loadable_id_key)
    }

    #[instrument(level = "debug", skip_all)]
    fn fetch_loadable_cert_key_from_keystore<D: KeyStoreTxn + Send>(
        &self,
        keystore: &mut D,
    ) -> Result<Option<LoadableMsDeviceEnrolmentKey>, IdpError> {
        let csr_tag = self.fetch_cert_key_tag();
        let loadable_id_key: Option<LoadableMsDeviceEnrolmentKey> =
            keystore.get_tagged_hsm_key(&csr_tag).map_err(|ks_err| {
                error!(?ks_err);
                IdpError::KeyStore
            })?;

        Ok(loadable_id_key)
    }

    /// Try to check if sign-in frequency is satisfied via PRT exchange.
    /// Returns:
    /// - Some(Ok(token)) if PRT exchange succeeded (sign-in frequency satisfied)
    /// - Some(Err(reason)) if PRT exchange failed (sign-in frequency not satisfied)
    /// - None if no PRT is cached for this user
    #[instrument(level = "debug", skip_all)]
    async fn try_prt_signin_frequency_check(
        &self,
        account_id: &str,
        tpm: &mut tpm::provider::BoxedDynTpm,
        machine_key: &tpm::structures::StorageKey,
    ) -> Option<Result<UnixUserToken, String>> {
        // Check if we have a cached PRT for this user
        let prt = match self.refresh_cache.refresh_token(account_id).await {
            Ok(RefreshCacheEntry::Prt(prt)) => prt,
            Ok(_) => {
                debug!("Cached refresh token is not a PRT");
                return None;
            }
            Err(_) => {
                debug!("No refresh token cached");
                return None;
            }
        };

        // Try PRT exchange to check sign-in frequency
        let (client_id, scopes) = if self.config.lock().await.get_app_id(&self.domain).is_some() {
            (None, vec!["GroupMember.Read.All"])
        } else {
            (
                Some(EDGE_BROWSER_CLIENT_ID),
                vec!["https://graph.microsoft.com/.default"],
            )
        };
        let prt_result = self
            .client
            .lock()
            .await
            .exchange_prt_for_access_token(
                &prt,
                scopes.clone(),
                None,
                client_id,
                tpm,
                machine_key,
                None,
                None,
            )
            .await;
        let prt_result = match prt_result {
            Err(MsalError::RequestFailed(msg)) => {
                error!(
                    "PRT exchange failed, retrying after network error: {:?}",
                    msg
                );
                sleep(Duration::from_millis(500));
                self.client
                    .lock()
                    .await
                    .exchange_prt_for_access_token(
                        &prt,
                        scopes,
                        None,
                        client_id,
                        tpm,
                        machine_key,
                        None,
                        None,
                    )
                    .await
            }
            Err(MsalError::AcquireTokenFailed(err_resp)) => {
                if err_resp.error_codes.contains(&CONSENT_REQUIRED) {
                    /* Consent has not been granted for the application
                     * to access the Graph API. Retry without Graph API
                     * scopes - authentication can still proceed but group
                     * names will not be resolved. */
                    warn!(
                        "Consent not granted for Graph API access. \
                       Retrying token exchange without Graph API scopes."
                    );
                    self.client
                        .lock()
                        .await
                        .exchange_prt_for_access_token(
                            &prt,
                            vec![],
                            None,
                            None,
                            tpm,
                            machine_key,
                            None,
                            None,
                        )
                        .await
                } else if client_id == Some(EDGE_BROWSER_CLIENT_ID) {
                    /* Authentication failed with Edge Browser client ID.
                     * Fall back to default app ID - group names may not
                     * be resolved but authentication can proceed. */
                    info!(
                        "Token acquisition failed with Edge Browser app ({}). \
                         Retrying with default app ID.",
                        err_resp.error_description
                    );
                    self.client
                        .lock()
                        .await
                        .exchange_prt_for_access_token(
                            &prt,
                            scopes.clone(),
                            None,
                            Some(DEFAULT_APP_ID),
                            tpm,
                            machine_key,
                            None,
                            None,
                        )
                        .await
                } else {
                    Err(MsalError::AcquireTokenFailed(err_resp))
                }
            }
            Err(MsalError::AADSTSError(_)) if client_id == Some(EDGE_BROWSER_CLIENT_ID) => {
                /* AADSTS error with Edge Browser client ID (e.g. CA
                 * policy requiring device compliance). Fall back to
                 * default app ID. */
                info!(
                    "AADSTS error with Edge Browser app. \
                     Retrying with default app ID."
                );
                self.client
                    .lock()
                    .await
                    .exchange_prt_for_access_token(
                        &prt,
                        scopes,
                        None,
                        Some(DEFAULT_APP_ID),
                        tpm,
                        machine_key,
                        None,
                        None,
                    )
                    .await
            }
            result => result,
        };

        match prt_result {
            Ok(mut msal_token) => {
                // PRT exchange succeeded - sign-in frequency is satisfied!
                // Request a new PRT to refresh the cache
                match self
                    .client
                    .lock()
                    .await
                    .exchange_prt_for_prt(&prt, tpm, machine_key, true)
                    .await
                {
                    Ok(new_prt) => {
                        msal_token.prt = Some(new_prt.clone());
                        self.refresh_cache
                            .add(account_id, &RefreshCacheEntry::Prt(new_prt))
                            .await;
                    }
                    Err(err) => {
                        error!(
                            ?err,
                            "PRT refresh failed after successful PRT access token exchange; keeping cached PRT"
                        );
                    }
                }
                Some(Ok(msal_token))
            }
            Err(MsalError::MFARequired) => Some(Err(
                "PRT exchange requires MFA - sign-in frequency expired".to_string(),
            )),
            Err(MsalError::RequestFailed(msg)) => {
                let url = extract_base_url!(msg);
                info!(?url, "Network down detected");
                let mut state = self.state.lock().await;
                *state = CacheState::OfflineNextCheck(SystemTime::now() + OFFLINE_NEXT_CHECK);
                None
            }
            Err(e) => Some(Err(format!("PRT exchange failed: {:?}", e))),
        }
    }

    #[instrument(level = "debug", skip_all)]
    async fn token_validate(
        &self,
        account_id: &str,
        token: &UnixUserToken,
        old_token: Option<&UserToken>,
    ) -> Result<AuthResult, IdpError> {
        // UUID is only used for logging; tolerate tokens where the oid claim is
        // absent or empty (e.g. device-flow tokens that lack the oid claim) by
        // falling back to an explicit "unknown" value rather than the requested
        // account_id, so logs remain accurate about the authenticated user.
        let uuid = token
            .uuid()
            .map(|u| u.to_string())
            .unwrap_or_else(|_| "unknown".to_string());
        match &token.access_token {
            Some(_) => {
                /* Fixes bug#37: MFA can respond with different user than requested.
                 * Azure resource names are case insensitive.
                 */
                let spn = token.spn().map_err(|e| {
                    error!("Failed fetching user spn: {:?}", e);
                    IdpError::BadRequest
                })?;
                if account_id.to_string().to_lowercase() != spn.to_string().to_lowercase() {
                    /* Fixes bug#801: The authenticated user might have a mis-matched
                     * response because the domains are aliases of one another.
                     * Both the local part AND the domains must match — otherwise a
                     * different user authenticating in the same tenant would be
                     * silently accepted (e.g. user2 unlocking user1's locked screen
                     * via a passkey QR scan).
                     */
                    let (local1, domain1) = split_username(account_id).ok_or_else(|| {
                        error!("Failed splitting account_id username");
                        IdpError::BadRequest
                    })?;
                    let (local2, domain2) = split_username(&spn).ok_or_else(|| {
                        error!("Failed splitting spn username");
                        IdpError::BadRequest
                    })?;
                    let domains_match = self.domains_are_aliases(domain1, domain2).await;
                    if local1.to_lowercase() != local2.to_lowercase() || !domains_match {
                        let msg = tr_fmt(
                            "Authenticated user {user} does not match requested user",
                            &[("user", uuid.to_string())],
                        );
                        error!("{}", msg);
                        return Ok(AuthResult::Denied(msg));
                    }
                }
                info!("Authentication successful for user '{}'", uuid);
                // If an encrypted PRT is present, store it in the mem cache
                if let Some(prt) = &token.prt {
                    self.refresh_cache
                        .add(account_id, &RefreshCacheEntry::Prt(prt.clone()))
                        .await;
                }
                // MSA Accounts don't have PRTs, so instead cache the refresh token
                else {
                    self.refresh_cache
                        .add(
                            account_id,
                            &RefreshCacheEntry::RefreshToken(token.refresh_token.clone()),
                        )
                        .await;
                }
                Ok(AuthResult::Success {
                    token: self
                        .user_token_from_unix_user_token(
                            account_id,
                            TokenOrObj::UserToken(Box::new(token.clone())),
                            old_token,
                        )
                        .await?,
                })
            }
            None => {
                info!("Authentication failed for user '{}'", uuid);
                Err(IdpError::NotFound {
                    what: "access_token".to_string(),
                    where_: "token_validate".to_string(),
                })
            }
        }
    }

    #[instrument(level = "debug", skip_all)]
    async fn user_token_from_unix_user_token(
        &self,
        spn: &str,
        value: TokenOrObj,
        old_token: Option<&UserToken>,
    ) -> Result<UserToken, IdpError> {
        let mut groups: Vec<GroupToken>;
        let posix_attrs: HashMap<String, String>;
        let spn = spn.to_lowercase();
        let uuid = match &value {
            TokenOrObj::UserObj((_, value)) => Uuid::parse_str(&value.id).map_err(|e| {
                error!("Failed fetching user uuid: {:?}", e);
                IdpError::BadRequest
            })?,
            TokenOrObj::UserToken(value) => value.uuid().map_err(|e| {
                error!("Failed fetching user uuid: {:?}", e);
                IdpError::BadRequest
            })?,
        };
        let access_token = match &value {
            TokenOrObj::UserObj((token, _)) => Some(token.access_token.clone()),
            TokenOrObj::UserToken(value) => value.access_token.clone(),
        };
        match &access_token {
            Some(access_token) => {
                groups = match self
                    .graph
                    .request_user_groups_by_user_id(access_token, &uuid.to_string())
                    .await
                {
                    Ok(groups) => {
                        let mut gt_groups = vec![];
                        for g in groups {
                            match self.group_token_from_directory_object(g).await {
                                Ok(group) => gt_groups.push(group),
                                Err(e) => {
                                    debug!("Failed fetching group for user {}: {}", uuid, e)
                                }
                            };
                        }
                        gt_groups
                    }
                    Err(_e) => {
                        debug!("Failed fetching user groups for {}", uuid);
                        /* If we failed to fetch the groups, and we have an old
                         * token, preserve the existing cached group memberships.
                         */
                        match old_token {
                            Some(old_token) => old_token.groups.clone(),
                            None => vec![],
                        }
                    }
                };
                posix_attrs = if self.config.lock().await.get_id_attr_map() == IdAttr::Rfc2307 {
                    match self
                        .graph
                        .fetch_user_extension_attributes_by_user_id(
                            access_token,
                            &uuid.to_string(),
                            vec![
                                "uidNumber",
                                "gidNumber",
                                "loginShell",
                                "gecos",
                                "unixHomeDirectory",
                            ],
                        )
                        .await
                    {
                        Ok(posix_attrs) => posix_attrs,
                        Err(e) => {
                            debug!("Failed fetching user posix attributes: {:?}", e);
                            HashMap::new()
                        }
                    }
                } else {
                    HashMap::new()
                };
            }
            None => {
                debug!("Failed fetching user groups for {}", uuid);
                /* If we failed to fetch the groups, and we have an old
                 * token, preserve the existing cached group memberships.
                 */
                groups = match old_token {
                    Some(old_token) => old_token.groups.clone(),
                    None => vec![],
                };
                posix_attrs = HashMap::new();
            }
        };
        let valid = true;
        let user_map = UserMap::new(&self.config.lock().await.get_user_map_file());
        let (uidnumber, gidnumber) = match user_map.get_local_from_upn(&spn) {
            Some(user) => {
                let passwd = tokio::fs::read("/etc/passwd").await.map_err(|e| {
                    error!("Failed reading /etc/passwd for mapped user {}: {}", user, e);
                    IdpError::BadRequest
                })?;
                local_user_ids_from_passwd(&passwd, &user).ok_or(IdpError::NotFound {
                    what: user,
                    where_: "local user map".to_string(),
                })?
            }
            None => {
                let idmap_cache = StaticIdCache::new(ID_MAP_CACHE, false).map_err(|e| {
                    error!("Failed reading from the idmap cache: {:?}", e);
                    IdpError::BadRequest
                })?;
                match idmap_cache.get_user_by_name(&spn) {
                    Some(user) => (user.uid, user.gid),
                    None => {
                        let id_attr_map = self.config.lock().await.get_id_attr_map();
                        let uidnumber = match id_attr_map {
                            IdAttr::Uuid => self
                                .idmap
                                .lock()
                                .await
                                .object_id_to_unix_id(
                                    &self.graph.tenant_id().await.map_err(|e| {
                                        error!("{:?}", e);
                                        IdpError::BadRequest
                                    })?,
                                    &AadSid::from_object_id(&uuid).map_err(|e| {
                                        error!("Failed parsing object id: {:?}", e);
                                        IdpError::BadRequest
                                    })?,
                                )
                                .map_err(|e| {
                                    error!("{:?}", e);
                                    IdpError::BadRequest
                                })?,
                            IdAttr::Name => self
                                .idmap
                                .lock()
                                .await
                                .gen_to_unix(
                                    &self.graph.tenant_id().await.map_err(|e| {
                                        error!("{:?}", e);
                                        IdpError::BadRequest
                                    })?,
                                    &spn,
                                )
                                .map_err(|e| {
                                    error!("{:?}", e);
                                    IdpError::BadRequest
                                })?,
                            IdAttr::Rfc2307 => match posix_attrs.get("uidNumber") {
                                Some(uid_number) => {
                                    let uid_number = uid_number.parse::<u32>().map_err(|e| {
                                        error!(
                                            "Invalid uidNumber ('{}') synced from on-prem AD: {:?}",
                                            uid_number, e
                                        );
                                        IdpError::BadRequest
                                    })?;
                                    // Never hand a directory identity the UID of a
                                    // systemd dynamic user (such as himmelblaud
                                    // itself). See GHSA-6gp8-pp9v-gx45.
                                    if is_systemd_dynamic_id(uid_number) {
                                        error!(
                                            "Refusing uidNumber {} for user {}: {}-{} is reserved for systemd dynamic users",
                                            uid_number,
                                            uuid,
                                            SYSTEMD_DYNAMIC_ID_MIN,
                                            SYSTEMD_DYNAMIC_ID_MAX
                                        );
                                        return Err(IdpError::BadRequest);
                                    }
                                    uid_number
                                }
                                None => {
                                    error!(
                                        "User {} has no uidNumber defined in the directory!",
                                        uuid
                                    );
                                    return Err(IdpError::BadRequest);
                                }
                            },
                        };

                        // Utilize the existing primary group if set
                        let gidnumber = if let Some(gid_number) = posix_attrs.get("gidNumber") {
                            let gid_number = gid_number.parse::<u32>().map_err(|e| {
                                error!(
                                    "Invalid gidNumber ('{}') synced from on-prem AD: {:?}",
                                    gid_number, e
                                );
                                IdpError::BadRequest
                            })?;
                            // Never hand a directory identity the GID of a systemd
                            // dynamic user. See GHSA-6gp8-pp9v-gx45.
                            if is_systemd_dynamic_id(gid_number) {
                                error!(
                                    "Refusing gidNumber {} for user {}: {}-{} is reserved for systemd dynamic users",
                                    gid_number,
                                    uuid,
                                    SYSTEMD_DYNAMIC_ID_MIN,
                                    SYSTEMD_DYNAMIC_ID_MAX
                                );
                                return Err(IdpError::BadRequest);
                            }
                            gid_number
                        } else {
                            // Otherwise add a fake primary group
                            groups.push(GroupToken {
                                name: spn.clone(),
                                spn: spn.clone(),
                                uuid,
                                gidnumber: uidnumber,
                            });
                            uidnumber
                        };
                        (uidnumber, gidnumber)
                    }
                }
            }
        };

        let displayname = match posix_attrs.get("gecos") {
            Some(gecos) => gecos.clone(),
            None => match &value {
                TokenOrObj::UserObj((_, value)) => value.displayname.clone(),
                TokenOrObj::UserToken(value) => value.id_token.name.clone(),
            },
            //value.id_token.name.clone(),
        };

        let displayname = flip_displayname_comma(&displayname);

        let shell = match posix_attrs.get("loginShell") {
            Some(login_shell) => login_shell.clone(),
            None => self.config.lock().await.get_shell(Some(&self.domain)),
        };

        if posix_attrs.contains_key("unixHomeDirectory") {
            // TODO: Implement homedir mapping
            warn!(
                "Himmelblau did not map unixHomeDirectory from Azure Entra Connector sync for user {}",
                uuid
            );
        }

        Ok(UserToken {
            name: spn.clone(),
            spn: spn.clone(),
            uuid,
            real_gidnumber: Some(gidnumber),
            gidnumber: uidnumber,
            displayname,
            shell: Some(shell),
            groups,
            tenant_id: Some(
                Uuid::parse_str(&self.graph.tenant_id().await.map_err(|e| {
                    error!("{:?}", e);
                    IdpError::BadRequest
                })?)
                .map_err(|e| {
                    error!("{:?}", e);
                    IdpError::BadRequest
                })?,
            ),
            valid,
        })
    }

    #[instrument(level = "debug", skip_all)]
    async fn group_token_from_directory_object(
        &self,
        value: DirectoryObject,
    ) -> Result<GroupToken> {
        let name = match value.display_name {
            Some(name) => name,
            None => value.id.clone(),
        };
        // Prohibit group names which look like a UPN
        if name.contains("@") {
            // Including the "@" symbol in a group name is discouraged by MS,
            // and permits a potential name collision risk (a user could
            // create a group which collides with a fake primary group).
            // Group names with an "@" will also resolve via NSS, which we
            // NEVER permit (see CVE-2025-49012).
            return Err(anyhow!("Group names cannot contain the '@' symbol."));
        }
        let id =
            Uuid::parse_str(&value.id).map_err(|e| anyhow!("Failed parsing user uuid: {}", e))?;
        let idmap_cache_entry = StaticIdCache::new(ID_MAP_CACHE, false)
            .ok()
            .and_then(|idmap_cache| idmap_cache.get_group_by_name(&id.to_string()));
        let id_attr_map = self.config.lock().await.get_id_attr_map();
        let rfc2307_group_fallback_map = self.config.lock().await.get_rfc2307_group_fallback_map();
        let gidnumber = match idmap_cache_entry {
            Some(group) => group.gid,
            None => match id_attr_map {
                IdAttr::Uuid => self
                    .idmap
                    .lock()
                    .await
                    .object_id_to_unix_id(
                        &self
                            .graph
                            .tenant_id()
                            .await
                            .map_err(|e| anyhow!("{:?}", e))?,
                        &AadSid::from_object_id(&id)
                            .map_err(|e| anyhow!("Failed parsing object id: {:?}", e))?,
                    )
                    .map_err(|e| anyhow!("Failed fetching gid for {}: {:?}", id, e))?,
                IdAttr::Name => self
                    .idmap
                    .lock()
                    .await
                    .gen_to_unix(
                        &self
                            .graph
                            .tenant_id()
                            .await
                            .map_err(|e| anyhow!("{:?}", e))?,
                        &id.to_string(),
                    )
                    .map_err(|e| anyhow!("Failed fetching gid for {}: {:?}", name, e))?,
                IdAttr::Rfc2307 => match value.extension_attrs.get("gidNumber") {
                    Some(gid_number) => {
                        let gid_number = gid_number.parse::<u32>().map_err(|e| {
                            anyhow!(
                                "Invalid gidNumber ('{}') synced from on-prem AD: {:?}",
                                gid_number,
                                e
                            )
                        })?;
                        // Never hand a directory group the GID of a systemd
                        // dynamic user. See GHSA-6gp8-pp9v-gx45.
                        if is_systemd_dynamic_id(gid_number) {
                            return Err(anyhow!(
                                "Refusing gidNumber {} for group {}: {}-{} is reserved for systemd dynamic users",
                                gid_number,
                                name,
                                SYSTEMD_DYNAMIC_ID_MIN,
                                SYSTEMD_DYNAMIC_ID_MAX
                            ));
                        }
                        gid_number
                    }
                    None => match rfc2307_group_fallback_map {
                        Some(IdAttr::Uuid) => self
                            .idmap
                            .lock()
                            .await
                            .object_id_to_unix_id(
                                &self
                                    .graph
                                    .tenant_id()
                                    .await
                                    .map_err(|e| anyhow!("{:?}", e))?,
                                &AadSid::from_object_id(&id)
                                    .map_err(|e| anyhow!("Failed parsing object id: {:?}", e))?,
                            )
                            .map_err(|e| anyhow!("Failed fetching gid for {}: {:?}", id, e))?,
                        Some(IdAttr::Name) => self
                            .idmap
                            .lock()
                            .await
                            .gen_to_unix(
                                &self
                                    .graph
                                    .tenant_id()
                                    .await
                                    .map_err(|e| anyhow!("{:?}", e))?,
                                &name,
                            )
                            .map_err(|e| anyhow!("Failed fetching gid for {}: {:?}", name, e))?,
                        Some(_) | None => {
                            return Err(anyhow!(
                            "Group {} has no gidNumber defined in the directory and no fallback was set!",
                            name
                        ));
                        }
                    },
                },
            },
        };

        Ok(GroupToken {
            name: name.clone(),
            spn: name.to_string(),
            uuid: id,
            gidnumber,
        })
    }

    #[instrument(level = "debug", skip_all)]
    async fn join_domain<D: KeyStoreTxn + Send>(
        &self,
        tpm: &mut tpm::provider::BoxedDynTpm,
        token: &UnixUserToken,
        keystore: &mut D,
        machine_key: &tpm::structures::StorageKey,
    ) -> Result<(), MsalError> {
        let join_type = self.config.lock().await.get_join_type();
        /* If not already joined, join the domain now. */
        let attrs = EnrollAttrs::new(
            self.domain.clone(),
            None,
            None,
            Some(join_type.into()),
            None,
        )?;
        // A client write lock is required here.
        let res = self
            .client
            .lock()
            .await
            .enroll_device(&token.refresh_token, attrs.clone(), tpm, machine_key)
            .await;
        match res {
            Ok((new_loadable_transport_key, new_loadable_cert_key, device_id)) => {
                info!("Joined domain {} with device id {}", self.domain, device_id);
                // Store the new_loadable_cert_key in the keystore
                let csr_tag = self.fetch_cert_key_tag();
                if let Err(e) = keystore.insert_tagged_hsm_key(&csr_tag, &new_loadable_cert_key) {
                    return Err(MsalError::TPMFail(format!(
                        "Failed to join the domain: {:?}",
                        e
                    )));
                }
                // Store the new_loadable_transport_key
                let transport_tag = self.fetch_tranport_key_tag();
                if let Err(e) =
                    keystore.insert_tagged_hsm_key(&transport_tag, &new_loadable_transport_key)
                {
                    return Err(MsalError::TPMFail(format!(
                        "Failed to join the domain: {:?}",
                        e
                    )));
                }

                let intune_device_id = match self
                    .intune_enroll(Some(&device_id), Some(&attrs), tpm, token, machine_key)
                    .await
                {
                    Ok((intune_key, intune_device_id)) => {
                        let intune_tag = self.fetch_intune_key_tag();
                        if let Err(e) = keystore.insert_tagged_hsm_key(&intune_tag, &intune_key) {
                            error!(?e, "Failed inserting the intune key into the keystore.");
                            return Err(MsalError::GeneralFailure(format!(
                                "Failed to enroll in Intune: {:?}",
                                e
                            )));
                        }
                        Some(intune_device_id)
                    }
                    Err(IdpError::NotFound { .. }) => None,
                    Err(e) => {
                        error!(
                            ?e,
                            "Failed to enroll in Intune during domain join, will retry later."
                        );
                        None
                    }
                };

                let mut config = self.config.lock().await;
                if let Some(intune_device_id) = intune_device_id {
                    config.set(&self.domain, "intune_device_id", &intune_device_id);
                }
                config.set(&self.domain, "device_id", &device_id);
                debug!(
                    "Setting domain {} config device_id to {}",
                    self.domain, &device_id
                );
                if let Err(e) = config.write_server_config() {
                    return Err(MsalError::GeneralFailure(format!(
                        "Failed to write domain join configuration: {:?}",
                        e
                    )));
                }
                Ok(())
            }
            Err(e) => Err(e),
        }
    }

    #[instrument(level = "debug", skip_all)]
    async fn intune_enroll(
        &self,
        device_id: Option<&str>,
        attrs: Option<&EnrollAttrs>,
        tpm: &mut tpm::provider::BoxedDynTpm,
        token: &UnixUserToken,
        machine_key: &tpm::structures::StorageKey,
    ) -> Result<(LoadableMsDeviceEnrolmentKey, String), IdpError> {
        // Enrolling the device in Intune
        let apply_policy = self.config.lock().await.get_apply_policy();
        if apply_policy {
            let graph_token = match self
                .client
                .lock()
                .await
                .acquire_token_by_refresh_token(
                    &token.refresh_token,
                    vec!["00000003-0000-0000-c000-000000000000/.default"],
                    None,
                    Some(DEFAULT_APP_ID),
                    tpm,
                    machine_key,
                )
                .await
            {
                Ok(token) => token,
                Err(MsalError::AcquireTokenFailed(e)) => {
                    if e.error_codes.contains(&DEVICE_AUTH_FAIL) {
                        error!(
                            ?e,
                            "Device auth failed for Intune device enrollment, delaying enrollment."
                        );
                        // TODO: Is NotFound the correct error type here? BadRequest better here?
                        return Err(IdpError::NotFound {
                            what: "refresh_token".to_string(),
                            where_: "intune_enroll".to_string(),
                        });
                    } else {
                        error!(?e, "Acquiring token for Intune device enrollment failed.");
                        return Err(IdpError::BadRequest);
                    }
                }
                Err(e) => {
                    error!(?e, "Acquiring token for Intune device enrollment failed.");
                    return Err(IdpError::BadRequest);
                }
            };
            let access_token = graph_token.access_token.clone().ok_or_else(|| {
                error!("Acquiring token for Intune device enrollment failed: access_token missing");
                IdpError::BadRequest
            })?;
            let endpoints = self
                .graph
                .intune_service_endpoints(&access_token)
                .await
                .map_err(|e| {
                    error!("Failed fetching Intune service endpoints: {:?}", e);
                    IdpError::BadRequest
                })?;
            match self
                .client
                .lock()
                .await
                .acquire_token_by_refresh_token(
                    &token.refresh_token,
                    vec!["d4ebce55-015a-49b5-a083-c84d1797ae8c/.default"],
                    None,
                    Some(DEFAULT_APP_ID),
                    tpm,
                    machine_key,
                )
                .await
            {
                Ok(token) => {
                    let mut vers = fetch_intune_portal_versions(Some(
                        "https://packages.microsoft.com/ubuntu/22.04/prod/pool/main/i/intune-portal/"
                    )).await.unwrap_or(vec!["1.2511.11".to_string()]);
                    if vers.is_empty() {
                        vers = vec!["1.2511.11".to_string()];
                    }
                    let (ip_versions, request_timeout) = {
                        let cfg = self.config.lock().await;
                        (cfg.get_ip_versions(), cfg.get_request_timeout())
                    };
                    let intune = IntuneForLinux::new(
                        endpoints,
                        Some(&vers[vers.len() - 1]),
                        std::time::Duration::from_secs(request_timeout),
                        &ip_versions,
                    )
                    .map_err(|e| {
                        error!(?e, "Intune device enrollment failed.");
                        IdpError::BadRequest
                    })?;
                    let device_id = match device_id {
                        Some(v) => v.to_string(),
                        None => self
                            .config
                            .lock()
                            .await
                            .get(&self.domain, "device_id")
                            .ok_or({
                                error!("Device ID missing for Intune device enrollment.");
                                IdpError::BadRequest
                            })?,
                    };
                    let attrs = attrs.cloned().unwrap_or(
                        EnrollAttrs::new(self.domain.clone(), None, None, None, None).map_err(
                            |e| {
                                error!("Failed creating enroll attrs: {:?}", e);
                                IdpError::BadRequest
                            },
                        )?,
                    );
                    match intune
                        .enroll(&token, &attrs, &device_id, tpm, machine_key)
                        .await
                    {
                        Ok((intune_key, intune_device_id)) => Ok((intune_key, intune_device_id)),
                        Err(e) => {
                            error!(?e, "Intune device enrollment failed.");
                            Err(IdpError::BadRequest)
                        }
                    }
                }
                Err(e) => {
                    error!(?e, "Intune device enrollment failed.");
                    Err(IdpError::BadRequest)
                }
            }
        } else {
            Err(IdpError::NotFound {
                what: "apply_policy".to_string(),
                where_: "intune_enroll".to_string(),
            })
        }
    }

    #[instrument(level = "debug", skip_all)]
    async fn is_domain_joined<D: KeyStoreTxn + Send>(&self, keystore: &mut D) -> bool {
        if self.is_consumer_tenant().await {
            // Pretend we are always joined for MSA accounts
            return true;
        }
        /* If we have access to tpm keys, and the domain device_id is
         * configured, we'll assume we are domain joined. */
        if self
            .config
            .lock()
            .await
            .get(&self.domain, "device_id")
            .is_none()
        {
            return false;
        }
        let transport_key = match self.fetch_loadable_transport_key_from_keystore(keystore) {
            Ok(transport_key) => transport_key,
            Err(_) => return false,
        };
        if transport_key.is_none() {
            return false;
        }
        let cert_key = match self.fetch_loadable_cert_key_from_keystore(keystore) {
            Ok(cert_key) => cert_key,
            Err(_) => return false,
        };
        if cert_key.is_none() {
            return false;
        }
        true
    }

    #[instrument(level = "debug", skip_all)]
    async fn is_consumer_tenant(&self) -> bool {
        let tenant_id = self
            .config
            .lock()
            .await
            .get(&self.domain, "tenant_id")
            .unwrap_or("".to_string());
        tenant_id == "9188040d-6c67-4c5b-b112-36a304b66dad"
            || tenant_id == "9cd80435-793b-4f48-844b-6b3f37d1c1f3"
    }

    #[instrument(level = "debug", skip_all)]
    async fn is_intune_enrolled<D: KeyStoreTxn + Send>(&self, keystore: &mut D) -> bool {
        if self.is_consumer_tenant().await {
            // Pretend we are always enrolled for MSA accounts
            return true;
        }
        if self
            .config
            .lock()
            .await
            .get(&self.domain, "intune_device_id")
            .is_none()
        {
            return false;
        }
        let intune_tag = self.fetch_intune_key_tag();
        let intune_key: Option<LoadableMsDeviceEnrolmentKey> =
            match keystore.get_tagged_hsm_key(&intune_tag) {
                Ok(intune_key) => intune_key,
                Err(_) => return false,
            };
        if intune_key.is_none() {
            return false;
        }
        true
    }
}

#[cfg(test)]
mod tests {
    use super::{
        is_mfa_required_for_enrollment, is_sspr_required, is_unavailable_mfa_method_error,
        local_user_ids_from_passwd, mfa_flow_uses_push_hint, password_change_required,
        CONSENT_REQUIRED, PASSWORD_RESET_REGISTRATION_REQUIRED,
    };
    use crate::idprovider::interface::{AuthCacheAction, AuthCredHandler, AuthRequest, AuthResult};
    use himmelblau::error::{AADSTSError, ErrorResponse, MsalError, DEVICE_AUTH_FAIL};
    use himmelblau::{MFAAuthContinue, MfaMethodInfo};

    #[test]
    fn local_user_lookup_uses_passwd_file_only() {
        let passwd = b"root:x:0:0:root:/root:/bin/bash\nlocal:x:1000:1001::/home/local:/bin/bash\n";

        assert_eq!(
            local_user_ids_from_passwd(passwd, "local"),
            Some((1000, 1001))
        );
        assert_eq!(local_user_ids_from_passwd(passwd, "directory-user"), None);
    }

    #[test]
    fn local_user_lookup_skips_compat_and_invalid_records() {
        let passwd = b"+::::::\n+directory-user::::::\nshort:record\ninvalid:x:bad:1001::/:/bin/bash\nlocal:x:1000:1001::/home/local:/bin/bash\n-::::::\n";

        assert_eq!(
            local_user_ids_from_passwd(passwd, "local"),
            Some((1000, 1001))
        );
        assert_eq!(local_user_ids_from_passwd(passwd, "directory-user"), None);
        assert_eq!(local_user_ids_from_passwd(passwd, "invalid"), None);
        assert_eq!(local_user_ids_from_passwd(passwd, "loc"), None);
    }

    #[test]
    fn local_user_lookup_keeps_valid_records_before_compat_entries() {
        let passwd = b"local:x:1000:1001::/home/local:/bin/bash\n+::::::\n+local:x:2000:2001::/:/bin/bash\n-local:x:3000:3001::/:/bin/bash\n";

        assert_eq!(
            local_user_ids_from_passwd(passwd, "local"),
            Some((1000, 1001))
        );
        assert_eq!(local_user_ids_from_passwd(passwd, "+local"), None);
        assert_eq!(local_user_ids_from_passwd(passwd, "-local"), None);
    }

    fn should_use_sspr_hello_fallback(e: &MsalError, is_remote_service: bool) -> bool {
        is_sspr_required(e) && !is_remote_service
    }

    #[test]
    fn sspr_hello_fallback_is_local_only() {
        let error = MsalError::AcquireTokenFailed(ErrorResponse {
            error: "invalid_grant".to_string(),
            error_description: "SSPR registration required".to_string(),
            suberror: None,
            error_codes: vec![PASSWORD_RESET_REGISTRATION_REQUIRED],
        });

        assert!(should_use_sspr_hello_fallback(&error, false));
        assert!(!should_use_sspr_hello_fallback(&error, true));
        assert!(!should_use_sspr_hello_fallback(
            &MsalError::RequestFailed("network down".to_string()),
            false
        ));
    }

    #[test]
    fn unavailable_mfa_method_error_requires_exact_requested_method() {
        assert!(is_unavailable_mfa_method_error(
            "Requested MFA method 'FidoKey' not available. Available methods: PhoneAppOTP",
            "FidoKey"
        ));

        assert!(!is_unavailable_mfa_method_error(
            "Requested MFA method 'PhoneAppOTP' not available. Available methods: FidoKey",
            "FidoKey"
        ));
        assert!(!is_unavailable_mfa_method_error(
            "Stored MFA method 'FidoKey' is not available. Available methods: PhoneAppOTP",
            "FidoKey"
        ));
    }

    fn mfa_flow_with_method(method_id: &str) -> MFAAuthContinue {
        MFAAuthContinue {
            mfa_methods: vec![method_id.to_string()],
            mfa_method_details: vec![MfaMethodInfo {
                auth_method_id: method_id.to_string(),
                display: method_id.to_string(),
                is_default: true,
            }],
            ..Default::default()
        }
    }

    #[test]
    fn mfa_flow_uses_push_hint_only_for_push_methods() {
        assert!(mfa_flow_uses_push_hint(&mfa_flow_with_method(
            "PhoneAppNotification"
        )));
        assert!(mfa_flow_uses_push_hint(&mfa_flow_with_method(
            "CompanionAppsNotification"
        )));
        assert!(!mfa_flow_uses_push_hint(&mfa_flow_with_method(
            "PhoneAppOTP"
        )));
        assert!(!mfa_flow_uses_push_hint(&mfa_flow_with_method("OneWaySMS")));
        assert!(!mfa_flow_uses_push_hint(&MFAAuthContinue::default()));
    }

    #[test]
    fn enrollment_mfa_classifier_matches_strong_auth_demands() {
        for code in [50072, 50074, 50076] {
            assert!(is_mfa_required_for_enrollment(
                &MsalError::AcquireTokenFailed(ErrorResponse {
                    error: "invalid_grant".to_string(),
                    error_description: format!("AADSTS{code}: MFA required"),
                    suberror: None,
                    error_codes: vec![code],
                })
            ));
            assert!(is_mfa_required_for_enrollment(&MsalError::AADSTSError(
                AADSTSError::new(code, None)
            )));
        }

        assert!(is_mfa_required_for_enrollment(&MsalError::MFARequired));
    }

    #[test]
    fn enrollment_mfa_classifier_ignores_unrelated_errors() {
        assert!(!is_mfa_required_for_enrollment(
            &MsalError::AcquireTokenFailed(ErrorResponse {
                error: "invalid_grant".to_string(),
                error_description: "device auth failed".to_string(),
                suberror: None,
                error_codes: vec![DEVICE_AUTH_FAIL],
            })
        ));
        assert!(!is_mfa_required_for_enrollment(
            &MsalError::AcquireTokenFailed(ErrorResponse {
                error: "invalid_grant".to_string(),
                error_description: "consent required".to_string(),
                suberror: None,
                error_codes: vec![CONSENT_REQUIRED],
            })
        ));
        assert!(!is_mfa_required_for_enrollment(&MsalError::RequestFailed(
            "network down".to_string()
        )));
    }

    #[test]
    fn password_change_required_sets_change_password_handler() {
        let mut cred_handler = AuthCredHandler::None;

        let (result, action) = password_change_required(&mut cred_handler, "old-password".into());

        match cred_handler {
            AuthCredHandler::ChangePassword { old_cred } => {
                assert_eq!(old_cred, "old-password");
            }
            other => panic!("unexpected credential handler: {other:?}"),
        }

        match result {
            AuthResult::Next(AuthRequest::ChangePassword { msg }) => {
                assert!(msg.contains("Update your password"));
                assert!(msg.contains("password has expired"));
            }
            _ => panic!("expected password change request"),
        }

        match action {
            AuthCacheAction::None => {}
            AuthCacheAction::PasswordHashUpdate { .. } => {
                panic!("password change prompt must not update auth cache")
            }
        }
    }
}
