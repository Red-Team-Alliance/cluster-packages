/*
 * Unix Azure Entra ID implementation
 * Copyright (C) William Brown <william@blackhats.net.au> and the Kanidm team 2018-2024
 * Copyright (C) David Mulder <dmulder@samba.org> 2024
 *
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/.
 */

use crate::db::KeyStoreTxn;
use crate::unix_proto::{PamAuthRequest, PamAuthResponse};
use async_trait::async_trait;
use himmelblau::{AuthOption, MFAAuthContinue, UserToken as UnixUserToken};
use kanidm_hsm_crypto::structures::SealedData;
use libkrimes::proto::KerberosCredentials;
use serde::{Deserialize, Serialize};
use std::fmt;
use std::time::SystemTime;
use tokio::sync::broadcast;
use uuid::Uuid;
use zeroize::Zeroizing;

pub use kanidm_hsm_crypto as tpm;

/// Errors that the IdProvider may return. These drive the resolver state machine
/// and should be carefully selected to match your expected errors.
#[derive(Debug)]
pub enum IdpError {
    /// An error occurred in the underlying communication to the Idp. A timeout or
    /// or other communication issue exists. The resolver will take this provider
    /// offline.
    Transport,
    /// The provider is online but the provider module is not current authorised with
    /// the idp. After returning this error the operation will be retried after a
    /// successful authentication.
    ProviderUnauthorised,
    /// The provider made an invalid or illogical request to the idp, and a result
    /// is not able to be provided to the resolver.
    BadRequest,
    /// The idp has indicated that the requested resource does not exist and should
    /// be considered deleted, removed, or not present.
    NotFound { what: String, where_: String },
    /// The idp was unable to perform an operation on the underlying hsm keystorage
    KeyStore,
    /// The idp failed to interact with the configured TPM
    Tpm,
}

#[derive(Debug, Clone)]
pub enum CacheState {
    Online,
    Offline,
    OfflineNextCheck(SystemTime),
}

pub enum UserTokenState {
    /// Indicate to the resolver that the cached UserToken should be used, if present.
    UseCached,
    /// The requested entity is not found, or has been removed.
    NotFound,

    /// Update the cache state with the data found in this UserToken.
    Update(UserToken),
    /// Return an identity for lookup without persisting it as authenticated.
    LookupOnly(UserToken),
}

#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub enum Id {
    Name(String),
    Gid(u32),
}

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct GroupToken {
    pub name: String,
    pub spn: String,
    pub uuid: Uuid,
    pub gidnumber: u32,
}

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct UserToken {
    pub name: String,
    pub spn: String,
    pub uuid: Uuid,
    #[serde(default)]
    pub real_gidnumber: Option<u32>, // This is the actual gidnumber.
    pub gidnumber: u32, // This is actually the uid, and is a legacy carryover from Kanidm
    pub displayname: String,
    pub shell: Option<String>,
    pub groups: Vec<GroupToken>,
    #[serde(default)]
    pub tenant_id: Option<Uuid>,
    // Defaults to false.
    pub valid: bool,
}

pub enum AuthCredHandler {
    MFA {
        flow: Box<MFAAuthContinue>,
        password: Option<String>,
        extra_data: Option<String>,
        /// When set, this MFA flow was triggered by an expired PRT/refresh token
        /// while the Hello key and PIN are still valid. Contains the validated
        /// PIN to reuse for re-sealing the new PRT with the existing Hello key
        /// after successful re-authentication. (See issue #1051)
        reauth_hello_pin: Option<Zeroizing<String>>,
    },
    /// Password prompt for Hello re-authentication when Azure requires a
    /// password before continuing MFA. Carries the validated Hello PIN so we
    /// can re-seal tokens with the existing Hello key after MFA succeeds.
    ReauthPassword {
        reauth_hello_pin: Zeroizing<String>,
    },
    SetupPin {
        token: Box<Option<UnixUserToken>>,
    },
    HelloTOTP {
        cred: String,
        /// Sealed TOTP secret pending validation - only set during initial setup.
        /// Will be saved to HSM after successful TOTP validation.
        pending_sealed_totp: Option<SealedData>,
    },
    ChangePassword {
        old_cred: String,
    },
    /// Password-first authentication for console_password_only mode. Providers
    /// first try to validate the password, then either complete auth or continue
    /// into their provider-specific MFA/device flow.
    PasswordFirst {
        /// Entra auth options to pass if we need to initiate an MFA flow.
        /// Generic OIDC providers ignore this field.
        auth_options: Vec<AuthOption>,
        /// Whether the device is domain joined for Entra ROPC/MFA behavior.
        /// Generic OIDC providers ignore this field.
        is_domain_joined: bool,
    },
    None,
}

impl fmt::Debug for AuthCredHandler {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            AuthCredHandler::MFA { .. } => f.write_str("MFA { .. }"),
            AuthCredHandler::ReauthPassword { .. } => f.write_str("ReauthPassword { .. }"),
            AuthCredHandler::SetupPin { .. } => f.write_str("SetupPin { .. }"),
            AuthCredHandler::HelloTOTP { .. } => f.write_str("HelloTOTP { .. }"),
            AuthCredHandler::ChangePassword { .. } => f.write_str("ChangePassword { .. }"),
            AuthCredHandler::PasswordFirst { .. } => f.write_str("PasswordFirst { .. }"),
            AuthCredHandler::None => f.write_str("None"),
        }
    }
}

pub enum AuthRequest {
    Password {
        prompt: Option<String>,
        long_prompt: Option<String>,
    },
    Input {
        msg: String,
        echo_on: bool,
    },
    HelloTOTP {
        msg: String,
    },
    MFAPoll {
        /// Message to display to the user.
        msg: String,
        /// Interval in seconds between poll attempts.
        polling_interval: u32,
        /// Whether PAM should append push-notification troubleshooting text.
        show_push_hint: bool,
    },
    MFAPollWait,
    SetupPin {
        /// Message to display to the user.
        msg: String,
    },
    Pin,
    Fido {
        fido_challenge: String,
        fido_allow_list: Vec<String>,
        has_physical_security_key: bool,
        has_cross_device: bool,
    },
    ChangePassword {
        /// Message to display to the user.
        msg: String,
    },
    InitDenied {
        /// Message to display to the user.
        msg: String,
    },
}

#[allow(clippy::from_over_into)]
impl Into<PamAuthResponse> for AuthRequest {
    fn into(self) -> PamAuthResponse {
        match self {
            AuthRequest::Password {
                prompt,
                long_prompt,
            } => PamAuthResponse::Password {
                prompt,
                long_prompt,
            },
            AuthRequest::Input { msg, echo_on } => PamAuthResponse::Input { msg, echo_on },
            AuthRequest::HelloTOTP { msg } => PamAuthResponse::HelloTOTP { msg },
            AuthRequest::MFAPoll {
                msg,
                polling_interval,
                show_push_hint,
            } => PamAuthResponse::MFAPoll {
                msg,
                polling_interval,
                show_push_hint,
            },
            AuthRequest::MFAPollWait => PamAuthResponse::MFAPollWait,
            AuthRequest::SetupPin { msg } => PamAuthResponse::SetupPin { msg },
            AuthRequest::Pin => PamAuthResponse::Pin,
            AuthRequest::Fido {
                fido_challenge,
                fido_allow_list,
                has_physical_security_key,
                has_cross_device,
            } => PamAuthResponse::Fido {
                fido_challenge,
                fido_allow_list,
                has_physical_security_key,
                has_cross_device,
            },
            AuthRequest::ChangePassword { msg } => PamAuthResponse::ChangePassword { msg },
            AuthRequest::InitDenied { msg } => PamAuthResponse::InitDenied { msg },
        }
    }
}

pub enum AuthResult {
    Success { token: UserToken },
    Denied(String),
    Next(AuthRequest),
}

pub enum AuthCacheAction {
    None,
    PasswordHashUpdate { cred: String },
}

#[async_trait]
pub trait IdProvider {
    async fn configure_hsm_keys<D: KeyStoreTxn + Send>(
        &self,
        _keystore: &mut D,
        _tpm: &mut tpm::provider::BoxedDynTpm,
        _machine_key: &tpm::structures::StorageKey,
    ) -> Result<(), IdpError> {
        Ok(())
    }

    async fn check_online(&self, _tpm: &mut tpm::provider::BoxedDynTpm, _now: SystemTime) -> bool;

    async fn unix_user_get<D: KeyStoreTxn + Send>(
        &self,
        _id: &Id,
        _token: Option<&UserToken>,
        _keystore: &mut D,
        _tpm: &mut tpm::provider::BoxedDynTpm,
        _machine_key: &tpm::structures::StorageKey,
    ) -> Result<UserTokenState, IdpError>;

    #[allow(clippy::too_many_arguments)]
    async fn unix_user_access<D: KeyStoreTxn + Send>(
        &self,
        _id: &Id,
        _scopes: Vec<String>,
        _token: Option<&UserToken>,
        _client_id: Option<String>,
        _redirect_uri: Option<String>,
        _req_cnf: Option<String>,
        _keystore: &mut D,
        _tpm: &mut tpm::provider::BoxedDynTpm,
        _machine_key: &tpm::structures::StorageKey,
    ) -> Result<UnixUserToken, IdpError>;

    async fn unix_user_tgts<D: KeyStoreTxn + Send>(
        &self,
        _id: &Id,
        _old_token: Option<&UserToken>,
        _keystore: &mut D,
        _tpm: &mut tpm::provider::BoxedDynTpm,
        _machine_key: &tpm::structures::StorageKey,
    ) -> (
        Option<Box<KerberosCredentials>>,
        Option<Box<KerberosCredentials>>,
        Option<String>,
        Option<String>,
    );

    async fn unix_user_prt_cookie<D: KeyStoreTxn + Send>(
        &self,
        _id: &Id,
        _token: Option<&UserToken>,
        _sso_nonce: Option<&str>,
        _keystore: &mut D,
        _tpm: &mut tpm::provider::BoxedDynTpm,
        _machine_key: &tpm::structures::StorageKey,
    ) -> Result<String, IdpError>;

    async fn change_auth_token<D: KeyStoreTxn + Send>(
        &self,
        _account_id: &str,
        _token: &UnixUserToken,
        _new_tok: &str,
        _keystore: &mut D,
        _tpm: &mut tpm::provider::BoxedDynTpm,
        _machine_key: &tpm::structures::StorageKey,
    ) -> Result<bool, IdpError>;

    #[allow(clippy::too_many_arguments)]
    async fn unix_user_online_auth_init<D: KeyStoreTxn + Send>(
        &self,
        _account_id: &str,
        _token: Option<&UserToken>,
        _service: &str,
        _no_hello_pin: bool,
        _force_reauth: bool,
        _keystore: &mut D,
        _tpm: &mut tpm::provider::BoxedDynTpm,
        _machine_key: &tpm::structures::StorageKey,
        _shutdown_rx: &broadcast::Receiver<()>,
    ) -> Result<(AuthRequest, AuthCredHandler), IdpError>;

    #[allow(clippy::too_many_arguments)]
    async fn unix_user_online_auth_step<D: KeyStoreTxn + Send>(
        &self,
        _account_id: &str,
        _old_token: &UserToken,
        _service: &str,
        _no_hello_pin: bool,
        _cred_handler: &mut AuthCredHandler,
        _pam_next_req: PamAuthRequest,
        _keystore: &mut D,
        _tpm: &mut tpm::provider::BoxedDynTpm,
        _machine_key: &tpm::structures::StorageKey,
        _shutdown_rx: &broadcast::Receiver<()>,
    ) -> Result<(AuthResult, AuthCacheAction), IdpError>;

    async fn unix_user_offline_auth_init<D: KeyStoreTxn + Send>(
        &self,
        _account_id: &str,
        _token: Option<&UserToken>,
        _service: &str,
        _no_hello_pin: bool,
        _keystore: &mut D,
    ) -> Result<(AuthRequest, AuthCredHandler), IdpError>;

    // I thought about this part of the interface a lot. we could have the
    // provider actually need to check the password or credentials, but then
    // we need to rework the tpm/crypto engine to be an argument to pass here
    // as well the cached credentials.
    //
    // As well, since this is "offline auth" the provider isn't really "doing"
    // anything special here - when you say you want offline password auth, the
    // resolver can just do it for you for all the possible implementations.
    // This is similar for offline ctap2 as well, or even offline totp.
    //
    // I think in the future we could reconsider this and let the provider be
    // involved if there is some "custom logic" or similar that is needed but
    // for now I think making it generic is a good first step and we can change
    // it later.
    //
    // EDIT 04042024: When we're performing an offline PIN auth, the PIN can
    // unlock the associated TPM key. While we can't perform a full request
    // for an auth token, we can verify that the PIN successfully unlocks the
    // TPM key.
    async fn unix_user_offline_auth_step<D: KeyStoreTxn + Send>(
        &self,
        _account_id: &str,
        _token: &UserToken,
        _cred_handler: &mut AuthCredHandler,
        _pam_next_req: PamAuthRequest,
        _keystore: &mut D,
        _tpm: &mut tpm::provider::BoxedDynTpm,
        _machine_key: &tpm::structures::StorageKey,
        _online_at_init: bool,
    ) -> Result<AuthResult, IdpError>;

    /// Validate a Hello PIN and restore its cached PRT/refresh token without
    /// entering the interactive online or offline authentication state machine.
    async fn unix_user_try_unseal<D: KeyStoreTxn + Send>(
        &self,
        _account_id: &str,
        _cred: &str,
        _keystore: &mut D,
        _tpm: &mut tpm::provider::BoxedDynTpm,
        _machine_key: &tpm::structures::StorageKey,
        _online: bool,
    ) -> Result<bool, IdpError>;

    async fn unix_group_get(
        &self,
        id: &Id,
        _tpm: &mut tpm::provider::BoxedDynTpm,
    ) -> Result<GroupToken, IdpError>;

    async fn get_cachestate<D: KeyStoreTxn + Send>(
        &self,
        _account_id: Option<&str>,
        _keystore: &mut D,
    ) -> CacheState;

    async fn offline_break_glass(&self, _ttl: Option<u64>) -> Result<(), IdpError>;

    /// Export broker PRTs as a serialised blob (for fdstore persistence).
    /// Providers that don't hold broker PRTs return an empty JSON object.
    async fn export_broker_prts(&self) -> Result<Vec<u8>, serde_json::Error> {
        Ok(b"{}".to_vec())
    }

    /// Import broker PRTs previously exported by [`Self::export_broker_prts`].
    async fn import_broker_prts(&self, _data: &[u8]) -> Result<(), serde_json::Error> {
        Ok(())
    }
}
