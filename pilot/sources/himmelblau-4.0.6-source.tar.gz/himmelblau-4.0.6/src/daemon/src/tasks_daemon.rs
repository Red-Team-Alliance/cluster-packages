/*
 * Unix Azure Entra ID implementation
 * Copyright (C) William Brown <william@blackhats.net.au> and the Kanidm team 2018-2024
 * Copyright (C) David Mulder <dmulder@samba.org> 2024
 *
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/.
 */
#![deny(warnings)]
#![warn(unused_extern_crates)]
#![deny(clippy::todo)]
#![deny(clippy::unimplemented)]
#![deny(clippy::unwrap_used)]
#![deny(clippy::expect_used)]
#![deny(clippy::panic)]
#![deny(clippy::unreachable)]
#![deny(clippy::await_holding_lock)]
#![deny(clippy::needless_pass_by_value)]
#![deny(clippy::trivially_copy_pass_by_ref)]
#![allow(unexpected_cfgs)]

use std::ffi::CString;
use std::os::unix::ffi::OsStrExt;
use std::os::unix::fs::{symlink, OpenOptionsExt, PermissionsExt};
use std::path::Path;
use std::process::ExitCode;
use std::str;
use std::time::Duration;
use std::{fs, io};

use bytes::{BufMut, BytesMut};
use futures::{SinkExt, StreamExt};
use himmelblau::graph::Graph;
use himmelblau_policies::policies::apply_intune_policy;
use himmelblau_unix_common::config::{split_username, HimmelblauConfig};
use himmelblau_unix_common::constants::{DEFAULT_CONFIG_PATH, DEFAULT_KERBEROS_CONF_DIR};
use himmelblau_unix_common::unix_proto::{HomeDirectoryInfo, TaskRequest, TaskResponse};
use himmelblau_unix_common::user_map::UserMap;
use kanidm_utils_users::{get_effective_gid, get_effective_uid};
use libc::uid_t;
use libc::{lchown, umask};
use libkrimes::proto::KerberosCredentials;
use sd_notify::NotifyState;
use sketching::tracing_forest::traits::*;
use sketching::tracing_forest::util::*;
use sketching::tracing_forest::{self};
use std::fs::OpenOptions;
use std::io::Write;
use std::process::Command;
use tempfile::NamedTempFile;
use tokio::net::UnixStream;
use tokio::sync::broadcast;
use tokio::time;
use tokio_util::codec::{Decoder, Encoder, Framed};
use tracing::span;
use walkdir::WalkDir;
use zbus::zvariant::OwnedObjectPath;
use zbus::{proxy, Connection};

#[cfg(all(target_family = "unix", feature = "selinux"))]
use himmelblau_unix_common::selinux_util;

struct TaskCodec;

#[proxy(
    interface = "org.freedesktop.Accounts",
    default_service = "org.freedesktop.Accounts",
    default_path = "/org/freedesktop/Accounts"
)]
trait AccountsService {
    fn find_user_by_name(&self, name: &str) -> zbus::Result<OwnedObjectPath>;
    fn cache_user(&self, name: &str) -> zbus::Result<OwnedObjectPath>;
}

#[proxy(
    interface = "org.freedesktop.Accounts.User",
    default_service = "org.freedesktop.Accounts"
)]
trait AccountsServiceUser {
    fn set_icon_file(&self, filename: &str) -> zbus::Result<()>;
}

impl Decoder for TaskCodec {
    type Error = io::Error;
    type Item = TaskRequest;

    fn decode(&mut self, src: &mut BytesMut) -> Result<Option<Self::Item>, Self::Error> {
        match serde_json::from_slice::<TaskRequest>(src) {
            Ok(msg) => {
                // Clear the buffer for the next message.
                src.clear();
                Ok(Some(msg))
            }
            _ => Ok(None),
        }
    }
}

impl Encoder<TaskResponse> for TaskCodec {
    type Error = io::Error;

    fn encode(&mut self, msg: TaskResponse, dst: &mut BytesMut) -> Result<(), Self::Error> {
        debug!("Attempting to send request -> {:?} ...", msg);
        let data = serde_json::to_vec(&msg).map_err(|e| {
            error!("socket encoding error -> {:?}", e);
            io::Error::other("JSON encode error")
        })?;
        dst.put(data.as_slice());
        Ok(())
    }
}

impl TaskCodec {
    fn new() -> Self {
        TaskCodec
    }
}

fn chown(path: &Path, uid: u32, gid: u32) -> Result<(), String> {
    let path_os = CString::new(path.as_os_str().as_bytes())
        .map_err(|_| "Unable to create c-string".to_string())?;

    // Change the owner to the gid - remember, himmelblau ONLY has gid's, the uid is implied.
    if unsafe { lchown(path_os.as_ptr(), uid, gid) } != 0 {
        return Err("Unable to set ownership".to_string());
    }
    Ok(())
}

fn create_home_directory(
    info: &HomeDirectoryInfo,
    home_prefix: &str,
    use_etc_skel: bool,
    use_selinux: bool,
) -> Result<(), String> {
    // Final sanity check to prevent certain classes of attacks.
    let name = info.name.trim_start_matches('.').replace(['/', '\\'], "");

    let home_prefix_path = Path::new(home_prefix);

    // Does our home_prefix actually exist?
    if !home_prefix_path.exists() || !home_prefix_path.is_dir() {
        return Err("Invalid home_prefix from configuration".to_string());
    }

    // Actually process the request here.
    let hd_path_raw = format!("{}{}", home_prefix, name);
    let hd_path = Path::new(&hd_path_raw);

    // Assert the resulting named home path is consistent and correct.
    if let Some(pp) = hd_path.parent() {
        if pp != home_prefix_path {
            return Err("Invalid home directory name - not within home_prefix".to_string());
        }
    } else {
        return Err("Invalid/Corrupt home directory path - no prefix found".to_string());
    }

    // Get a handle to the SELinux labeling interface
    debug!(?use_selinux, "selinux for home dir labeling");
    #[cfg(all(target_family = "unix", feature = "selinux"))]
    let labeler = if use_selinux {
        selinux_util::SelinuxLabeler::new(info.uid, home_prefix)?
    } else {
        selinux_util::SelinuxLabeler::new_noop()
    };

    // Does the home directory exist?
    if !hd_path.exists() {
        // Set the SELinux security context for file creation
        #[cfg(all(target_family = "unix", feature = "selinux"))]
        labeler.do_setfscreatecon_for_path()?;

        // Set a umask
        let before = unsafe { umask(0o0027) };

        // Create the dir
        if let Err(e) = fs::create_dir_all(hd_path) {
            let _ = unsafe { umask(before) };
            return Err(format!("{:?}", e));
        }
        let _ = unsafe { umask(before) };

        chown(hd_path, info.uid, info.gid)?;

        // Copy in structure from /etc/skel/ if present
        let skel_dir = Path::new("/etc/skel/");
        if use_etc_skel && skel_dir.exists() {
            info!("preparing homedir using /etc/skel");
            for entry in WalkDir::new(skel_dir).into_iter().filter_map(|e| e.ok()) {
                let dest = &hd_path.join(
                    entry
                        .path()
                        .strip_prefix(skel_dir)
                        .map_err(|e| e.to_string())?,
                );

                #[cfg(all(target_family = "unix", feature = "selinux"))]
                {
                    let p = entry
                        .path()
                        .strip_prefix(skel_dir)
                        .map_err(|e| e.to_string())?;
                    labeler.label_path(p)?;
                }

                if entry.path().is_dir() {
                    fs::create_dir_all(dest).map_err(|e| e.to_string())?;
                } else {
                    fs::copy(entry.path(), dest).map_err(|e| e.to_string())?;
                }
                chown(dest, info.uid, info.gid)?;

                // Create equivalence rule in the SELinux policy
                #[cfg(all(target_family = "unix", feature = "selinux"))]
                labeler.setup_equivalence_rule(&hd_path_raw)?;
            }
        }
    }

    // Reset object creation SELinux context to default
    #[cfg(all(target_family = "unix", feature = "selinux"))]
    labeler.set_default_context_for_fs_objects()?;

    let name_rel_path = Path::new(&name);
    // Does the aliases exist
    for alias in info.aliases.iter() {
        // Sanity check the alias.
        // let alias = alias.replace(".", "").replace("/", "").replace("\\", "");
        let alias = alias.trim_start_matches('.').replace(['/', '\\'], "");
        let alias_path_raw = format!("{}{}", home_prefix, alias);
        let alias_path = Path::new(&alias_path_raw);

        // Assert the resulting alias path is consistent and correct.
        if let Some(pp) = alias_path.parent() {
            if pp != home_prefix_path {
                return Err("Invalid home directory alias - not within home_prefix".to_string());
            }
        } else {
            return Err("Invalid/Corrupt alias directory path - no prefix found".to_string());
        }

        if alias_path.exists() {
            let attr = match fs::symlink_metadata(alias_path) {
                Ok(a) => a,
                Err(e) => {
                    return Err(format!("{:?}", e));
                }
            };

            if attr.file_type().is_symlink() {
                // Probably need to update it.
                if let Err(e) = fs::remove_file(alias_path) {
                    return Err(format!("{:?}", e));
                }
                if let Err(e) = symlink(name_rel_path, alias_path) {
                    return Err(format!("{:?}", e));
                }
            }
        } else {
            // Does not exist. Create.
            if let Err(e) = symlink(name_rel_path, alias_path) {
                return Err(format!("{:?}", e));
            }
        }
    }
    Ok(())
}

fn add_user_to_group(account_id: &str, local_group: &str) {
    match Command::new("gpasswd")
        .arg("-a")
        .arg(account_id)
        .arg(local_group)
        .output()
    {
        Ok(res) => {
            if !res.status.success() {
                error!("Failed adding user to local group {}", local_group);
            }
        }
        Err(e) => {
            error!("Failed adding user to local group {}: {:?}", local_group, e);
        }
    }
}

fn group_members_include(users: &str, account_id: &str) -> bool {
    users.split(',').any(|user| user.trim() == account_id)
}

fn user_in_group(account_id: &str, local_group: &str) -> bool {
    let output = Command::new("getent")
        .arg("group")
        .arg(local_group)
        .output();

    if let Ok(out) = output {
        if out.status.success() {
            let stdout = String::from_utf8_lossy(&out.stdout);
            if let Some(users) = stdout.split(':').nth(3) {
                return group_members_include(users, account_id);
            }
        }
    }
    false
}

fn remove_user_from_group(account_id: &str, local_group: &str) {
    if !user_in_group(account_id, local_group) {
        trace!(
            "User {} is not a member of {}, nothing to remove",
            account_id,
            local_group
        );
        return;
    }

    match Command::new("gpasswd")
        .arg("-d")
        .arg(account_id)
        .arg(local_group)
        .output()
    {
        Ok(res) => {
            if !res.status.success() {
                error!("Failed removing user from local group {}", local_group);
            }
        }
        Err(e) => {
            error!(
                "Failed removing user from local group {}: {:?}",
                local_group, e
            );
        }
    }
}

fn execute_user_script(account_id: &str, script: &str, access_token: &str) -> i32 {
    match Command::new("sh")
        .arg("-c")
        .arg(script)
        .env("USERNAME", account_id)
        .env("ACCESS_TOKEN", access_token)
        .output()
    {
        Ok(res) => {
            if !res.status.success() {
                let stdout = str::from_utf8(&res.stdout).unwrap_or("Invalid UTF-8 in stdout");
                let stderr = str::from_utf8(&res.stderr).unwrap_or("Invalid UTF-8 in stderr");
                error!(
                    "Failed to execute script '{}':\nstdout: {}\nstderr: {}",
                    script, stdout, stderr
                );
            }

            // If we don't get a status code, make assumptions
            if res.status.success() {
                res.status.code().unwrap_or(0)
            } else {
                res.status.code().unwrap_or(2)
            }
        }
        Err(e) => {
            error!("Failed to execute script '{}': {:?}", script, e);
            // If the script fails to execute at all, we assume this is a hard
            // failure and terminate the authentication attempt.
            2
        }
    }
}

/// Check if a user already has an entry in the given subid file
fn user_has_subid_entry(username: &str, subid_file: &Path) -> bool {
    if let Ok(contents) = fs::read_to_string(subid_file) {
        let prefix = format!("{}:", username);
        contents.lines().any(|line| line.starts_with(&prefix))
    } else {
        false
    }
}

/// Reject account names that could forge additional records in a subid file.
///
/// /etc/subuid and /etc/subgid are newline separated `name:start:count`
/// records. An account name containing the field separator (`:`) or a record
/// separator (any control character, which covers `\n`, `\r` and NUL) would
/// let a single delegation request write arbitrary *additional* delegations,
/// e.g. `padding:1:2\nattacker:0:65536\npad` grants host UID 0 to `attacker`.
/// See GHSA-x259-23ph-65m5.
fn validate_subid_username(username: &str) -> Result<(), String> {
    if username.is_empty() {
        return Err("Refusing subordinate ID entry for an empty account name".to_string());
    }

    if let Some(c) = username.chars().find(|c| *c == ':' || c.is_control()) {
        return Err(format!(
            "Refusing subordinate ID entry for account name {:?}: illegal character {:?}",
            username, c
        ));
    }

    Ok(())
}

/// Add a subordinate ID entry to /etc/subuid or /etc/subgid
/// Format: username:start:count
fn add_subid_entry(
    username: &str,
    start: u32,
    count: u32,
    subid_file: &Path,
) -> Result<(), String> {
    // Never interpolate an unvalidated name into a subid record.
    validate_subid_username(username)?;

    // Check if user already has an entry
    if user_has_subid_entry(username, subid_file) {
        debug!(
            "User {} already has an entry in {}, skipping",
            username,
            subid_file.display()
        );
        return Ok(());
    }

    // Append the new entry
    let entry = format!("{}:{}:{}\n", username, start, count);

    let mut file = OpenOptions::new()
        .create(true)
        .append(true)
        .open(subid_file)
        .map_err(|e| format!("Failed to open {}: {:?}", subid_file.display(), e))?;

    file.write_all(entry.as_bytes())
        .map_err(|e| format!("Failed to write to {}: {:?}", subid_file.display(), e))?;

    info!(
        "Added subordinate ID entry for {} in {}: start={}, count={}",
        username,
        subid_file.display(),
        start,
        count
    );

    Ok(())
}

/// Set up subordinate UID/GID mappings for a user
fn setup_subordinate_ids(username: &str, start: u32, count: u32) -> Result<(), String> {
    let subuid_path = Path::new("/etc/subuid");
    let subgid_path = Path::new("/etc/subgid");

    // Add entry to /etc/subuid
    add_subid_entry(username, start, count, subuid_path)?;

    // Add entry to /etc/subgid (same range)
    add_subid_entry(username, start, count, subgid_path)?;

    Ok(())
}

async fn set_accountsservice_icon(account_id: &str, icon_path: &Path) -> zbus::Result<()> {
    let connection = Connection::system().await?;
    let accounts = AccountsServiceProxy::new(&connection).await?;
    let user_path = match accounts.find_user_by_name(account_id).await {
        Ok(path) => path,
        Err(err) => {
            debug!(
                ?err,
                account_id, "AccountsService FindUserByName failed; falling back to CacheUser"
            );
            accounts.cache_user(account_id).await?
        }
    };
    let user = AccountsServiceUserProxy::builder(&connection)
        .path(user_path)?
        .build()
        .await?;

    user.set_icon_file(icon_path.to_string_lossy().as_ref())
        .await
}

fn create_profile_photo_temp_file(icons_dir: &Path) -> io::Result<NamedTempFile> {
    let file = NamedTempFile::new_in(icons_dir)?;
    file.as_file()
        .set_permissions(fs::Permissions::from_mode(0o600))?;
    Ok(file)
}

fn store_tgt(tgt: &KerberosCredentials, uid: uid_t, gid: uid_t) -> Result<(), String> {
    // Usually default_ccache_name in /etc/krb5.conf contains a %{uid} substitution,
    // which will be '0' (root) for the tasks daemon because it runs as root. Force
    // the ccache name.
    // TODO: Add a new himmelblau.conf option to define the ccache name
    let ccname = Some(format!("KEYRING:persistent:{}", uid));

    debug!(?ccname, "Storing kerberos ticket in credential cache");

    let guard = uzers::switch::switch_user_group(uid, gid)
        .map_err(|e| format!("Failed to switch user/group: {}", e))?;

    let mut ccache = match libkrimes::ccache::resolve(ccname.as_deref()) {
        Ok(ccache) => ccache,
        Err(e) => {
            drop(guard);
            let msg = format!("Failed to resolve credential cache {:?}: {:?}", ccname, e);
            return Err(msg);
        }
    };

    match ccache.init(tgt.name(), None) {
        Ok(_) => (),
        Err(e) => {
            drop(guard);
            let msg = format!("Failed to init credential cache {:?}: {:?}", ccname, e);
            return Err(msg);
        }
    }

    match ccache.store(tgt) {
        Ok(_) => (),
        Err(e) => {
            drop(guard);
            let msg = format!("Failed to store TGT in credential cache: {:?}", e);
            return Err(msg);
        }
    }

    drop(guard);

    Ok(())
}

fn write_kerberos_config_snippet(
    top_level_names: Option<String>,
    tenant_id: &str,
) -> Result<(), String> {
    write_kerberos_config_snippet_to(
        top_level_names,
        tenant_id,
        Path::new(DEFAULT_KERBEROS_CONF_DIR),
    )
}

fn write_kerberos_config_snippet_to(
    top_level_names: Option<String>,
    tenant_id: &str,
    krb_conf_dir: &Path,
) -> Result<(), String> {
    if tenant_id.is_empty() {
        return Err("Failed to write Kerberos config snippet, empty tenant_id".to_string());
    }

    // The tenant_id will be used in a file path. Validate it is really an UUID.
    uuid::Uuid::try_parse(tenant_id).map_err(|x| format!("Failed to validate tenant ID: {x}"))?;

    trace!(?krb_conf_dir, "Check kerberos config dir exists");
    match krb_conf_dir.try_exists() {
        Ok(true) if krb_conf_dir.is_dir() => Ok(()),
        Ok(true) => Err(format!("Path {krb_conf_dir:?} is not a directory")),
        Ok(false) => fs::create_dir_all(krb_conf_dir)
            .map_err(|e| format!("Failed to create {krb_conf_dir:?}: {e}")),
        Err(e) => Err(format!("Failed to check if {krb_conf_dir:?} exists: {e}")),
    }?;

    let krb_snippet = krb_conf_dir.join(format!("himmelblau_{tenant_id}.conf"));
    let mut file = match OpenOptions::new()
        .create(true)
        .truncate(true)
        .write(true)
        .mode(0o644)
        .open(&krb_snippet)
    {
        Ok(file) => file,
        Err(e) => return Err(format!("Failed to open {krb_snippet:?}: {e}")),
    };

    let libdefs = "[libdefaults]\n\tdns_canonicalize_hostname = false\n";
    file.write_all(libdefs.as_bytes())
        .map_err(|e| format!("Failed to write to {krb_snippet:?}: {e}"))?;

    let realms = format!(
        "[realms]\n\tKERBEROS.MICROSOFTONLINE.COM = {{\n\t\tkdc = https://login.microsoftonline.com/{tenant_id}/kerberos\n\t}}\n"
    );
    file.write_all(realms.as_bytes())
        .map_err(|e| format!("Failed to write to {krb_snippet:?}: {e}"))?;

    let domain_realms: Vec<String> = match top_level_names {
        Some(s) => s
            .split(",")
            .map(|e| e.trim())
            .filter(|e| !e.contains(":"))
            .map(|x| format!("\t{x} = KERBEROS.MICROSOFTONLINE.COM"))
            .collect(),
        None => vec![],
    };
    let domain_realms = format!("[domain_realm]\n{}\n", domain_realms.join("\n"));
    file.write_all(domain_realms.as_bytes())
        .map_err(|e| format!("Failed to write to {krb_snippet:?}: {e}"))?;

    Ok(())
}

async fn handle_tasks(stream: UnixStream, cfg: &HimmelblauConfig) {
    let mut reqs = Framed::new(stream, TaskCodec::new());

    loop {
        let next_req = reqs.next().await;
        let span = span!(Level::INFO, "TaskRequest");
        let _ = span.enter();
        match next_req {
            Some(Ok(TaskRequest::HomeDirectory(info))) => {
                debug!("Received task -> HomeDirectory(...)");
                let domain = split_username(&info.name).map(|(_, domain)| domain);

                let resp = match create_home_directory(
                    &info,
                    &cfg.get_home_prefix(domain),
                    cfg.get_use_etc_skel(),
                    cfg.get_selinux(),
                ) {
                    Ok(()) => TaskResponse::Success(0),
                    Err(msg) => TaskResponse::Error(msg),
                };

                // Now send a result.
                if let Err(e) = reqs.send(resp).await {
                    error!("Error -> {:?}", e);
                    return;
                }
                // All good, loop.
            }
            Some(Ok(TaskRequest::LocalGroups(mut account_id, is_sudoer))) => {
                debug!("Received task -> LocalGroups(...)",);
                account_id = cfg.map_upn_to_name(&account_id);

                let local_groups = cfg.get_local_groups();
                for local_group in &local_groups {
                    add_user_to_group(&account_id, local_group);
                }

                let local_sudo_group = cfg.get_local_sudo_group();

                // Only run sudo groups if local_groups does not contain local_sudo_group (default = sudo)
                if !local_groups.contains(&local_sudo_group) {
                    if is_sudoer {
                        add_user_to_group(&account_id, &local_sudo_group);
                    } else {
                        remove_user_from_group(&account_id, &local_sudo_group);
                    }
                }

                // Always indicate success here
                if let Err(e) = reqs.send(TaskResponse::Success(0)).await {
                    error!("Error -> {:?}", e);
                    return;
                }
            }
            Some(Ok(TaskRequest::LogonScript(account_id, access_token))) => {
                debug!("Received task -> LogonScript(...)");
                let mut status = 0;
                if let Some(script) = cfg.get_logon_script() {
                    status = execute_user_script(&account_id, &script, &access_token);
                }

                // Indicate the status response
                if let Err(e) = reqs.send(TaskResponse::Success(status)).await {
                    error!("Error -> {:?}", e);
                    return;
                }
            }
            Some(Ok(TaskRequest::KerberosConfig(top_level_names, tenant_id))) => {
                debug!("Received task -> KerberosConfig(...)");

                let response = match tenant_id {
                    Some(t) => match write_kerberos_config_snippet(top_level_names, &t) {
                        Ok(_) => TaskResponse::Success(0),
                        Err(msg) => TaskResponse::Error(msg),
                    },
                    None => TaskResponse::Error(
                        "Failed to write Kerberos config snippet, no tenant_id".to_string(),
                    ),
                };

                if let Err(e) = reqs.send(response).await {
                    error!("Error -> {:?}", e);
                    return;
                }
            }
            Some(Ok(TaskRequest::KerberosTGTs(uid, gid, tgt_cloud, tgt_ad))) => {
                debug!("Received task -> KerberosTGTs({}, {}, ...)", uid, gid);

                let cloud_ret = if let Some(tgt_cloud) = tgt_cloud {
                    store_tgt(tgt_cloud.as_ref(), uid, gid)
                } else {
                    Ok(())
                };

                let ad_ret = if let Some(tgt_ad) = tgt_ad {
                    store_tgt(tgt_ad.as_ref(), uid, gid)
                } else {
                    Ok(())
                };

                let response = match cloud_ret.and(ad_ret) {
                    Ok(_) => TaskResponse::Success(0),
                    Err(msg) => TaskResponse::Error(msg),
                };
                if let Err(e) = reqs.send(response).await {
                    error!("Error -> {:?}", e);
                    return;
                }
            }
            Some(Ok(TaskRequest::LoadProfilePhoto(account_id, access_token))) => {
                debug!("Received task -> LoadProfilePhoto(...)");
                let icons_dir = Path::new("/var/lib/AccountsService/icons/");

                let outcome: Result<(), String> = async {
                    if !icons_dir.exists() {
                        return Err(format!(
                            "Profile photo directory '{}' doesn't exist",
                            icons_dir.display()
                        ));
                    }

                    let upn = account_id.clone();
                    let domain = split_username(&upn)
                        .map(|(_, domain)| domain)
                        .ok_or_else(|| format!("Couldn't parse domain from UPN '{upn}'"))?;

                    // A user_map maps a local login to this UPN; resolve back to the local
                    // name so AccountsService keys the avatar to the account the user logs in as.
                    let user_map = UserMap::new(&cfg.get_user_map_file());
                    let account_id = match user_map.get_local_from_upn(&upn.to_lowercase()) {
                        Some(local) => local,
                        None => cfg.map_upn_to_name(&account_id),
                    };

                    // Reject invalid account identifiers before resolving them through
                    // AccountsService. Stripping characters could select a different user.
                    if account_id.is_empty()
                        || !account_id.chars().all(|c| {
                            c.is_ascii_alphanumeric() || matches!(c, '@' | '.' | '_' | '-')
                        })
                    {
                        return Err(format!(
                            "Invalid account_id '{account_id}' for profile photo - disallowed characters"
                        ));
                    }

                    let profile_photo = create_profile_photo_temp_file(icons_dir)
                        .map_err(|e| format!("Failed creating profile photo: {e:?}"))?;
                    let file = profile_photo
                        .reopen()
                        .map_err(|e| format!("Failed opening profile photo: {e:?}"))?;
                    let authority_host = cfg.get_authority_host(domain);
                    let tenant_id = cfg.get_tenant_id(domain);
                    let graph_url = cfg.get_graph_url(domain);
                    let ip_versions = cfg.get_ip_versions();
                    let request_timeout = cfg.get_request_timeout();
                    let graph = Graph::new(
                        &cfg.get_odc_provider(domain),
                        domain,
                        Some(&authority_host),
                        tenant_id.as_deref(),
                        graph_url.as_deref(),
                        Duration::from_secs(request_timeout),
                        &ip_versions,
                    )
                    .await
                    .map_err(|e| format!("Failed creating Graph client: {e:?}"))?;
                    graph
                        .fetch_user_profile_photo(&access_token, file)
                        .await
                        .map_err(|e| format!("Failed fetching profile photo: {e:?}"))?;
                    set_accountsservice_icon(&account_id, profile_photo.path())
                        .await
                        .map_err(|e| format!("Failed updating AccountsService profile photo: {e:?}"))?;
                    Ok(())
                }
                .await;

                let response = match outcome {
                    Ok(()) => TaskResponse::Success(0),
                    Err(e) => {
                        error!("{}", e);
                        TaskResponse::Error(e)
                    }
                };
                if let Err(e) = reqs.send(response).await {
                    error!("Error -> {:?}", e);
                    return;
                }
            }
            Some(Ok(TaskRequest::ApplyPolicy(
                intune_device_id,
                account_id,
                graph_token,
                intune_token,
                iwservice_token,
            ))) => {
                debug!("Received task -> ApplyPolicy(...)");
                let intune_device_id = match intune_device_id {
                    Some(id) => id,
                    None => {
                        debug!("Device not enrolled in Intune, skipping");
                        if let Err(e) = reqs.send(TaskResponse::Success(0)).await {
                            error!("Error -> {:?}", e);
                            return;
                        }
                        continue;
                    }
                };
                let noncompliant_rules = match apply_intune_policy(
                    &intune_device_id,
                    cfg,
                    &account_id,
                    &graph_token,
                    &intune_token,
                    &iwservice_token,
                )
                .await
                {
                    Ok(r) => r,
                    Err(e) => {
                        error!("Failed to apply Intune policies: {:?}", e);
                        if let Err(e) = reqs
                            .send(TaskResponse::Error(format!(
                                "Failed to apply Intune policies: {:?}",
                                e
                            )))
                            .await
                        {
                            error!("Error -> {:?}", e);
                            return;
                        }
                        continue;
                    }
                };

                let response = if noncompliant_rules.is_empty() {
                    debug!("tasks: policy applied, device is compliant");
                    TaskResponse::Success(0)
                } else {
                    debug!(
                        count = noncompliant_rules.len(),
                        "tasks: policy applied, device is non-compliant"
                    );
                    TaskResponse::NonCompliant(noncompliant_rules)
                };

                if let Err(e) = reqs.send(response).await {
                    error!("Error -> {:?}", e);
                    return;
                }
            }
            Some(Ok(TaskRequest::SubordinateIds(username, start, count))) => {
                debug!(
                    "Received task -> SubordinateIds({:?}, {}, {})",
                    username, start, count
                );

                let resp = match setup_subordinate_ids(&username, start, count) {
                    Ok(()) => TaskResponse::Success(0),
                    Err(msg) => {
                        error!(
                            "Failed to setup subordinate IDs for {:?}: {}",
                            username, msg
                        );
                        TaskResponse::Error(msg)
                    }
                };

                if let Err(e) = reqs.send(resp).await {
                    error!("Error -> {:?}", e);
                    return;
                }
            }
            Some(Err(e)) => {
                error!("Error -> {:?}", e);
                return;
            }
            None => {
                debug!("Task connection closed");
                return;
            }
        }
    }
}

#[tokio::main(flavor = "current_thread")]
async fn main() -> ExitCode {
    // let cuid = get_current_uid();
    // let cgid = get_current_gid();
    // We only need to check effective id
    let ceuid = get_effective_uid();
    let cegid = get_effective_gid();
    let systemd_booted = sd_notify::booted().unwrap_or(false);

    let config_path = Path::new(DEFAULT_CONFIG_PATH);
    let config_path_str = match config_path.to_str() {
        Some(cps) => cps,
        None => {
            error!("Unable to turn config_path to str");
            return ExitCode::FAILURE;
        }
    };

    let cfg = match HimmelblauConfig::new(Some(config_path_str)) {
        Ok(c) => c,
        Err(e) => {
            error!("Failed to parse {}: {}", config_path_str, e);
            return ExitCode::FAILURE;
        }
    };

    if cfg.get_debug() {
        std::env::set_var("RUST_LOG", "debug");
    }

    #[allow(clippy::expect_used)]
    tracing_forest::worker_task()
        .set_global(true)
        // Fall back to stderr
        .map_sender(|sender| sender.or_stderr())
        .build_on(|subscriber| {
            subscriber.with(
                EnvFilter::try_from_default_env()
                    .or_else(|_| EnvFilter::try_new("info"))
                    .expect("Failed to init envfilter"),
            )
        })
        .on(async {
            let span = span!(Level::INFO, "Task daemon initialization");
            let _enter = span.enter();

            if ceuid != 0 || cegid != 0 {
                error!("Refusing to run - this process *MUST* operate as root.");
                return ExitCode::FAILURE;
            }

            let task_sock_path = cfg.get_task_socket_path();
            debug!("Attempting to use {} ...", task_sock_path);

            let (broadcast_tx, mut broadcast_rx) = broadcast::channel(4);
            let mut d_broadcast_rx = broadcast_tx.subscribe();

            let server = tokio::spawn(async move {
                loop {
                    info!("Attempting to connect to himmelblaud ...");

                    tokio::select! {
                        _ = broadcast_rx.recv() => {
                            break;
                        }
                        connect_res = UnixStream::connect(&task_sock_path) => {
                            match connect_res {
                                Ok(stream) => {
                                    info!("Found himmelblaud, waiting for tasks ...");
                                    // Yep! Now let the main handler do it's job.
                                    // If it returns (dc, etc, then we loop and try again).
                                    tokio::select! {
                                        _ = d_broadcast_rx.recv() => {
                                            break;
                                        }
                                        _ = handle_tasks(stream, &cfg) => {
                                            continue;
                                        }
                                    }
                                }
                                Err(e) => {
                                    debug!("\\---> {:?}", e);
                                    error!("Unable to find himmelblaud, sleeping ...");
                                    // Back off.
                                    time::sleep(Duration::from_millis(5000)).await;
                                }
                            }
                        }
                    }
                }
            });

            info!("Server started ...");

            drop(_enter);

            if systemd_booted {
                if let Ok(monotonic_usec) = sd_notify::NotifyState::monotonic_usec_now() {
                    let _ = sd_notify::notify(&[NotifyState::Ready, monotonic_usec]);
                }
            }

            // Ping the systemd watchdog at half the configured WatchdogSec interval.
            let mut watchdog_interval = if systemd_booted {
                std::env::var("WATCHDOG_USEC")
                    .ok()
                    .and_then(|v| v.parse::<u64>().ok())
                    .map(|usec| time::interval(Duration::from_micros(usec / 2)))
            } else {
                None
            };

            loop {
                tokio::select! {
                    Ok(()) = tokio::signal::ctrl_c() => {
                        break
                    }
                    Some(()) = async move {
                        let sigterm = tokio::signal::unix::SignalKind::terminate();
                        #[allow(clippy::unwrap_used)]
                        tokio::signal::unix::signal(sigterm).unwrap().recv().await
                    } => {
                        break
                    }
                    Some(()) = async move {
                        let sigterm = tokio::signal::unix::SignalKind::alarm();
                        #[allow(clippy::unwrap_used)]
                        tokio::signal::unix::signal(sigterm).unwrap().recv().await
                    } => {
                        // Ignore
                    }
                    Some(()) = async move {
                        let sigterm = tokio::signal::unix::SignalKind::hangup();
                        #[allow(clippy::unwrap_used)]
                        tokio::signal::unix::signal(sigterm).unwrap().recv().await
                    } => {
                        // Ignore
                    }
                    Some(()) = async move {
                        let sigterm = tokio::signal::unix::SignalKind::user_defined1();
                        #[allow(clippy::unwrap_used)]
                        tokio::signal::unix::signal(sigterm).unwrap().recv().await
                    } => {
                        // Ignore
                    }

                    Some(()) = async move {
                        let sigterm = tokio::signal::unix::SignalKind::user_defined2();
                        #[allow(clippy::unwrap_used)]
                        tokio::signal::unix::signal(sigterm).unwrap().recv().await
                    } => {
                        // Ignore
                    }
                    _ = async {
                        match watchdog_interval.as_mut() {
                            Some(interval) => interval.tick().await,
                            None => std::future::pending().await,
                        }
                    } => {
                        let _ = sd_notify::notify(&[NotifyState::Watchdog]);
                    }
                }
            }

            info!("Signal received, shutting down");
            if systemd_booted {
                if let Ok(monotonic_usec) = sd_notify::NotifyState::monotonic_usec_now() {
                    let _ = sd_notify::notify(&[NotifyState::Stopping, monotonic_usec]);
                }
            }

            // Send a broadcast that we are done.
            if let Err(e) = broadcast_tx.send(true) {
                error!("Unable to shutdown workers {:?}", e);
            }

            let _ = server.await;
            ExitCode::SUCCESS
        })
        .await
}

#[cfg(test)]
mod tests {
    #![allow(clippy::unwrap_used, clippy::expect_used, clippy::panic)]

    use super::*;

    /// The exact payload from GHSA-x259-23ph-65m5.
    const ADVISORY_PAYLOAD: &str = "padding:100000:65536\nattacker:0:65536\npadding";
    const TENANT_ID: &str = "11111111-2222-3333-4444-555555555555";

    #[test]
    fn validate_subid_username_accepts_legitimate_names() {
        for username in [
            "user",
            "user@example.com",
            "first.last-1_2@contoso.com",
            "user+alias@example.com",
            "jos\u{e9}@example.com",
        ] {
            assert!(
                validate_subid_username(username).is_ok(),
                "expected {:?} to be accepted",
                username
            );
        }
    }

    #[test]
    fn group_membership_matches_newline_terminated_last_member() {
        let users = "alice,bob\n";

        assert!(group_members_include(users, "bob"));
    }

    #[test]
    fn validate_subid_username_rejects_record_forging_names() {
        for username in [
            "",
            "attacker:0:65536",
            ADVISORY_PAYLOAD,
            "victim\nroot",
            "victim\r\nroot",
            "victim\0root",
        ] {
            assert!(
                validate_subid_username(username).is_err(),
                "expected {:?} to be rejected",
                username
            );
        }
    }

    #[test]
    fn add_subid_entry_rejects_payload_and_leaves_file_untouched() {
        let subid_file = tempfile::NamedTempFile::new().expect("failed to create temp subid file");
        let path = subid_file.path();

        let before = fs::read(path).unwrap_or_default();

        assert!(add_subid_entry(ADVISORY_PAYLOAD, 100000, 65536, path).is_err());

        let after = fs::read(path).unwrap_or_default();
        assert_eq!(before, after, "subid file must not be modified");
    }

    #[test]
    fn add_subid_entry_appends_a_single_record_for_a_valid_name() {
        let subid_file = tempfile::NamedTempFile::new().expect("failed to create temp subid file");
        let path = subid_file.path();

        assert!(add_subid_entry("user@example.com", 2100000000, 65536, path).is_ok());

        let contents = fs::read_to_string(path).unwrap_or_default();
        assert_eq!(contents, "user@example.com:2100000000:65536\n");

        // A second call for the same user must not duplicate the record.
        assert!(add_subid_entry("user@example.com", 2100000000, 65536, path).is_ok());

        let contents = fs::read_to_string(path).unwrap_or_default();
        assert_eq!(contents, "user@example.com:2100000000:65536\n");
    }

    #[test]
    fn profile_photo_temp_file_is_private() {
        let icons_dir = tempfile::tempdir().expect("failed to create temp icon directory");
        let profile_photo = create_profile_photo_temp_file(icons_dir.path())
            .expect("failed to create profile photo");

        let mode = profile_photo
            .as_file()
            .metadata()
            .expect("failed to read profile photo metadata")
            .permissions()
            .mode()
            & 0o777;
        assert_eq!(mode, 0o600);
    }

    #[test]
    fn write_kerberos_config_snippet_creates_missing_config_dir() {
        let tmpdir = tempfile::tempdir().expect("failed to create temp dir");
        let krb_conf_dir = tmpdir.path().join("krb5.conf.d");

        write_kerberos_config_snippet_to(
            Some(".example.com, example.com, invalid:realm".to_string()),
            TENANT_ID,
            &krb_conf_dir,
        )
        .expect("expected kerberos config snippet to be written");

        assert!(krb_conf_dir.is_dir());
        let snippet_path = krb_conf_dir.join(format!("himmelblau_{TENANT_ID}.conf"));
        let contents =
            fs::read_to_string(snippet_path).expect("expected kerberos config snippet to exist");
        assert!(contents.contains("[libdefaults]\n\tdns_canonicalize_hostname = false\n"));
        assert!(contents.contains(&format!(
            "\t\tkdc = https://login.microsoftonline.com/{TENANT_ID}/kerberos"
        )));
        assert!(contents.contains("\t.example.com = KERBEROS.MICROSOFTONLINE.COM"));
        assert!(contents.contains("\texample.com = KERBEROS.MICROSOFTONLINE.COM"));
        assert!(!contents.contains("invalid:realm = KERBEROS.MICROSOFTONLINE.COM"));
    }

    #[test]
    fn write_kerberos_config_snippet_rejects_non_directory_path() {
        let krb_conf_dir =
            tempfile::NamedTempFile::new().expect("failed to create temp config path");

        let err = write_kerberos_config_snippet_to(None, TENANT_ID, krb_conf_dir.path())
            .expect_err("expected non-directory config path to be rejected");

        assert!(err.contains("is not a directory"));
    }

    #[test]
    fn write_kerberos_config_snippet_rejects_invalid_tenant_without_creating_dir() {
        let tmpdir = tempfile::tempdir().expect("failed to create temp dir");
        let krb_conf_dir = tmpdir.path().join("krb5.conf.d");

        let err = write_kerberos_config_snippet_to(None, "not-a-tenant-id", &krb_conf_dir)
            .expect_err("expected invalid tenant ID to be rejected");

        assert!(err.contains("Failed to validate tenant ID"));
        assert!(!krb_conf_dir.exists());
    }
}
