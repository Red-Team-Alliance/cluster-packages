/*
 * Unix Azure Entra ID implementation
 * Copyright (C) William Brown <william@blackhats.net.au> and the Kanidm team 2018-2024
 * Copyright (C) David Mulder <dmulder@samba.org> 2024
 *
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/.
 */
#![deny(warnings)]
#![warn(unused_extern_crates)]
#![deny(clippy::todo)]
#![deny(clippy::unimplemented)]
#![deny(clippy::unwrap_used)]
#![deny(clippy::expect_used)]
#![deny(clippy::panic)]
#![deny(clippy::unreachable)]
#![deny(clippy::await_holding_lock)]
#![deny(clippy::needless_pass_by_value)]
#![deny(clippy::trivially_copy_pass_by_ref)]

use std::collections::{HashMap, HashSet};
use std::error::Error;
use std::fs::metadata;
use std::io;
use std::io::Error as IoError;
use std::os::unix::fs::MetadataExt;
use std::os::unix::io::FromRawFd;
use std::path::{Path, PathBuf};
use std::process::ExitCode;
use std::sync::Arc;
use std::time::Duration;

use bytes::{BufMut, BytesMut};
use clap::{Arg, ArgAction, Command};
use futures::{SinkExt, StreamExt};
use himmelblau::intune::NoncompliantRule;
use himmelblau::{ClientInfo, IdToken, UserToken as UnixUserToken};
use himmelblau_unix_common::config::{split_username, HimmelblauConfig};
use himmelblau_unix_common::constants::{
    DEFAULT_APP_ID, DEFAULT_CONFIG_PATH, INTUNE_POLICY_TASK_TIMEOUT_SECS,
};
use himmelblau_unix_common::db::{Cache, CacheTxn, Db};
use himmelblau_unix_common::idprovider::himmelblau::HimmelblauMultiProvider;
use himmelblau_unix_common::idprovider::interface::{Id, IdProvider};
use himmelblau_unix_common::resolver::{AuthSession, Resolver};
use himmelblau_unix_common::unix_config::UidAttr;
use himmelblau_unix_common::unix_passwd::{parse_etc_group, parse_etc_passwd};
use himmelblau_unix_common::unix_proto::{
    ClientRequest, ClientResponse, PamAuthResponse, TaskRequest, TaskResponse,
};
use himmelblau_unix_common::user_map::UserMap;
use himmelblau_unix_common::{tpm_init, tpm_loadable_machine_key, tpm_machine_key};
use idmap::{gen_subid_start, SUBID_COUNT};
use uuid::Uuid;

use kanidm_utils_users::{get_current_gid, get_current_uid, get_effective_gid, get_effective_uid};
use libc::umask;
use sd_notify::NotifyState;
use sketching::tracing_forest::traits::*;
use sketching::tracing_forest::util::*;
use sketching::tracing_forest::{self};
use tokio::fs::File;
use tokio::io::AsyncReadExt; // for read_to_end()
use tokio::net::{UnixListener, UnixStream};
use tokio::sync::broadcast;
use tokio::sync::mpsc::{channel, Receiver, Sender};
use tokio::sync::oneshot;
use tokio::sync::Mutex;
use tokio::time;
use tokio_util::codec::{Decoder, Encoder, Framed};
use tracing::span;

use kanidm_hsm_crypto::provider::Tpm;

use notify_debouncer_full::{new_debouncer, notify::RecursiveMode};

mod broker;
use broker::Broker;
use identity_dbus_broker::himmelblau_broker_serve_with_listener;

mod prt_memfd;

//=== the codec

#[derive(Debug)]
enum TaskOutcome {
    Status(i32),
    NonCompliant(Vec<NoncompliantRule>),
}

type AsyncTaskRequest = (TaskRequest, oneshot::Sender<TaskOutcome>);
type IntunePolicyThrottle = Arc<Mutex<HashMap<String, IntunePolicyThrottleState>>>;

const INTUNE_POLICY_THROTTLE_INTERVAL: Duration = Duration::from_secs(30 * 60);
const LOCAL_GROUPS_TASK_QUEUE_TIMEOUT: Duration = Duration::from_millis(100);
const LOCAL_GROUPS_TASK_RESPONSE_TIMEOUT: Duration = Duration::from_millis(1000);

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum IntunePolicyThrottleState {
    InFlight,
    LastRun(time::Instant),
}

#[derive(Default)]
struct ClientCodec;

impl Decoder for ClientCodec {
    type Error = io::Error;
    type Item = ClientRequest;

    fn decode(&mut self, src: &mut BytesMut) -> Result<Option<Self::Item>, Self::Error> {
        trace!("Attempting to decode request ...");
        match serde_json::from_slice::<ClientRequest>(src) {
            Ok(msg) => {
                // Clear the buffer for the next message.
                src.clear();
                Ok(Some(msg))
            }
            _ => Ok(None),
        }
    }
}

impl Encoder<ClientResponse> for ClientCodec {
    type Error = io::Error;

    fn encode(&mut self, msg: ClientResponse, dst: &mut BytesMut) -> Result<(), Self::Error> {
        trace!("Attempting to send response -> {:?} ...", msg);
        let data = serde_json::to_vec(&msg).map_err(|e| {
            error!("socket encoding error -> {:?}", e);
            io::Error::other("JSON encode error")
        })?;
        dst.put(data.as_slice());
        Ok(())
    }
}

#[derive(Default)]
struct TaskCodec;

impl Decoder for TaskCodec {
    type Error = io::Error;
    type Item = TaskResponse;

    fn decode(&mut self, src: &mut BytesMut) -> Result<Option<Self::Item>, Self::Error> {
        match serde_json::from_slice::<TaskResponse>(src) {
            Ok(msg) => {
                // Clear the buffer for the next message.
                src.clear();
                Ok(Some(msg))
            }
            _ => Ok(None),
        }
    }
}

impl Encoder<TaskRequest> for TaskCodec {
    type Error = io::Error;

    fn encode(&mut self, msg: TaskRequest, dst: &mut BytesMut) -> Result<(), Self::Error> {
        debug!(
            "Attempting to send request -> {:?} ...",
            msg.as_safe_string()
        );
        let data = serde_json::to_vec(&msg).map_err(|e| {
            error!("socket encoding error -> {:?}", e);
            io::Error::other("JSON encode error")
        })?;
        dst.put(data.as_slice());
        Ok(())
    }
}

/// Pass this a file path and it'll look for the file and remove it if it's there.
fn rm_if_exist(p: &str) {
    if Path::new(p).exists() {
        debug!("Removing requested file {:?}", p);
        let _ = std::fs::remove_file(p).map_err(|e| {
            error!(
                "Failure while attempting to attempting to remove {:?} -> {:?}",
                p, e
            );
        });
    } else {
        debug!("Path {:?} doesn't exist, not attempting to remove.", p);
    }
}

async fn handle_task_client(
    stream: UnixStream,
    task_channel_tx: &Sender<AsyncTaskRequest>,
    task_channel_rx: &mut Receiver<AsyncTaskRequest>,
) -> Result<(), Box<dyn Error>> {
    // setup the codec
    let mut reqs = Framed::new(stream, TaskCodec);

    loop {
        // TODO wait on the channel OR the task handler, so we know
        // when it closes.
        let v = match task_channel_rx.recv().await {
            Some(v) => v,
            None => return Ok(()),
        };

        debug!("Sending Task -> {:?}", v.0.as_safe_string());

        // Write the req to the socket.
        if let Err(_e) = reqs.send(v.0.clone()).await {
            // re-queue the event if not timed out.
            // This is indicated by the one shot being dropped.
            if !v.1.is_closed() {
                let _ = task_channel_tx
                    .send_timeout(v, Duration::from_millis(100))
                    .await;
            }
            // now return the error.
            return Err(Box::new(IoError::other("oh no!")));
        }

        match reqs.next().await {
            Some(Ok(TaskResponse::Success(status))) => {
                debug!("Task was acknowledged and completed.");
                // Send a result back via the one-shot
                // Ignore if it fails.
                let _ = v.1.send(TaskOutcome::Status(status));
            }
            Some(Ok(TaskResponse::Error(msg))) => {
                warn!("Task returned an error: {}", msg);
                // Send a failure status back via the one-shot so the
                // caller knows, but don't kill the task connection.
                let _ = v.1.send(TaskOutcome::Status(1));
            }
            Some(Ok(TaskResponse::NonCompliant(rules))) => {
                debug!(
                    count = rules.len(),
                    "Task completed; device reported non-compliant by Intune"
                );
                let _ = v.1.send(TaskOutcome::NonCompliant(rules));
            }
            other => {
                error!("Error -> {:?}", other);
                return Err(Box::new(IoError::other("oh no!")));
            }
        }
    }
}

/// Authorize a Hello PIN change against the credentials of the connecting peer.
///
/// The main daemon socket is world-connectable by design — NSS lookups and PAM
/// entry points that run in the user's own context must be able to reach it.
/// `PamChangeAuthToken` therefore cannot rely on socket permissions for
/// authorization, and the bearer token it carries is caller-supplied and never
/// signature-verified. Bind the request to the peer instead.
///
/// * `peer_uid` — the SO_PEERCRED uid of the connection.
/// * `target_uid` — the resolved POSIX uid of the account being changed, or
///   `None` when the account could not be resolved.
///
/// root is allowed because `chauthtok` normally runs from a setuid-root helper
/// (`passwd`, `login`, `sshd`). Any other peer may only change its own PIN.
fn peer_may_change_hello_pin(peer_uid: u32, target_uid: Option<u32>) -> bool {
    peer_uid == 0 || target_uid == Some(peer_uid)
}

async fn is_account_sudoer(
    cachelayer: &Resolver<HimmelblauMultiProvider>,
    cfg: &HimmelblauConfig,
    account_id: &str,
) -> bool {
    for sudo_group in cfg.get_sudo_groups() {
        let sudo_group_uuid = match Uuid::parse_str(&sudo_group) {
            Ok(uuid) => uuid,
            Err(e) => {
                debug!("Failed to parse a sudo group: {}", e);
                continue;
            }
        };

        let members = cachelayer.get_groupmembers(sudo_group_uuid).await;
        if members.iter().any(|member| member == account_id) {
            return true;
        }
    }

    false
}

async fn submit_local_groups_task(
    task_channel_tx: &Sender<AsyncTaskRequest>,
    account_id: String,
    is_sudoer: bool,
) -> Result<(), ()> {
    let (tx, rx) = oneshot::channel();

    task_channel_tx
        .send_timeout(
            (TaskRequest::LocalGroups(account_id, is_sudoer), tx),
            LOCAL_GROUPS_TASK_QUEUE_TIMEOUT,
        )
        .await
        .map_err(|_| ())?;

    match time::timeout(LOCAL_GROUPS_TASK_RESPONSE_TIMEOUT, rx).await {
        Ok(Ok(TaskOutcome::Status(0))) => Ok(()),
        _ => Err(()),
    }
}

async fn reconcile_local_groups_once(
    cachelayer: &Resolver<HimmelblauMultiProvider>,
    task_channel_tx: &Sender<AsyncTaskRequest>,
    cfg: &HimmelblauConfig,
) {
    let sudo_groups = cfg.get_sudo_groups();
    if cfg.get_local_groups().is_empty() && sudo_groups.is_empty() {
        trace!("Skipping local group reconciliation; no local groups configured");
        return;
    }

    let sudo_group_ids: HashSet<Uuid> = sudo_groups
        .iter()
        .filter_map(|sudo_group| match Uuid::parse_str(sudo_group) {
            Ok(uuid) => Some(uuid),
            Err(e) => {
                debug!("Failed to parse a sudo group: {}", e);
                None
            }
        })
        .collect();

    let accounts = match cachelayer.get_unexpired_nssaccounts().await {
        Ok(accounts) => accounts,
        Err(()) => {
            warn!("Unable to fetch cached users for local group reconciliation");
            return;
        }
    };

    for account in accounts {
        let is_sudoer = if sudo_group_ids.is_empty() {
            false
        } else {
            let token = match cachelayer.refresh_cached_usertoken(&account.name).await {
                Ok(Some(token)) => token,
                Ok(None) => {
                    trace!(
                        account_id = account.name.as_str(),
                        "Skipping local group reconciliation for missing user"
                    );
                    continue;
                }
                Err(()) => {
                    warn!(
                        account_id = account.name.as_str(),
                        "Failed to refresh cached user before local group reconciliation"
                    );
                    continue;
                }
            };

            token
                .groups
                .iter()
                .any(|group| sudo_group_ids.contains(&group.uuid))
        };

        if submit_local_groups_task(task_channel_tx, account.name.clone(), is_sudoer)
            .await
            .is_err()
        {
            warn!(
                account_id = account.name.as_str(),
                "Failed to reconcile local groups for cached user"
            );
        }
    }
}

async fn reconcile_local_groups_periodically(
    cachelayer: Arc<Resolver<HimmelblauMultiProvider>>,
    task_channel_tx: Arc<Sender<AsyncTaskRequest>>,
    cfg: HimmelblauConfig,
    mut shutdown_rx: broadcast::Receiver<bool>,
) {
    let interval_secs = cfg.get_local_groups_reconcile_interval();
    if interval_secs == 0 {
        info!("Periodic local group reconciliation disabled");
        return;
    }

    let mut interval = time::interval(Duration::from_secs(interval_secs));
    interval.set_missed_tick_behavior(time::MissedTickBehavior::Delay);

    loop {
        tokio::select! {
            _ = shutdown_rx.recv() => {
                break;
            }
            _ = interval.tick() => {
                reconcile_local_groups_once(&cachelayer, &task_channel_tx, &cfg).await;
            }
        }
    }

    info!("Stopped local group reconciler");
}

async fn handle_client(
    sock: UnixStream,
    cachelayer: Arc<Resolver<HimmelblauMultiProvider>>,
    task_channel_tx: &Sender<AsyncTaskRequest>,
    intune_policy_throttle: IntunePolicyThrottle,
    cfg: HimmelblauConfig,
) -> Result<(), Box<dyn Error>> {
    trace!("Accepted connection");

    let Ok(ucred) = sock.peer_cred() else {
        return Err(Box::new(IoError::other(
            "Unable to verify peer credentials.",
        )));
    };

    let mut reqs = Framed::new(sock, ClientCodec);
    let mut pam_auth_session_state = None;

    // Setup a broadcast channel so that if we have an unexpected disconnection, we can
    // tell consumers to stop work.
    let (shutdown_tx, _shutdown_rx) = broadcast::channel(1);

    trace!("Waiting for requests ...");
    while let Some(Ok(req)) = reqs.next().await {
        let resp = match req {
            ClientRequest::NssAccounts => {
                trace!("nssaccounts req");
                cachelayer
                    .get_nssaccounts()
                    .await
                    .map(ClientResponse::NssAccounts)
                    .unwrap_or_else(|_| {
                        error!("unable to enum accounts");
                        ClientResponse::NssAccounts(Vec::new())
                    })
            }
            ClientRequest::NssAccountByUid(gid) => {
                trace!("nssaccountbyuid req");
                cachelayer
                    .get_nssaccount_gid(gid)
                    .await
                    .map(ClientResponse::NssAccount)
                    .unwrap_or_else(|_| {
                        error!("unable to load account, returning empty.");
                        ClientResponse::NssAccount(None)
                    })
            }
            ClientRequest::NssAccountByName(account_id) => {
                let account_id = account_id.to_lowercase();
                trace!("nssaccountbyname req");
                cachelayer
                    .get_nssaccount_name(account_id.as_str())
                    .await
                    .map(ClientResponse::NssAccount)
                    .unwrap_or_else(|_| {
                        error!("unable to load account, returning empty.");
                        ClientResponse::NssAccount(None)
                    })
            }
            ClientRequest::NssGroups => {
                trace!("nssgroups req");
                cachelayer
                    .get_nssgroups()
                    .await
                    .map(ClientResponse::NssGroups)
                    .unwrap_or_else(|_| {
                        error!("unable to enum groups");
                        ClientResponse::NssGroups(Vec::new())
                    })
            }
            ClientRequest::NssGroupByGid(gid) => {
                trace!("nssgroupbygid req");
                cachelayer
                    .get_nssgroup_gid(gid)
                    .await
                    .map(ClientResponse::NssGroup)
                    .unwrap_or_else(|_| {
                        error!("unable to load group, returning empty.");
                        ClientResponse::NssGroup(None)
                    })
            }
            ClientRequest::NssGroupByName(grp_id) => {
                trace!("nssgroupbyname req");
                cachelayer
                    .get_nssgroup_name(grp_id.as_str())
                    .await
                    .map(ClientResponse::NssGroup)
                    .unwrap_or_else(|_| {
                        error!("unable to load group, returning empty.");
                        ClientResponse::NssGroup(None)
                    })
            }
            ClientRequest::NssInitgroups(account_id) => {
                let account_id = account_id.to_lowercase();
                trace!("nssinitgroups req");
                cachelayer
                    .get_initgroups(account_id.as_str())
                    .await
                    .map(ClientResponse::NssInitgroups)
                    .unwrap_or_else(|_| {
                        error!("unable to load initgroups.");
                        ClientResponse::Error
                    })
            }
            ClientRequest::PamAuthenticateInit(account_id, service, no_hello_pin, force_reauth) => {
                let account_id = account_id.to_lowercase();
                let span = span!(Level::INFO, "pam authenticate init");
                trace!("pam authenticate init");

                async {
                    // We may re-init upon auth failure, at which point we will
                    // disregard the previous state and start over.
                    match cachelayer
                        .pam_account_authenticate_init(
                            account_id.as_str(),
                            service.as_str(),
                            no_hello_pin,
                            force_reauth,
                            shutdown_tx.subscribe(),
                        )
                        .await
                    {
                        Ok((auth_session, pam_auth_response)) => {
                            pam_auth_session_state = Some(auth_session);
                            pam_auth_response.into()
                        }
                        Err(_) => ClientResponse::Error,
                    }
                }
                .instrument(span)
                .await
            }
            ClientRequest::PamAuthenticateStep(pam_next_req) => {
                let span = span!(Level::INFO, "pam authenticate step");
                async {
                    trace!("pam authenticate step");
                    match &mut pam_auth_session_state {
                        Some(auth_session) => {
                            match cachelayer
                                .pam_account_authenticate_step(auth_session, pam_next_req)
                                .await
                                .map(|pam_auth_response| pam_auth_response.into())
                                .unwrap_or(ClientResponse::Error)
                            {
                                ClientResponse::PamAuthenticateStepResponse(mut resp) => {
                                    match auth_session {
                                        AuthSession::Success(account_id) => {
                                            let account_id = account_id.to_lowercase();
                                            match resp {
                                                PamAuthResponse::Success => {
                                                    let is_oidc_auth =
                                                        cfg.get_oidc_issuer_url().is_some();

                                                    if cfg.get_logon_script().is_some() {
                                                        let scopes = cfg.get_logon_token_scopes();
                                                        let domain = split_username(&account_id)
                                                            .map(|(_, domain)| domain);
                                                        let client_id = domain.and_then(|d| {
                                                            cfg.get_logon_token_app_id(d)
                                                        });
                                                        let access_token = match cachelayer
                                                            .get_user_accesstoken(
                                                                Id::Name(account_id.to_string()),
                                                                scopes,
                                                                client_id,
                                                                None,
                                                                None,
                                                            )
                                                            .await
                                                        {
                                                            Some(token) => token
                                                                .access_token
                                                                .clone()
                                                                .unwrap_or("".to_string()),
                                                            None => "".to_string(),
                                                        };

                                                        let (tx, rx) = oneshot::channel();

                                                        match task_channel_tx
                                                            .send_timeout(
                                                                (
                                                                    TaskRequest::LogonScript(
                                                                        account_id.to_string(),
                                                                        access_token.to_string(),
                                                                    ),
                                                                    tx,
                                                                ),
                                                                Duration::from_millis(100),
                                                            )
                                                            .await
                                                        {
                                                            Ok(()) => {
                                                                // Now wait for the other end OR timeout.
                                                                match time::timeout_at(
                                                                    time::Instant::now()
                                                                        + Duration::from_secs(
                                                                            cfg.get_logon_script_timeout(),
                                                                        ),
                                                                    rx,
                                                                )
                                                                .await
                                                                {
                                                                    Ok(Ok(TaskOutcome::Status(status))) => {
                                                                        if status == 2 {
                                                                            let msg = "Authentication was explicitly denied by the logon script";
                                                                            debug!(msg);
                                                                            resp =
                                                                                PamAuthResponse::Denied(msg.to_string());
                                                                        }
                                                                    }
                                                                    Ok(Ok(_)) => {
                                                                        let msg = "Logon script returned an unexpected task response";
                                                                        error!(msg);
                                                                        resp =
                                                                            PamAuthResponse::Denied(msg.to_string());
                                                                    }
                                                                    Ok(Err(e)) => {
                                                                        let msg = format!(
                                                                            "Execution of logon script failed: {:?}",
                                                                            e
                                                                        );
                                                                        error!(msg);
                                                                        resp =
                                                                            PamAuthResponse::Denied(msg);
                                                                    }
                                                                    Err(e) => {
                                                                        let msg = format!(
                                                                            "Execution of logon script timed out: {:?}",
                                                                            e
                                                                        );
                                                                        error!(msg);
                                                                        resp =
                                                                            PamAuthResponse::Denied(msg);
                                                                    }
                                                                }
                                                            }
                                                            Err(e) => {
                                                                error!("Execution of logon script failed: {:?}", e);
                                                            }
                                                        }
                                                    }

                                                    // Initialize the user Kerberos ccache
                                                    if cfg.get_enable_kerberos_cache()
                                                        && !is_oidc_auth
                                                    {
                                                        if let Some((uid, gid, tgt_cloud, tgt_ad, top_level_names, tenant_id)) =
                                                            cachelayer
                                                                .get_user_tgts(Id::Name(
                                                                    account_id.to_string(),
                                                                ))
                                                                .await
                                                        {
                                                            let (tx, rx) = oneshot::channel();
                                                            match task_channel_tx
                                                                .send_timeout(
                                                                    (
                                                                        TaskRequest::KerberosConfig(top_level_names, tenant_id),
                                                                        tx,
                                                                    ),
                                                                    Duration::from_millis(100),
                                                                )
                                                                .await
                                                            {
                                                                Ok(()) => {
                                                                    // Now wait for the other end OR timeout.
                                                                    match time::timeout_at(
                                                                        time::Instant::now()
                                                                            + Duration::from_secs(60),
                                                                        rx,
                                                                    )
                                                                    .await
                                                                    {
                                                                        Ok(Ok(TaskOutcome::Status(status))) => {
                                                                            if status != 0 {
                                                                                error!("Kerberos config failed for {}: Status code: {}", account_id, status);
                                                                            }
                                                                        }
                                                                        Ok(Ok(TaskOutcome::NonCompliant(_))) => {
                                                                            error!("Kerberos config: unexpected NonCompliant task outcome");
                                                                        }
                                                                        Ok(Err(e)) => {
                                                                            error!("Kerberos config failed for {}: {:?}", account_id, e);
                                                                        }
                                                                        Err(e) => {
                                                                            error!("Kerberos config failed for {}: {:?}", account_id, e);
                                                                        }
                                                                    }
                                                                }
                                                                Err(e) => {
                                                                    error!("Kerberos config failed for {}: {:?}", account_id, e);
                                                                }
                                                            }

                                                            let (tx, rx) = oneshot::channel();

                                                            match task_channel_tx
                                                                .send_timeout(
                                                                    (
                                                                        TaskRequest::KerberosTGTs(
                                                                            uid,
                                                                            gid,
                                                                            tgt_cloud,
                                                                            tgt_ad,
                                                                        ),
                                                                        tx,
                                                                    ),
                                                                    Duration::from_millis(100),
                                                                )
                                                                .await
                                                            {
                                                                Ok(()) => {
                                                                    // Now wait for the other end OR timeout.
                                                                    match time::timeout_at(
                                                                        time::Instant::now()
                                                                            + Duration::from_secs(60),
                                                                        rx,
                                                                    )
                                                                    .await
                                                                    {
                                                                        Ok(Ok(TaskOutcome::Status(status))) => {
                                                                            if status != 0 {
                                                                                error!("Kerberos credential cache load failed for {}: Status code: {}", account_id, status);
                                                                            }
                                                                        }
                                                                        Ok(Ok(TaskOutcome::NonCompliant(_))) => {
                                                                            error!("Kerberos credential cache load: unexpected NonCompliant task outcome");
                                                                        }
                                                                        Ok(Err(e)) => {
                                                                            error!("Kerberos credential cache load failed for {}: {:?}", account_id, e);
                                                                        }
                                                                        Err(e) => {
                                                                            error!("Kerberos credential cache load failed for {}: {:?}", account_id, e);
                                                                        }
                                                                    }
                                                                }
                                                                Err(e) => {
                                                                    error!("Kerberos credential cache load failed for {}: {:?}", account_id, e);
                                                                }
                                                            }
                                                        }
                                                    }

                                                    // Fetch the user Profile picture
                                                    if cfg.get_fetch_profile_picture()
                                                        && !is_oidc_auth
                                                    {
                                                        spawn_profile_photo_fetch(
                                                            cachelayer.clone(),
                                                            task_channel_tx.clone(),
                                                            account_id.clone(),
                                                        );
                                                    }

                                                    // Apply Intune policies
                                                    if !is_oidc_auth && cfg.get_apply_policy() {
                                                        spawn_intune_policy_application_if_due(
                                                            cachelayer.clone(),
                                                            cfg.clone(),
                                                            task_channel_tx.clone(),
                                                            intune_policy_throttle.clone(),
                                                            account_id.clone(),
                                                        )
                                                        .await;
                                                    }

                                                    ClientResponse::PamAuthenticateStepResponse(resp)
                                                }
                                                _ => ClientResponse::PamAuthenticateStepResponse(resp),
                                            }
                                        }
                                        _ => ClientResponse::PamAuthenticateStepResponse(resp),
                                    }
                                }
                                other => other,
                            }
                        }
                        None => {
                            warn!("Attempt to continue auth session while current session is inactive");
                            ClientResponse::Error
                        }
                    }
                }
                .instrument(span)
                .await
            }
            ClientRequest::PamAccountAllowed(account_id) => {
                let account_id = account_id.to_lowercase();
                trace!("pam account allowed");
                cachelayer
                    .pam_account_allowed(account_id.as_str())
                    .await
                    .map(ClientResponse::PamStatus)
                    .unwrap_or(ClientResponse::Error)
            }
            ClientRequest::PamAccountBeginSession(account_id) => {
                let account_id = account_id.to_lowercase();
                let span = span!(Level::INFO, "pam account begin session");
                async {
                    trace!("pam account begin session");
                    match cachelayer
                        .pam_account_beginsession(account_id.as_str())
                        .await
                    {
                        Ok(Some(info)) => {
                            let (tx, rx) = oneshot::channel();

                            let resp1 = match task_channel_tx
                                .send_timeout(
                                    (TaskRequest::HomeDirectory(info), tx),
                                    Duration::from_millis(100),
                                )
                                .await
                            {
                                Ok(()) => {
                                    // Now wait for the other end OR timeout.
                                    match time::timeout_at(
                                        time::Instant::now() + Duration::from_millis(1000),
                                        rx,
                                    )
                                    .await
                                    {
                                        Ok(Ok(_)) => {
                                            trace!("Task completed, returning to pam ...");
                                            ClientResponse::Ok
                                        }
                                        _ => {
                                            // Timeout or other error.
                                            ClientResponse::Error
                                        }
                                    }
                                }
                                Err(_) => {
                                    // We could not submit the req. Move on!
                                    ClientResponse::Error
                                }
                            };

                            let is_sudoer =
                                is_account_sudoer(&cachelayer, &cfg, account_id.as_str()).await;

                            let resp2 = match submit_local_groups_task(
                                task_channel_tx,
                                account_id.to_string(),
                                is_sudoer,
                            )
                            .await
                            {
                                Ok(()) => {
                                    trace!("Task completed, returning to pam ...");
                                    ClientResponse::Ok
                                }
                                Err(()) => ClientResponse::Error,
                            };

                            // Set up subordinate IDs for container support
                            let subid_range = cfg.get_subid_range();
                            let mapped_name = cfg.map_upn_to_name(&account_id);
                            let subid_start = gen_subid_start(&mapped_name, subid_range);

                            let (tx, rx) = oneshot::channel();

                            let resp3 = match task_channel_tx
                                .send_timeout(
                                    (
                                        TaskRequest::SubordinateIds(
                                            mapped_name,
                                            subid_start,
                                            SUBID_COUNT,
                                        ),
                                        tx,
                                    ),
                                    Duration::from_millis(100),
                                )
                                .await
                            {
                                Ok(()) => {
                                    // Now wait for the other end OR timeout.
                                    match time::timeout_at(
                                        time::Instant::now() + Duration::from_millis(1000),
                                        rx,
                                    )
                                    .await
                                    {
                                        Ok(Ok(_)) => {
                                            trace!("SubordinateIds task completed");
                                            ClientResponse::Ok
                                        }
                                        _ => {
                                            // Timeout or error - log but don't fail the session
                                            debug!("SubordinateIds task timed out or failed");
                                            ClientResponse::Ok
                                        }
                                    }
                                }
                                Err(e) => {
                                    // Failed to submit - log but don't fail the session
                                    debug!("Failed to submit SubordinateIds task: {:?}", e);
                                    ClientResponse::Ok
                                }
                            };

                            // Return error only if critical tasks (home dir or local groups) failed
                            // SubordinateIds failure is non-critical
                            let _ = resp3; // Acknowledge resp3 but don't affect the result
                            match resp1 {
                                ClientResponse::Error => ClientResponse::Error,
                                _ => resp2,
                            }
                        }
                        _ => ClientResponse::Error,
                    }
                }
                .instrument(span)
                .await
            }
            ClientRequest::PamChangeAuthToken(account_id, access_token, refresh_token, new_pin) => {
                let account_id = account_id.to_lowercase();
                let span = span!(Level::INFO, "sm_chauthtok req");
                async {
                    trace!("sm_chauthtok req");

                    // Bind this request to the connecting peer (GHSA-6gp8-pp9v-gx45).
                    // Without this, any local user can enroll a Hello PIN for any
                    // cached account, because the only other check is an `spn`
                    // comparison against an unverified JWT payload.
                    //
                    // Compare UIDs, not names: `NssUser::name` follows the
                    // `uid_attr_map` setting (spn vs. name), while `NssUser::uid`
                    // is always the account's gidnumber — the POSIX uid the peer
                    // actually runs as.
                    let target_uid = if ucred.uid() == 0 {
                        None // not consulted; root is always authorized
                    } else {
                        cachelayer
                            .get_nssaccount_name(&account_id)
                            .await
                            .ok()
                            .flatten()
                            .map(|nss_user| nss_user.uid)
                    };
                    if !peer_may_change_hello_pin(ucred.uid(), target_uid) {
                        error!(
                            "Refusing Hello PIN change for {}: uid {} is neither root \
                             nor the owner of that account",
                            account_id,
                            ucred.uid()
                        );
                        return ClientResponse::Error;
                    }

                    let token = UnixUserToken {
                        token_type: "Bearer".to_string(),
                        scope: None,
                        expires_in: 0,
                        ext_expires_in: 0,
                        access_token: Some(access_token),
                        refresh_token,
                        id_token: IdToken::default(),
                        client_info: ClientInfo::default(),
                        prt: None,
                    };
                    cachelayer
                        .change_auth_token(&account_id, &token, &new_pin)
                        .await
                        .map(|_| ClientResponse::Ok)
                        .unwrap_or(ClientResponse::Error)
                }
                .instrument(span)
                .await
            }
            ClientRequest::InvalidateCache => {
                trace!("invalidate cache");
                cachelayer
                    .invalidate()
                    .await
                    .map(|_| ClientResponse::Ok)
                    .unwrap_or(ClientResponse::Error)
            }
            ClientRequest::ClearCache => {
                trace!("clear cache");
                if ucred.uid() == 0 {
                    cachelayer
                        .clear_cache()
                        .await
                        .map(|_| ClientResponse::Ok)
                        .unwrap_or(ClientResponse::Error)
                } else {
                    error!("Only root may clear the cache");
                    ClientResponse::Error
                }
            }
            ClientRequest::OfflineBreakGlass(ttl) => {
                trace!("offline break glass");
                if ucred.uid() == 0 {
                    cachelayer
                        .offline_break_glass(ttl)
                        .await
                        .map(|_| ClientResponse::Ok)
                        .unwrap_or(ClientResponse::Error)
                } else {
                    error!("Only root may set the offline break glass time to live");
                    ClientResponse::Error
                }
            }
            ClientRequest::Status => {
                trace!("status check");
                if cachelayer.test_connection().await {
                    ClientResponse::Ok
                } else {
                    ClientResponse::Error
                }
            }
            ClientRequest::ComplianceCheck => {
                let span = span!(Level::INFO, "compliance check");
                async {
                    trace!("compliance check requested");

                    if !cfg.get_apply_policy() || cfg.get_oidc_issuer_url().is_some() {
                        warn!("compliance check: unavailable for current configuration");
                        return ClientResponse::Error;
                    }

                    // Resolve the calling user's Unix UID to an account name.
                    // NOTE: this intentionally uses `get_nssaccount_gid()` even though
                    // `ucred.uid()` is a UID. In the current NSS mapping, the resolver
                    // looks up the account via `gidnumber`, which is used as the NSS uid.
                    let account_id = match cachelayer.get_nssaccount_gid(ucred.uid()).await {
                        Ok(Some(nss_user)) => nss_user.name,
                        _ => {
                            error!(
                                "compliance check: could not resolve uid {} to an account",
                                ucred.uid()
                            );
                            return ClientResponse::Error;
                        }
                    };

                    let account_id = account_id.to_lowercase();
                    if !start_intune_policy_application(
                        &intune_policy_throttle,
                        &account_id,
                        false,
                    )
                    .await
                    {
                        warn!(
                            "compliance check: Intune policy application is already in flight for {}",
                            account_id
                        );
                        return ClientResponse::Error;
                    }

                    let resp = match apply_intune_policy_for_account(
                        &cachelayer,
                        &cfg,
                        task_channel_tx,
                        &account_id,
                    )
                    .await
                    {
                        Ok(()) => {
                            debug!("compliance check: succeeded");
                            ClientResponse::Ok
                        }
                        Err(ApplyPolicyError::NonCompliant(rules)) => {
                            debug!(
                                count = rules.len(),
                                "compliance check: device is non-compliant for {}", account_id
                            );
                            ClientResponse::NonCompliant(rules)
                        }
                        Err(ApplyPolicyError::TokenAcquisitionFailed) => {
                            error!(
                                "compliance check: could not acquire tokens; \
                                 ensure the session is unsealed and the broker/daemon is available"
                            );
                            ClientResponse::Error
                        }
                        Err(ApplyPolicyError::MissingAccessToken) => {
                            error!("compliance check: missing access token");
                            ClientResponse::NotAuthenticated
                        }
                        Err(ApplyPolicyError::PolicyFailure) => {
                            warn!("compliance check: policy failure");
                            ClientResponse::Error
                        }
                        Err(ApplyPolicyError::DispatchFailed(e)) => {
                            warn!("compliance check: failed to dispatch task: {}", e);
                            ClientResponse::Error
                        }
                        Err(ApplyPolicyError::TaskError(e)) => {
                            warn!("compliance check: task error: {}", e);
                            ClientResponse::Error
                        }
                        Err(ApplyPolicyError::TaskTimeout(e)) => {
                            warn!("compliance check: timeout: {}", e);
                            ClientResponse::Error
                        }
                    };

                    complete_intune_policy_application(&intune_policy_throttle, account_id).await;
                    resp
                }
                .instrument(span)
                .await
            }
            ClientRequest::PamTryUnseal(account_id, cred) => {
                let account_id = account_id.to_lowercase();
                let span = span!(Level::INFO, "pam try unseal");
                async {
                    trace!("pam try unseal");
                    match cachelayer.pam_try_unseal(&account_id, &cred).await {
                        Ok(true) => {
                            debug!("pam_try_unseal: succeeded for {}", account_id);
                        }
                        Ok(false) => {
                            debug!("pam_try_unseal: failed for {}", account_id);
                        }
                        Err(()) => {
                            error!("pam_try_unseal: error for {}", account_id);
                        }
                    }
                    ClientResponse::Ok
                }
                .instrument(span)
                .await
            }
        };
        reqs.send(resp).await?;
        reqs.flush().await?;
        trace!("flushed response!");
    }

    // Signal any tasks that they need to stop.
    if let Err(shutdown_err) = shutdown_tx.send(()) {
        warn!(
            ?shutdown_err,
            "Unable to signal tasks to stop, they will naturally timeout instead."
        )
    }

    // Disconnect them
    trace!("Disconnecting client ...");
    Ok(())
}

enum ApplyPolicyError {
    /// One of the `get_user_accesstoken` calls returned `None`. This covers a
    /// range of conditions: broker/transport errors, no cached user token,
    /// expired refresh material, or a sealed/inactive user session.
    TokenAcquisitionFailed,
    /// A token was returned, but its `access_token` field was `None` — the
    /// most specific indicator that the session cannot currently produce a
    /// usable access token (e.g. sealed Hello secret).
    MissingAccessToken,
    /// Failed to send the `ApplyPolicy` task to the tasks daemon channel.
    DispatchFailed(String),
    /// The tasks daemon did not respond within the 5-minute Intune script
    /// budget.
    TaskTimeout(String),
    /// The tasks daemon returned an error while running the policy.
    TaskError(String),
    /// A CSE errored while applying policy. Distinct from a non-compliant
    /// verdict: the pipeline itself failed, no verdict was produced.
    PolicyFailure,
    /// Intune reported the device as non-compliant.
    NonCompliant(Vec<NoncompliantRule>),
}

fn should_start_intune_policy_application(
    throttle_state: &mut HashMap<String, IntunePolicyThrottleState>,
    account_id: &str,
    now: time::Instant,
    enforce_recent_run_throttle: bool,
) -> bool {
    let account_key = intune_policy_throttle_key(account_id);

    match throttle_state.get(&account_key) {
        Some(IntunePolicyThrottleState::InFlight) => false,
        Some(IntunePolicyThrottleState::LastRun(last_run))
            if enforce_recent_run_throttle
                && now.duration_since(*last_run) < INTUNE_POLICY_THROTTLE_INTERVAL =>
        {
            false
        }
        _ => {
            throttle_state.insert(account_key, IntunePolicyThrottleState::InFlight);
            true
        }
    }
}

fn intune_policy_throttle_key(account_id: &str) -> String {
    account_id.to_lowercase()
}

async fn start_intune_policy_application(
    intune_policy_throttle: &IntunePolicyThrottle,
    account_id: &str,
    enforce_recent_run_throttle: bool,
) -> bool {
    let mut throttle_state = intune_policy_throttle.lock().await;
    should_start_intune_policy_application(
        &mut throttle_state,
        account_id,
        time::Instant::now(),
        enforce_recent_run_throttle,
    )
}

async fn complete_intune_policy_application(
    intune_policy_throttle: &IntunePolicyThrottle,
    account_id: String,
) {
    let account_key = intune_policy_throttle_key(&account_id);

    intune_policy_throttle.lock().await.insert(
        account_key,
        IntunePolicyThrottleState::LastRun(time::Instant::now()),
    );
}

async fn spawn_intune_policy_application_if_due(
    cachelayer: Arc<Resolver<HimmelblauMultiProvider>>,
    cfg: HimmelblauConfig,
    task_channel_tx: Sender<AsyncTaskRequest>,
    intune_policy_throttle: IntunePolicyThrottle,
    account_id: String,
) {
    if !start_intune_policy_application(&intune_policy_throttle, &account_id, true).await {
        debug!(
            "Skipping Intune policy application for {}; recently run or already in flight",
            account_id
        );
        return;
    }

    spawn_intune_policy_application(
        cachelayer,
        cfg,
        task_channel_tx,
        intune_policy_throttle,
        account_id,
    );
}

fn spawn_profile_photo_fetch(
    cachelayer: Arc<Resolver<HimmelblauMultiProvider>>,
    task_channel_tx: Sender<AsyncTaskRequest>,
    account_id: String,
) {
    tokio::spawn(async move {
        let Some(token) = cachelayer
            .get_user_accesstoken(Id::Name(account_id.clone()), vec![], None, None, None)
            .await
        else {
            return;
        };
        let Some(access_token) = token.access_token.as_ref() else {
            return;
        };
        let (tx, rx) = oneshot::channel();
        if task_channel_tx
            .send_timeout(
                (
                    TaskRequest::LoadProfilePhoto(account_id, access_token.to_string()),
                    tx,
                ),
                Duration::from_millis(100),
            )
            .await
            .is_err()
        {
            error!("Fetching user profile picture failed");
            return;
        }
        match time::timeout_at(time::Instant::now() + Duration::from_secs(60), rx).await {
            Ok(_) => info!("Fetching user profile picture succeeded"),
            _ => error!("Fetching user profile picture failed"),
        }
    });
}

fn spawn_intune_policy_application(
    cachelayer: Arc<Resolver<HimmelblauMultiProvider>>,
    cfg: HimmelblauConfig,
    task_channel_tx: Sender<AsyncTaskRequest>,
    intune_policy_throttle: IntunePolicyThrottle,
    account_id: String,
) {
    tokio::spawn(async move {
        match apply_intune_policy_for_account(
            cachelayer.as_ref(),
            &cfg,
            &task_channel_tx,
            &account_id,
        )
        .await
        {
            Ok(()) => {
                debug!("Successfully applied Intune policies");
            }
            Err(ApplyPolicyError::TokenAcquisitionFailed)
            | Err(ApplyPolicyError::MissingAccessToken) => {
                warn!("Intune failure: could not acquire tokens");
            }
            Err(ApplyPolicyError::PolicyFailure) => {
                warn!("Intune failure");
            }
            Err(ApplyPolicyError::NonCompliant(rules)) => {
                warn!(
                    count = rules.len(),
                    "Intune reports device is non-compliant"
                );
            }
            Err(ApplyPolicyError::DispatchFailed(e))
            | Err(ApplyPolicyError::TaskTimeout(e))
            | Err(ApplyPolicyError::TaskError(e)) => {
                warn!("Intune failure: {}", e);
            }
        }

        complete_intune_policy_application(&intune_policy_throttle, account_id).await;
    });
}

async fn apply_intune_policy_for_account(
    cachelayer: &Resolver<HimmelblauMultiProvider>,
    cfg: &HimmelblauConfig,
    task_channel_tx: &Sender<AsyncTaskRequest>,
    account_id: &str,
) -> Result<(), ApplyPolicyError> {
    let intune_device_id = split_username(account_id)
        .map(|(_, domain)| domain)
        .and_then(|domain| {
            // The intune_device_id may have been written after startup,
            // so we re-read the config here.
            HimmelblauConfig::new(Some(&cfg.get_config_file()))
                .ok()
                .map(|cfg| cfg.get_intune_device_id(domain))
        })
        .flatten();

    let graph_token = cachelayer
        .get_user_accesstoken(
            Id::Name(account_id.to_string()),
            vec!["00000003-0000-0000-c000-000000000000/.default".to_string()],
            Some(DEFAULT_APP_ID.to_string()),
            None,
            None,
        )
        .await;
    let intune_token = cachelayer
        .get_user_accesstoken(
            Id::Name(account_id.to_string()),
            vec!["0000000a-0000-0000-c000-000000000000/.default".to_string()],
            Some(DEFAULT_APP_ID.to_string()),
            None,
            None,
        )
        .await;
    let iwservice_token = cachelayer
        .get_user_accesstoken(
            Id::Name(account_id.to_string()),
            vec!["b8066b99-6e67-41be-abfa-75db1a2c8809/.default".to_string()],
            Some(DEFAULT_APP_ID.to_string()),
            None,
            None,
        )
        .await;

    let (graph_token, intune_token, iwservice_token) =
        match (graph_token, intune_token, iwservice_token) {
            (Some(g), Some(i), Some(w)) => (g, i, w),
            _ => return Err(ApplyPolicyError::TokenAcquisitionFailed),
        };

    let (graph_at, intune_at, iwservice_at) = match (
        graph_token.access_token.clone(),
        intune_token.access_token.clone(),
        iwservice_token.access_token.clone(),
    ) {
        (Some(g), Some(i), Some(w)) => (g, i, w),
        _ => return Err(ApplyPolicyError::MissingAccessToken),
    };

    let (tx, rx) = oneshot::channel();

    task_channel_tx
        .send_timeout(
            (
                TaskRequest::ApplyPolicy(
                    intune_device_id,
                    account_id.to_string(),
                    graph_at,
                    intune_at,
                    iwservice_at,
                ),
                tx,
            ),
            Duration::from_millis(500),
        )
        .await
        .map_err(|e| ApplyPolicyError::DispatchFailed(e.to_string()))?;

    // From the MS specs:
    // Custom compliance discovery scripts for Microsoft Intune
    // Limits:
    // Scripts must have a limited run time:
    //   On Linux, scripts must take five minutes or less to run.
    // Add a small buffer on top of the task runtime budget for scheduling
    // and IPC overhead when receiving the task outcome.
    let task_timeout =
        Duration::from_secs(INTUNE_POLICY_TASK_TIMEOUT_SECS) + Duration::from_secs(5);
    match time::timeout_at(time::Instant::now() + task_timeout, rx).await {
        Ok(Ok(TaskOutcome::Status(0))) => Ok(()),
        Ok(Ok(TaskOutcome::Status(_))) => Err(ApplyPolicyError::PolicyFailure),
        Ok(Ok(TaskOutcome::NonCompliant(rules))) => Err(ApplyPolicyError::NonCompliant(rules)),
        Ok(Err(e)) => Err(ApplyPolicyError::TaskError(e.to_string())),
        Err(e) => Err(ApplyPolicyError::TaskTimeout(e.to_string())),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    const ACCOUNT_ID: &str = "user@example.com";

    #[test]
    fn intune_policy_throttle_allows_first_run_and_marks_in_flight() {
        let mut throttle_state = HashMap::new();
        let now = time::Instant::now();

        assert!(should_start_intune_policy_application(
            &mut throttle_state,
            ACCOUNT_ID,
            now,
            true,
        ));
        assert_eq!(
            throttle_state.get(ACCOUNT_ID),
            Some(&IntunePolicyThrottleState::InFlight)
        );
    }

    #[test]
    fn intune_policy_throttle_skips_in_flight_run() {
        let mut throttle_state =
            HashMap::from([(ACCOUNT_ID.to_string(), IntunePolicyThrottleState::InFlight)]);
        let now = time::Instant::now();

        assert!(!should_start_intune_policy_application(
            &mut throttle_state,
            ACCOUNT_ID,
            now,
            true,
        ));
        assert_eq!(
            throttle_state.get(ACCOUNT_ID),
            Some(&IntunePolicyThrottleState::InFlight)
        );
    }

    #[test]
    fn intune_policy_throttle_normalizes_account_id_for_in_flight_run() {
        let mut throttle_state =
            HashMap::from([(ACCOUNT_ID.to_string(), IntunePolicyThrottleState::InFlight)]);
        let now = time::Instant::now();

        assert!(!should_start_intune_policy_application(
            &mut throttle_state,
            "User@Example.com",
            now,
            true,
        ));
        assert_eq!(
            throttle_state.get(ACCOUNT_ID),
            Some(&IntunePolicyThrottleState::InFlight)
        );
        assert!(!throttle_state.contains_key("User@Example.com"));
    }

    #[test]
    fn intune_policy_throttle_skips_recent_run() {
        let mut throttle_state = HashMap::new();
        let now = time::Instant::now();
        throttle_state.insert(
            ACCOUNT_ID.to_string(),
            IntunePolicyThrottleState::LastRun(
                now - INTUNE_POLICY_THROTTLE_INTERVAL + Duration::from_secs(1),
            ),
        );

        assert!(!should_start_intune_policy_application(
            &mut throttle_state,
            ACCOUNT_ID,
            now,
            true,
        ));
    }

    #[test]
    fn intune_policy_throttle_allows_run_after_interval() {
        let mut throttle_state = HashMap::new();
        let now = time::Instant::now();
        throttle_state.insert(
            ACCOUNT_ID.to_string(),
            IntunePolicyThrottleState::LastRun(now - INTUNE_POLICY_THROTTLE_INTERVAL),
        );

        assert!(should_start_intune_policy_application(
            &mut throttle_state,
            ACCOUNT_ID,
            now,
            true,
        ));
        assert_eq!(
            throttle_state.get(ACCOUNT_ID),
            Some(&IntunePolicyThrottleState::InFlight)
        );
    }

    #[test]
    fn intune_policy_throttle_tracks_users_independently() {
        let mut throttle_state = HashMap::new();
        let now = time::Instant::now();
        throttle_state.insert(
            ACCOUNT_ID.to_string(),
            IntunePolicyThrottleState::LastRun(now),
        );

        assert!(should_start_intune_policy_application(
            &mut throttle_state,
            "other@example.com",
            now,
            true,
        ));
        assert_eq!(
            throttle_state.get(ACCOUNT_ID),
            Some(&IntunePolicyThrottleState::LastRun(now))
        );
        assert_eq!(
            throttle_state.get("other@example.com"),
            Some(&IntunePolicyThrottleState::InFlight)
        );
    }

    #[test]
    fn intune_policy_compliance_check_ignores_recent_run_throttle() {
        let mut throttle_state = HashMap::new();
        let now = time::Instant::now();
        throttle_state.insert(
            ACCOUNT_ID.to_string(),
            IntunePolicyThrottleState::LastRun(now),
        );

        assert!(should_start_intune_policy_application(
            &mut throttle_state,
            ACCOUNT_ID,
            now,
            false,
        ));
        assert_eq!(
            throttle_state.get(ACCOUNT_ID),
            Some(&IntunePolicyThrottleState::InFlight)
        );
    }

    #[test]
    fn intune_policy_compliance_check_skips_in_flight_run() {
        let mut throttle_state =
            HashMap::from([(ACCOUNT_ID.to_string(), IntunePolicyThrottleState::InFlight)]);
        let now = time::Instant::now();

        assert!(!should_start_intune_policy_application(
            &mut throttle_state,
            ACCOUNT_ID,
            now,
            false,
        ));
        assert_eq!(
            throttle_state.get(ACCOUNT_ID),
            Some(&IntunePolicyThrottleState::InFlight)
        );
    }

    #[tokio::test]
    async fn intune_policy_throttle_normalizes_account_id_on_completion() {
        let throttle_state: IntunePolicyThrottle = Arc::new(Mutex::new(HashMap::new()));

        complete_intune_policy_application(&throttle_state, "User@Example.com".to_string()).await;

        let throttle_state = throttle_state.lock().await;
        assert!(matches!(
            throttle_state.get(ACCOUNT_ID),
            Some(IntunePolicyThrottleState::LastRun(_))
        ));
        assert!(!throttle_state.contains_key("User@Example.com"));
    }

    #[test]
    fn hello_pin_change_allows_root() {
        assert!(peer_may_change_hello_pin(0, None));
        assert!(peer_may_change_hello_pin(0, Some(1000)));
    }

    #[test]
    fn hello_pin_change_allows_account_owner() {
        assert!(peer_may_change_hello_pin(1000, Some(1000)));
    }

    #[test]
    fn hello_pin_change_denies_other_users() {
        assert!(!peer_may_change_hello_pin(1000, Some(1001)));
    }

    #[test]
    fn hello_pin_change_denies_unresolvable_account() {
        assert!(!peer_may_change_hello_pin(1000, None));
    }
}

async fn process_etc_passwd_group(
    cachelayer: &Resolver<HimmelblauMultiProvider>,
) -> Result<(), Box<dyn Error>> {
    let mut file = File::open("/etc/passwd").await?;
    let mut contents = vec![];
    file.read_to_end(&mut contents).await?;

    let users = parse_etc_passwd(contents.as_slice()).map_err(|_| "Invalid passwd content")?;

    let mut file = File::open("/etc/group").await?;
    let mut contents = vec![];
    file.read_to_end(&mut contents).await?;

    let groups = parse_etc_group(contents.as_slice()).map_err(|_| "Invalid group content")?;

    let id_iter = users
        .iter()
        .map(|user| (user.name.clone(), user.uid))
        .chain(groups.iter().map(|group| (group.name.clone(), group.gid)));

    cachelayer.reload_nxset(id_iter).await;

    Ok(())
}

#[tokio::main(flavor = "current_thread")]
async fn main() -> ExitCode {
    let cuid = get_current_uid();
    let ceuid = get_effective_uid();
    let cgid = get_current_gid();
    let cegid = get_effective_gid();
    let systemd_booted = sd_notify::booted().unwrap_or(false);

    let clap_args = Command::new("himmelblaud")
        .version(env!("CARGO_PKG_VERSION"))
        .about("Himmelblau Authentication Daemon")
        .arg(
            Arg::new("skip-root-check")
                .help("Allow running as root. Don't use this in production as it is risky!")
                .short('r')
                .long("skip-root-check")
                .env("HIMMELBLAU_SKIP_ROOT_CHECK")
                .action(ArgAction::SetTrue),
        )
        .arg(
            Arg::new("debug")
                .help("Show extra debug information")
                .short('d')
                .long("debug")
                .env("HIMMELBLAU_DEBUG")
                .action(ArgAction::SetTrue),
        )
        .arg(
            Arg::new("configtest")
                .help("Display the configuration and exit")
                .short('t')
                .long("configtest")
                .action(ArgAction::SetTrue),
        )
        .arg(
            Arg::new("config")
                .help("Set the config file path")
                .short('c')
                .long("config")
                .default_value(DEFAULT_CONFIG_PATH)
                .env("HIMMELBLAU_CONFIG")
                .action(ArgAction::Set),
        )
        .get_matches();

    if clap_args.get_flag("debug") {
        std::env::set_var("RUST_LOG", "debug");
    }
    let Some(cfg_path_str) = clap_args.get_one::<String>("config") else {
        error!("Failed to pull the config path");
        return ExitCode::FAILURE;
    };
    // Read the configuration
    let cfg = match HimmelblauConfig::new(Some(cfg_path_str)) {
        Ok(c) => c,
        Err(e) => {
            error!("Failed to parse {}: {}", cfg_path_str, e);
            return ExitCode::FAILURE;
        }
    };
    if cfg.get_debug() {
        std::env::set_var("RUST_LOG", "debug");
    }

    // https://docs.rs/console-subscriber/latest/console_subscriber/struct.Builder.html#method.with_default_env
    #[cfg(feature = "console")]
    let console_layer = console_subscriber::ConsoleLayer::builder()
        .with_default_env()
        .spawn();

    #[allow(clippy::expect_used)]
    tracing_forest::worker_task()
        .set_global(true)
        // Fall back to stderr
        .map_sender(|sender| sender.or_stderr())
        .build_on(|subscriber| {
           #[cfg(feature = "console")]
           let subscriber = subscriber
               .with(console_layer);

            subscriber
            .with(EnvFilter::try_from_default_env()
                .or_else(|_| EnvFilter::try_new("info"))
                .expect("Failed to init envfilter")
            )
        })
        .on(async {
            if clap_args.get_flag("skip-root-check") {
                warn!("Skipping root user check, if you're running this for testing, ensure you clean up temporary files.")
                // TODO: this wording is not great m'kay.
            } else if cuid == 0 || ceuid == 0 || cgid == 0 || cegid == 0 {
                error!("Refusing to run - this process must not operate as root.");
                return ExitCode::FAILURE
            };

            let cfg_path: PathBuf = PathBuf::from(cfg_path_str);

            if cfg.get_effective_config_paths().is_empty() {
                error!(
                    "Client config missing from {} - cannot start up. Quitting.",
                    cfg_path_str
                );
                let diag = kanidm_lib_file_permissions::diagnose_path(cfg_path.as_ref());
                info!(%diag);
                return ExitCode::FAILURE
            }

            for effective_path in cfg.get_effective_config_paths() {
                let cfg_meta = match metadata(effective_path) {
                    Ok(v) => v,
                    Err(e) => {
                        error!("Unable to read metadata for {} - {:?}", effective_path.display(), e);
                        let diag = kanidm_lib_file_permissions::diagnose_path(effective_path.as_ref());
                        info!(%diag);
                        return ExitCode::FAILURE
                    }
                };
                if !kanidm_lib_file_permissions::readonly(&cfg_meta) {
                    warn!("permissions on {} may not be secure. Should be readonly to running uid. This could be a security risk ...",
                        effective_path.display()
                        );
                }

                if cfg_meta.uid() == cuid || cfg_meta.uid() == ceuid {
                    warn!("WARNING: {} owned by the current uid, which may allow file permission changes. This could be a security risk ...",
                        effective_path.display()
                    );
                }
            }

            if clap_args.get_flag("configtest") {
                eprintln!("###################################");
                eprintln!("Dumping configs:\n###################################");
                eprintln!("###################################");
                eprintln!("Config (from {:#?})", cfg.get_effective_config_paths());
                eprintln!("{:?}", cfg);
                return ExitCode::SUCCESS;
            }

            // Validate that idmap_range and subid_range don't overlap
            let subid_range = cfg.get_subid_range();
            let idmap_range = cfg.get_idmap_range("_");

            // Ranges overlap if one starts before the other ends
            if idmap_range.0 <= subid_range.1 && subid_range.0 <= idmap_range.1 {
                error!(
                    "Configuration error: idmap_range ({}-{}) overlaps with subid_range ({}-{}). \
                    These ranges must not overlap to prevent ID conflicts. \
                    Please adjust your configuration.",
                    idmap_range.0, idmap_range.1, subid_range.0, subid_range.1
                );
                return ExitCode::FAILURE;
            }

            info!(
                "Subordinate ID support enabled with range {}-{}",
                subid_range.0, subid_range.1
            );

            let socket_path = cfg.get_socket_path();
            let task_socket_path = cfg.get_task_socket_path();
            let broker_socket_path = cfg.get_broker_socket_path();

            // Collect all file descriptors passed by systemd (socket
            // activation + FD store) in one shot, before anything
            // else consumes the LISTEN_* environment variables.
            let mut systemd_fds = prt_memfd::collect_systemd_fds();

            // Only clean up sockets that were NOT passed via socket
            // activation, as those are owned by systemd.
            if systemd_fds.main_socket.is_none() {
                rm_if_exist(&socket_path);
            }
            if systemd_fds.task_socket.is_none() {
                rm_if_exist(&task_socket_path);
            }
            if systemd_fds.broker_socket.is_none() {
                rm_if_exist(&broker_socket_path);
            }


            // Check the db path will be okay.
            {
                let db_path = PathBuf::from(cfg.get_db_path());
                // We only need to check the parent folder path permissions as the db itself may not exist yet.
                if let Some(db_parent_path) = db_path.parent() {
                    if !db_parent_path.exists() {
                        error!(
                            "Refusing to run, DB folder {} does not exist",
                            db_parent_path
                                .to_str()
                                .unwrap_or("<db_parent_path invalid>")
                        );
                        let diag = kanidm_lib_file_permissions::diagnose_path(db_path.as_ref());
                        info!(%diag);
                        return ExitCode::FAILURE
                    }

                    let db_par_path_buf = db_parent_path.to_path_buf();

                    let i_meta = match metadata(&db_par_path_buf) {
                        Ok(v) => v,
                        Err(e) => {
                            error!(
                                "Unable to read metadata for {} - {:?}",
                                db_par_path_buf
                                    .to_str()
                                    .unwrap_or("<db_par_path_buf invalid>"),
                                e
                            );
                            return ExitCode::FAILURE
                        }
                    };

                    if !i_meta.is_dir() {
                        error!(
                            "Refusing to run - DB folder {} may not be a directory",
                            db_par_path_buf
                                .to_str()
                                .unwrap_or("<db_par_path_buf invalid>")
                        );
                        return ExitCode::FAILURE
                    }
                    if kanidm_lib_file_permissions::readonly(&i_meta) {
                        warn!("WARNING: DB folder permissions on {} indicate it may not be RW. This could cause the server start up to fail!", db_par_path_buf.to_str()
                        .unwrap_or("<db_par_path_buf invalid>")
                        );
                    }

                    if i_meta.mode() & 0o007 != 0 {
                        warn!("WARNING: DB folder {} has 'everyone' permission bits in the mode. This could be a security risk ...", db_par_path_buf.to_str()
                        .unwrap_or("<db_par_path_buf invalid>")
                        );
                    }
                }

                // check to see if the db's already there
                if db_path.exists() {
                    if !db_path.is_file() {
                        error!(
                            "Refusing to run - DB path {} already exists and is not a file.",
                            db_path.to_str().unwrap_or("<db_path invalid>")
                        );
                        let diag = kanidm_lib_file_permissions::diagnose_path(db_path.as_ref());
                        info!(%diag);
                        return ExitCode::FAILURE
                    };

                    match metadata(&db_path) {
                        Ok(v) => v,
                        Err(e) => {
                            error!(
                                "Unable to read metadata for {} - {:?}",
                                db_path.to_str().unwrap_or("<db_path invalid>"),
                                e
                            );
                            let diag = kanidm_lib_file_permissions::diagnose_path(db_path.as_ref());
                            info!(%diag);
                            return ExitCode::FAILURE
                        }
                    };
                    // TODO: permissions dance to enumerate the user's ability to write to the file? ref #456 - r2d2 will happily keep trying to do things without bailing.
                };
            }

            // Create the database
            let db = match Db::new(&cfg.get_db_path()) {
                Ok(db) => db,
                Err(_e) => {
                    error!("Failed to create database");
                    return ExitCode::FAILURE
                }
            };

            // perform any db migrations.
            let mut dbtxn = db.write().await;
            if dbtxn.migrate()
                .and_then(|_| {
                    dbtxn.commit()
                }).is_err() {
                    error!("Failed to migrate database");
                    return ExitCode::FAILURE
                }


            // With the assistance of the DB, setup the HSM and its machine key,
            // first checking for an existing key and then generating a new one
            // if necessary.

            let (auth_value, mut hsm) = tpm_init!(
                cfg,
                db.get_loadable_hsm_key(),
                return ExitCode::FAILURE
            );

            let loadable_machine_key = tpm_loadable_machine_key!(
                db,
                hsm,
                auth_value,
                true,
                // on_error
                return ExitCode::FAILURE
            );

            let machine_key = tpm_machine_key!(
                hsm,
                auth_value,
                loadable_machine_key,
                cfg,
                // on_error
                return ExitCode::FAILURE
            );

            // Okay, the hsm is now loaded and ready to go.

            // Create the identify provider connection
            let mut keystore = db.write().await;
            let idprovider = match HimmelblauMultiProvider::new(cfg.get_config_file().as_str(), &mut keystore).await {
                Ok(idprovider) => idprovider,
                Err(e) => {
                    error!("{}", e);
                    return ExitCode::FAILURE;
                }
            };
            if let Err(err) = keystore.commit() {
                error!(?err, "Failed to commit database transaction, unable to proceed");
                return ExitCode::FAILURE
            }

            // Restore broker PRTs from systemd FileDescriptorStore
            if let Some(data) = prt_memfd::restore_prts(&mut systemd_fds) {
                if let Err(e) = idprovider.import_broker_prts(&data).await {
                    error!("Failed to import PRTs from FD store: {:?}", e);
                } else {
                    info!("Restored broker PRTs from FileDescriptorStore");
                }
            } else {
                debug!("No broker PRTs in FileDescriptorStore (fresh boot or first start)");
            }

            // Setup the tasks socket first.
            let (task_channel_tx, mut task_channel_rx) = channel(16);
            let task_channel_tx = Arc::new(task_channel_tx);

            let task_channel_tx_cln = task_channel_tx.clone();

            let user_map = UserMap::new(&cfg.get_user_map_file());
            let cl_inner = match Resolver::new(
                db,
                idprovider,
                hsm,
                machine_key,
                cfg.get_cache_timeout(),
                cfg.get_pam_allow_groups(),
                cfg.get_oidc_issuer_url().is_some(),
                cfg.get_shell(None),
                cfg.get_home_prefix(None),
                cfg.get_home_attr(None),
                cfg.get_home_alias(None),
                UidAttr::Name,
                UidAttr::Name,
                cfg.get_initgroups_mode(),
                user_map.get_id_overrides(),
            )
            .await
            {
                Ok(c) => c,
                Err(_e) => {
                    error!("Failed to build cache layer.");
                    return ExitCode::FAILURE
                }
            };

            let cachelayer = Arc::new(cl_inner);

            // Setup the root-only task socket.
            // Prefer a socket-activated fd from systemd; fall back to
            // manual bind.
            let task_listener = if let Some(fd) = systemd_fds.task_socket.take() {
                // SAFETY: fd is valid and owned by this process, passed
                // by systemd via socket activation.
                let std_listener = unsafe {
                    std::os::unix::net::UnixListener::from_raw_fd(fd)
                };
                if let Err(e) = std_listener.set_nonblocking(true) {
                    error!("Failed to set task socket non-blocking: {}", e);
                    return ExitCode::FAILURE
                }
                match UnixListener::from_std(std_listener) {
                    Ok(l) => l,
                    Err(e) => {
                        error!("Failed to convert task socket: {}", e);
                        return ExitCode::FAILURE
                    }
                }
            } else {
                let before = unsafe { umask(0o0077) };
                let listener = match UnixListener::bind(task_socket_path.clone()) {
                    Ok(l) => l,
                    Err(_e) => {
                        error!("Failed to bind UNIX socket {}", task_socket_path);
                        return ExitCode::FAILURE
                    }
                };
                let _ = unsafe { umask(before) };
                listener
            };

            // Pre-process /etc/passwd and /etc/group for nxset
            if process_etc_passwd_group(&cachelayer).await.is_err() {
                error!("Failed to process system id providers");
                return ExitCode::FAILURE
            }

            // Start to build the worker tasks
            let (broadcast_tx, mut broadcast_rx) = broadcast::channel(4);
            let mut c_broadcast_rx = broadcast_tx.subscribe();
            let mut d_broadcast_rx = broadcast_tx.subscribe();
            let local_groups_broadcast_rx = broadcast_tx.subscribe();

            let local_groups_cachelayer = cachelayer.clone();
            let local_groups_task_channel_tx = task_channel_tx.clone();
            let local_groups_cfg = cfg.clone();
            let local_groups_reconciler = tokio::spawn(async move {
                reconcile_local_groups_periodically(
                    local_groups_cachelayer,
                    local_groups_task_channel_tx,
                    local_groups_cfg,
                    local_groups_broadcast_rx,
                )
                .await;
            });

            let task_b = tokio::spawn(async move {
                loop {
                    tokio::select! {
                        _ = c_broadcast_rx.recv() => {
                            break;
                        }
                        accept_res = task_listener.accept() => {
                            match accept_res {
                                Ok((socket, _addr)) => {
                                    // Did it come from root?
                                    if let Ok(ucred) = socket.peer_cred() {
                                        if ucred.uid() != 0 {
                                            // move along.
                                            warn!("Task handler not running as root, ignoring ...");
                                            continue;
                                        }
                                    } else {
                                        // move along.
                                        warn!("Unable to determine socked peer cred, ignoring ...");
                                        continue;
                                    };
                                    debug!("A task handler has connected.");
                                    // It did? Great, now we can wait and spin on that one
                                    // client.

                                    tokio::select! {
                                        _ = d_broadcast_rx.recv() => {
                                            break;
                                        }
                                        // We have to check for signals here else this tasks waits forever.
                                        Err(e) = handle_task_client(socket, &task_channel_tx, &mut task_channel_rx) => {
                                            error!("Task client error occurred; error = {:?}", e);
                                        }
                                    }
                                    // If they DC we go back to accept.
                                }
                                Err(err) => {
                                    error!("Task Accept error -> {:?}", err);
                                }
                            }
                        }
                    }
                    // done
                }
                info!("Stopped task connector");
            });

            // TODO: Setup a task that handles pre-fetching here.

            let (inotify_tx, mut inotify_rx) = channel(4);

            #[allow(clippy::blocks_in_conditions)]
            let watcher =
            match new_debouncer(Duration::from_secs(5), None, move |_event| {
                let _ = inotify_tx.try_send(true);
            })
                .and_then(|mut debouncer| {
                    debouncer.watch(Path::new("/etc/passwd"), RecursiveMode::NonRecursive)
                        .map(|()| debouncer)
                })
                .and_then(|mut debouncer| debouncer.watch(Path::new("/etc/group"), RecursiveMode::NonRecursive)
                        .map(|()| debouncer)
                )

            {
                Ok(watcher) => {
                    watcher
                }
                Err(e) => {
                    error!("Failed to setup inotify {:?}",  e);
                    return ExitCode::FAILURE
                }
            };

            let mut c_broadcast_rx = broadcast_tx.subscribe();

            let inotify_cachelayer = cachelayer.clone();
            let task_c = tokio::spawn(async move {
                loop {
                    tokio::select! {
                        _ = c_broadcast_rx.recv() => {
                            break;
                        }
                        _ = inotify_rx.recv() => {
                            if process_etc_passwd_group(&inotify_cachelayer).await.is_err() {
                                error!("Failed to process system id providers");
                            }
                        }
                    }
                }
                info!("Stopped inotify watcher");
            });

            // Spawn the himmelblau dbus broker.
            // Prefer a socket-activated fd from systemd; fall back to
            // manual bind inside himmelblau_broker_serve_with_listener.
            let broker_listener = if let Some(fd) = systemd_fds.broker_socket.take() {
                let std_listener = unsafe {
                    std::os::unix::net::UnixListener::from_raw_fd(fd)
                };
                if let Err(e) = std_listener.set_nonblocking(true) {
                    error!("Failed to set broker socket non-blocking: {}", e);
                    return ExitCode::FAILURE
                }
                match UnixListener::from_std(std_listener) {
                    Ok(l) => Some(l),
                    Err(e) => {
                        error!("Failed to convert broker socket: {}", e);
                        return ExitCode::FAILURE
                    }
                }
            } else {
                None
            };
            let dbus_cachelayer = cachelayer.clone();
            let e_broadcast_rx = broadcast_tx.subscribe();
            let task_d = match himmelblau_broker_serve_with_listener::<Broker>(
                Broker { cachelayer: dbus_cachelayer },
                if broker_listener.is_some() { None } else { Some(broker_socket_path.as_str()) },
                e_broadcast_rx,
                broker_listener,
            ).await {
                Ok(task_d) => task_d,
                Err(e) => {
                    error!("D-Bus error occurred; error = {:?}", e);
                    return ExitCode::FAILURE
                },
            };

            // Setup the main daemon socket.
            // Prefer a socket-activated fd from systemd; fall back to
            // manual bind.
            let listener = if let Some(fd) = systemd_fds.main_socket.take() {
                // SAFETY: fd is valid and owned by this process, passed
                // by systemd via socket activation.
                let std_listener = unsafe {
                    std::os::unix::net::UnixListener::from_raw_fd(fd)
                };
                if let Err(e) = std_listener.set_nonblocking(true) {
                    error!("Failed to set main socket non-blocking: {}", e);
                    return ExitCode::FAILURE
                }
                match UnixListener::from_std(std_listener) {
                    Ok(l) => l,
                    Err(e) => {
                        error!("Failed to convert main socket: {}", e);
                        return ExitCode::FAILURE
                    }
                }
            } else {
                let before = unsafe { umask(0) };
                let listener = match UnixListener::bind(socket_path.clone()) {
                    Ok(l) => l,
                    Err(_e) => {
                        error!("Failed to bind UNIX socket at {}", socket_path);
                        return ExitCode::FAILURE
                    }
                };
                let _ = unsafe { umask(before) };
                listener
            };

            // Keep a reference for PRT FD store persistence on service shutdown.
            let shutdown_cachelayer = cachelayer.clone();
            let intune_policy_throttle = Arc::new(Mutex::new(HashMap::new()));

            let task_a = tokio::spawn(async move {
                loop {
                    let tc_tx = task_channel_tx_cln.clone();
                    let cfg_h = cfg.clone();
                    let intune_policy_throttle = intune_policy_throttle.clone();

                    tokio::select! {
                        _ = broadcast_rx.recv() => {
                            break;
                        }
                        accept_res = listener.accept() => {
                            match accept_res {
                                Ok((socket, _addr)) => {
                                    let cachelayer_ref = cachelayer.clone();
                                    tokio::spawn(async move {
                                        if let Err(e) = handle_client(socket, cachelayer_ref.clone(), &tc_tx, intune_policy_throttle, cfg_h).await
                                        {
                                            debug!("handle_client disconnected; error = {:?}", e);
                                        }
                                    });
                                }
                                Err(err) => {
                                    error!("Error while handling connection -> {:?}", err);
                                }
                            }
                        }
                    }

                }
                info!("Stopped resolver");
            });

            info!("Server started ...");

            if systemd_booted {
                if let Ok(monotonic_usec) = sd_notify::NotifyState::monotonic_usec_now() {
                    let _ = sd_notify::notify(&[NotifyState::Ready, monotonic_usec]);
                }
            }

            // Ping the systemd watchdog at half the configured WatchdogSec interval.
            let mut watchdog_interval = if systemd_booted {
                std::env::var("WATCHDOG_USEC")
                    .ok()
                    .and_then(|v| v.parse::<u64>().ok())
                    .map(|usec| time::interval(Duration::from_micros(usec / 2)))
            } else {
                None
            };

            loop {
                tokio::select! {
                    Ok(()) = tokio::signal::ctrl_c() => {
                        break
                    }
                    Some(()) = async move {
                        let sigterm = tokio::signal::unix::SignalKind::terminate();
                        #[allow(clippy::unwrap_used)]
                        tokio::signal::unix::signal(sigterm).unwrap().recv().await
                    } => {
                        break
                    }
                    Some(()) = async move {
                        let sigterm = tokio::signal::unix::SignalKind::alarm();
                        #[allow(clippy::unwrap_used)]
                        tokio::signal::unix::signal(sigterm).unwrap().recv().await
                    } => {
                        // Ignore
                    }
                    Some(()) = async move {
                        let sigterm = tokio::signal::unix::SignalKind::hangup();
                        #[allow(clippy::unwrap_used)]
                        tokio::signal::unix::signal(sigterm).unwrap().recv().await
                    } => {
                        // Ignore
                    }
                    Some(()) = async move {
                        let sigterm = tokio::signal::unix::SignalKind::user_defined1();
                        #[allow(clippy::unwrap_used)]
                        tokio::signal::unix::signal(sigterm).unwrap().recv().await
                    } => {
                        // Ignore
                    }
                    Some(()) = async move {
                        let sigterm = tokio::signal::unix::SignalKind::user_defined2();
                        #[allow(clippy::unwrap_used)]
                        tokio::signal::unix::signal(sigterm).unwrap().recv().await
                    } => {
                        // Ignore
                    }
                    _ = async {
                        match watchdog_interval.as_mut() {
                            Some(interval) => interval.tick().await,
                            None => std::future::pending().await,
                        }
                    } => {
                        let _ = sd_notify::notify(&[NotifyState::Watchdog]);
                    }
                }
            }

            info!("Signal received, sending down signal to tasks");

            // Persist broker PRTs to systemd FileDescriptorStore so they
            // survive a daemon restart.  Always remove any previously stored
            // FD first so stale credentials are never kept around.
            if systemd_booted {
                prt_memfd::remove_prts_from_fdstore();

                match shutdown_cachelayer.export_broker_prts().await {
                    Ok(data) if !data.is_empty() && data != b"{}".as_slice() => {
                        if let Err(e) = prt_memfd::store_prts_to_fdstore(&data) {
                            error!("Failed to store PRTs in FD store: {:?}", e);
                        } else {
                            info!("Saved broker PRTs to FileDescriptorStore");
                        }
                    }
                    Ok(_) => {
                        debug!("No broker PRTs to persist to FD store");
                    }
                    Err(e) => {
                        error!("Failed to export PRTs: {:?}", e);
                    }
                }
            }

            if systemd_booted {
                if let Ok(monotonic_usec) = sd_notify::NotifyState::monotonic_usec_now() {
                    let _ = sd_notify::notify(&[NotifyState::Stopping, monotonic_usec]);
                }
            }

            // Send a broadcast that we are done.
            if let Err(e) = broadcast_tx.send(true) {
                error!("Unable to shutdown workers {:?}", e);
            }

            drop(watcher);

            let _ = task_a.await;
            let _ = task_b.await;
            let _ = local_groups_reconciler.await;
            let _ = task_c.await;
            let _ = task_d.await;

            ExitCode::SUCCESS
    })
    .await
    // TODO: can we catch signals to clean up sockets etc, especially handy when running as root
}
