/*
   Unix Azure Entra ID implementation
   Copyright (C) David Mulder <dmulder@samba.org> 2024

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
use async_trait::async_trait;
use base64::engine::general_purpose::URL_SAFE_NO_PAD;
use base64::Engine;
use himmelblau_unix_common::idprovider::himmelblau::HimmelblauMultiProvider;
use himmelblau_unix_common::idprovider::interface::Id;
use himmelblau_unix_common::resolver::Resolver;
use identity_dbus_broker::HimmelblauBroker;
use libc::uid_t;
use serde::{Deserialize, Serialize};
use serde_json::json;
use std::error::Error;
use std::sync::Arc;
use std::time::{SystemTime, UNIX_EPOCH};
use url::Url;

#[derive(Serialize, Deserialize, Debug)]
struct AccountReq {
    username: String,
}

#[derive(Serialize, Deserialize, Debug)]
struct PopParamsReq {
    #[serde(rename = "authenticationScheme")]
    authentication_scheme: Option<String>,
    kid: Option<String>,
}

#[derive(Serialize, Deserialize, Debug)]
struct AuthParametersReq {
    #[serde(rename = "requestedScopes")]
    requested_scopes: Vec<String>,
    #[serde(rename = "clientId")]
    client_id: Option<String>,
    #[serde(rename = "redirectUri")]
    redirect_uri: Option<String>,
    #[serde(rename = "popParams")]
    pop_params: Option<PopParamsReq>,
    account: Option<AccountReq>,
}

#[derive(Serialize, Deserialize, Debug)]
struct TokenReq {
    account: Option<AccountReq>,
    #[serde(rename = "authParameters")]
    auth_parameters: AuthParametersReq,
}

#[derive(Serialize, Deserialize, Debug)]
struct SsoCookieReq {
    account: AccountReq,
    #[serde(rename = "ssoUrl")]
    sso_url: Option<String>,
}

/// Extract the `sso_nonce` query parameter from an SSO URL, if present.
/// Returns `None` when the parameter is missing or empty/whitespace-only.
fn extract_sso_nonce(sso_url: Option<&str>) -> Option<String> {
    let url_str = sso_url?;
    let url = Url::parse(url_str).ok()?;
    url.query_pairs()
        .find(|(k, _)| k == "sso_nonce")
        .map(|(_, v)| v.into_owned())
        .filter(|v| !v.trim().is_empty())
}

/// Build a `req_cnf` value from the broker request's `popParams`.
/// When `popParams.authenticationScheme` is `"Pop"` and `kid` is set
/// (e.g. for RDS AAD / Cloud PC), we produce
/// `base64url({"kid":"<kid>"})` which Entra expects as the `req_cnf`
/// query / body parameter. Requests without the PoP scheme or without
/// a kid are treated as bearer token requests (returns None).
fn build_req_cnf(pop_params: &Option<PopParamsReq>) -> Option<String> {
    let pp = pop_params.as_ref()?;
    if !pp
        .authentication_scheme
        .as_deref()
        .is_some_and(|s| s.eq_ignore_ascii_case("pop"))
    {
        return None;
    }
    let kid = pp.kid.as_deref().map(str::trim).filter(|k| !k.is_empty())?;
    let json = serde_json::json!({"kid": kid}).to_string();
    Some(URL_SAFE_NO_PAD.encode(json.as_bytes()))
}

#[derive(Clone)]
pub(crate) struct Broker {
    pub(crate) cachelayer: Arc<Resolver<HimmelblauMultiProvider>>,
}

#[async_trait]
impl HimmelblauBroker for Broker {
    async fn acquire_token_interactively(
        &mut self,
        protocol_version: String,
        correlation_id: String,
        request_json: String,
        uid: uid_t,
    ) -> Result<String, Box<dyn Error>> {
        self.acquire_token_silently(protocol_version, correlation_id, request_json, uid)
            .await
    }

    async fn acquire_token_silently(
        &mut self,
        _protocol_version: String,
        _correlation_id: String,
        request_json: String,
        uid: uid_t,
    ) -> Result<String, Box<dyn Error>> {
        // Double check the user is making a request for their own account
        let user = self
            .cachelayer
            .get_usertoken(Id::Gid(uid))
            .await
            .map_err(|_| "Unable to load account")?
            .ok_or("Unable to find account")?;
        let request: TokenReq =
            serde_json::from_str(&request_json).map_err(|e| format!("{:?}", e))?;
        // account can be at root (Firefox, Chrome) or in authParameters (Edge)
        let account = match request.account {
            Some(x) => x,
            None => request.auth_parameters.account.ok_or("Missing account")?,
        };
        if account.username.to_lowercase() != user.spn.to_lowercase() {
            return Err("Invalid request for user!".into());
        }
        // Normalize and validate the redirect URI: treat empty/whitespace as
        // None, and reject values that are not valid URIs or that contain fragments.
        let redirect_uri = match request.auth_parameters.redirect_uri {
            Some(ref uri) => {
                let trimmed = uri.trim();
                if trimmed.is_empty() {
                    None
                } else {
                    let parsed = Url::parse(trimmed).map_err(|_| "Invalid redirectUri")?;
                    if parsed.fragment().is_some() {
                        return Err("Invalid redirectUri: fragment not allowed".into());
                    }
                    Some(trimmed.to_string())
                }
            }
            None => None,
        };
        let req_cnf = build_req_cnf(&request.auth_parameters.pop_params);
        let token = self
            .cachelayer
            .get_user_accesstoken(
                Id::Name(user.spn.clone()),
                request.auth_parameters.requested_scopes,
                request.auth_parameters.client_id,
                redirect_uri,
                req_cnf,
            )
            .await
            .ok_or("Failed to authenticate user")?;
        let now = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .map_err(|e| format!("{:?}", e))?;
        let res = json!({
            "brokerTokenResponse": {
                "accessToken": token.access_token.clone()
                    .ok_or("Failed to fetch access token")?,
                "accessTokenType": 0,
                "clientInfo": URL_SAFE_NO_PAD.encode(json!(&token.client_info).to_string()),
                "expiresOn": now.as_millis() + u128::from(token.expires_in) * 1000,
                "extendedExpiresOn": (token.ext_expires_in as u64) + now.as_secs(),
                "grantedScopes": token.scope.clone()
                    .ok_or("Failed to fetch scopes")?,
                "idToken": token.id_token.raw.clone().ok_or("Missing raw token")?,
            }
        });
        Ok(res.to_string())
    }

    async fn get_accounts(
        &mut self,
        _protocol_version: String,
        _correlation_id: String,
        _request_json: String,
        uid: uid_t,
    ) -> Result<String, Box<dyn Error>> {
        // Only return the account for the requesting user
        let user = self
            .cachelayer
            .get_usertoken(Id::Gid(uid))
            .await
            .map_err(|_| "Unable to load account")?
            .ok_or("Unable to find account")?;
        let res = json!({
            "accounts": [
                {
                    "environment": "login.windows.net",
                    "givenName": user.displayname,
                    "homeAccountId": format!("{}.{}", user.uuid.to_string(), user.tenant_id.map(|uuid| uuid.to_string()).unwrap_or("".to_string())),
                    "localAccountId": user.uuid.to_string(),
                    "name": user.displayname,
                    "passwordExpiry": 0,
                    "realm": user.tenant_id.map(|uuid| uuid.to_string()).unwrap_or("".to_string()),
                    "username": user.spn
                }
            ]
        });
        Ok(res.to_string())
    }

    async fn remove_account(
        &mut self,
        _protocol_version: String,
        _correlation_id: String,
        _request_json: String,
        _uid: uid_t,
    ) -> Result<String, Box<dyn Error>> {
        Err("Not implemented".into())
    }

    async fn acquire_prt_sso_cookie(
        &mut self,
        _protocol_version: String,
        _correlation_id: String,
        request_json: String,
        uid: uid_t,
    ) -> Result<String, Box<dyn Error>> {
        // Double check the user is making a request for their own account
        let user = self
            .cachelayer
            .get_usertoken(Id::Gid(uid))
            .await
            .map_err(|_| "Unable to load account")?
            .ok_or("Unable to find account")?;
        let request: SsoCookieReq =
            serde_json::from_str(&request_json).map_err(|e| format!("{:?}", e))?;
        if request.account.username.to_lowercase() != user.spn.to_lowercase() {
            return Err("Invalid request for user!".into());
        }
        // Extract sso_nonce from the ssoUrl query parameter if present.
        // When no sso_nonce is provided (proactive SSO flow, e.g. the linux-entra-sso
        // extension setting a static header), the cookie will be generated
        // with an iat claim instead of a server nonce, giving it a longer
        // validity window.
        let sso_nonce = extract_sso_nonce(request.sso_url.as_deref());
        let prt = self
            .cachelayer
            .get_user_prt_cookie(Id::Name(user.spn.clone()), sso_nonce.as_deref())
            .await
            .ok_or("Failed to fetch prt sso cookie")?;
        let res = json!({
            "account": {
                "environment": "login.microsoftonline.com",
                "homeAccountId": format!("{}.{}", user.uuid.to_string(), user.tenant_id.map(|uuid| uuid.to_string()).unwrap_or("".to_string())),
                "localAccountId": user.uuid.to_string(),
                "realm": user.tenant_id.map(|uuid| uuid.to_string()).unwrap_or("".to_string()),
                "username": user.spn.to_string(),
            },
            "cookieContent": prt,
            "cookieName": "x-ms-RefreshTokenCredential",
        });
        Ok(res.to_string())
    }

    async fn generate_signed_http_request(
        &mut self,
        _protocol_version: String,
        _correlation_id: String,
        _request_json: String,
        _uid: uid_t,
    ) -> Result<String, Box<dyn Error>> {
        Err("Not implemented".into())
    }

    async fn cancel_interactive_flow(
        &mut self,
        _protocol_version: String,
        _correlation_id: String,
        _request_json: String,
        _uid: uid_t,
    ) -> Result<String, Box<dyn Error>> {
        Err("Not implemented".into())
    }

    async fn get_linux_broker_version(
        &mut self,
        _protocol_version: String,
        _correlation_id: String,
        _request_json: String,
        _uid: uid_t,
    ) -> Result<String, Box<dyn Error>> {
        let res = json!({
            "linuxBrokerVersion": env!("CARGO_PKG_VERSION"),
        });
        Ok(res.to_string())
    }
}
