/*
   Unix Azure Entra ID implementation
   Copyright (C) David Mulder <dmulder@samba.org> 2024

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
use crate::compliance_ext::ComplianceCSE;
use crate::cse::CSE;
use crate::custom_compliance_ext::CustomComplianceCSE;
use crate::scripts_ext::ScriptsCSE;
use anyhow::{anyhow, Result};
use himmelblau::graph::Graph;
use himmelblau::intune::{
    fetch_intune_portal_versions, IntuneForLinux, IntuneStatus, NoncompliantRule,
};
use himmelblau::{ClientInfo, EnrollAttrs, IdToken, UserToken};
use himmelblau_unix_common::config::{split_username, HimmelblauConfig};
use std::sync::Arc;
use std::time::Duration;
use tokio::time::sleep;
use tracing::{debug, error, instrument};

#[instrument(skip(config, graph_token, intune_token, iwservice_token))]
/// Run the Intune policy pipeline and return the list of non-compliant
/// rules reported by Intune. An empty list means the device is compliant.
/// Returns `Err` if policy application could not be completed.
pub async fn apply_intune_policy(
    intune_device_id: &str,
    config: &HimmelblauConfig,
    account_id: &str,
    graph_token: &str,
    intune_token: &str,
    iwservice_token: &str,
) -> Result<Vec<NoncompliantRule>> {
    debug!(?account_id, "Attempting to enforce policies");

    let domain = split_username(account_id)
        .map(|(_, domain)| domain)
        .ok_or(anyhow!("Failed to parse domain name from account id",))?;

    debug!(
        ?account_id,
        ?intune_device_id,
        "Applying policies for user and device"
    );

    let ip_versions = config.get_ip_versions();
    let request_timeout = config.get_request_timeout();
    let graph = Graph::new(
        &config.get_odc_provider(domain),
        domain,
        None,
        None,
        None,
        Duration::from_secs(request_timeout),
        &ip_versions,
    )
    .await
    .map_err(|e| anyhow!(e))?;

    let endpoints = graph
        .intune_service_endpoints(graph_token)
        .await
        .map_err(|e| anyhow!(e))?;
    debug!("Discovered Intune service endpoints");

    let mut vers = fetch_intune_portal_versions(Some(
        "https://packages.microsoft.com/ubuntu/22.04/prod/pool/main/i/intune-portal/",
    ))
    .await
    .unwrap_or(vec!["1.2511.11".to_string()]);
    if vers.is_empty() {
        vers = vec!["1.2511.11".to_string()];
    }
    let intune = IntuneForLinux::new(
        endpoints,
        Some(&vers[vers.len() - 1]),
        Duration::from_secs(request_timeout),
        &ip_versions,
    )
    .map_err(|e| anyhow!(e))?;

    let token = UserToken {
        token_type: String::new(),
        scope: None,
        expires_in: 0,
        ext_expires_in: 0,
        refresh_token: String::new(),
        access_token: Some(intune_token.to_string()),
        client_info: ClientInfo::default(),
        id_token: IdToken::default(),
        prt: None,
    };

    // Update device details
    let attrs =
        EnrollAttrs::new(domain.to_string(), None, None, None, None).map_err(|e| anyhow!(e))?;
    intune
        .details(&token, &attrs, intune_device_id)
        .await
        .map_err(|e| anyhow!(e))?;
    debug!("Updated Intune device details");

    // Get the list of policies to apply
    let policies = intune
        .policies(&token, intune_device_id)
        .await
        .map_err(|e| anyhow!(e))?;
    debug!(
        num_policies = policies.len(),
        "Received policy enforcement actions"
    );
    debug!("Policy details:\n{:#?}", policies);
    let mut statuses: IntuneStatus = policies.into();
    statuses.set_device_id(intune_device_id.to_string());
    debug!(
        num_statuses = statuses.policy_statuses.len(),
        "Converted policies to status entries"
    );
    for status in &statuses.policy_statuses {
        debug!(
            policy_id = %status.policy_id,
            num_details = status.details.len(),
            detail_ids = ?status.details.iter().map(|d| d.setting_definition_item_id.as_str()).collect::<Vec<_>>(),
            "Policy status entry"
        );
    }

    let gp_extensions: Vec<Arc<dyn CSE>> = vec![
        Arc::new(ScriptsCSE::new(config, account_id)),
        Arc::new(ComplianceCSE::new(config, account_id)),
        Arc::new(CustomComplianceCSE::new(config, account_id)),
    ];

    let mut errors = vec![];
    let ext_names = ["ScriptsCSE", "ComplianceCSE", "CustomComplianceCSE"];
    for (ext, name) in gp_extensions.iter().zip(ext_names.iter()) {
        debug!(cse = name, "Running CSE");
        match ext.process_group_policy(&mut statuses).await {
            Ok(_) => {
                debug!(cse = name, "CSE completed successfully");
            }
            Err(e) => {
                error!(cse = name, error = %e, "CSE failed");
                errors.push(e);
            }
        }
    }
    debug!("Enforced Intune policy");

    // Report policy status
    debug!("Reporting Intune policy status");
    for status in &statuses.policy_statuses {
        for detail in &status.details {
            debug!(
                policy_id = %status.policy_id,
                rule_id = %detail.rule_id,
                setting_id = %detail.setting_definition_item_id,
                expected = %detail.expected_value,
                actual_len = detail.actual_value.len(),
                new_state = %detail.new_compliance_state,
                old_state = %detail.old_compliance_state,
                "Status detail being reported"
            );
        }
    }
    debug!("Full status report:\n{:#?}", statuses);
    intune
        .status(&token, statuses)
        .await
        .map_err(|e| anyhow!(e))?;

    let iwservice_token = UserToken {
        token_type: String::new(),
        scope: None,
        expires_in: 0,
        ext_expires_in: 0,
        refresh_token: String::new(),
        access_token: Some(iwservice_token.to_string()),
        client_info: ClientInfo::default(),
        id_token: IdToken::default(),
        prt: None,
    };

    // Check compliance status
    sleep(Duration::from_secs(3)).await;
    let device_info = intune
        .get_compliance_info(&iwservice_token, intune_device_id)
        .await
        .map_err(|e| anyhow!(e))?;
    debug!(?device_info.compliance_state, "Intune compliance status");
    if !device_info.noncompliant_rules.is_empty() {
        error!(
            count = device_info.noncompliant_rules.len(),
            "Device is non-compliant"
        );
        for rule in &device_info.noncompliant_rules {
            error!(
                title = rule.title.as_deref().unwrap_or("(no title)"),
                description = rule.description.as_deref().unwrap_or(""),
                more_info_uri = rule.more_info_uri.as_deref().unwrap_or(""),
                source = rule.compliance_source.as_deref().unwrap_or(""),
                setting_id = %rule.setting_id,
                "Non-compliant rule"
            );
        }
    }

    if !errors.is_empty() {
        Err(anyhow!("Policy enforcement failed: {:?}", errors))
    } else {
        Ok(device_info.noncompliant_rules)
    }
}
