import St from 'gi://St';
import Clutter from 'gi://Clutter';
import GLib from 'gi://GLib';
import Pango from 'gi://Pango';
import Gio from 'gi://Gio';
import { Extension } from 'resource:///org/gnome/shell/extensions/extension.js';
import * as AuthPromptModule from 'resource:///org/gnome/shell/gdm/authPrompt.js';
import { QrCode, Ecc } from './qrcodegen.js';
import { selectDeviceFlowUrl, URL_RE } from './qrselection.js';

const GdmAuthPrompt = AuthPromptModule.AuthPrompt;

// Track active temp files for cleanup
let activeTotpTempFiles = new Set();

// Must match the prefixes used in src/common/src/auth.rs fido_auth() / fido_status_check()
const FIDO_INSERT_PREFIX = "[FIDO_INSERT] ";
const FIDO_TOUCH_PREFIX = "[FIDO_TOUCH] ";
// Must match the prefixes used in src/common/src/auth.rs qr_bluetooth_fido_auth()
const QR_BT_PREFIX = "[QR_BT] ";
const QR_BT_LABEL_PREFIX = "[QR_BT_LABEL] ";
const TOTP_QR_PREFIX = "[TOTP_QR] ";

// Maximum URL length for QR code generation (longer URLs create denser, harder to scan codes)
const MAX_URL_LENGTH = 500;

// Validate and normalize a URL for QR code generation
function validateUrl(urlString) {
    if (!urlString || urlString.length > MAX_URL_LENGTH) {
        return null;
    }

    try {
        // Use GLib.Uri for proper URL parsing and validation
        const uri = GLib.Uri.parse(urlString, GLib.UriFlags.NONE);

        // Ensure we have a valid scheme and host
        const scheme = uri.get_scheme();
        const host = uri.get_host();

        if (!scheme || !host || (scheme !== 'http' && scheme !== 'https')) {
            return null;
        }

        // Return the normalized URL string
        return uri.to_string();
    } catch (e) {
        console.error("Himmelblau QR Greeter: Invalid URL:", e);
        return null;
    }
}

// Extract user_code from a device flow message.
// Handles: bare 9-char codes (e.g. "E9Y6JX8J7"), hyphenated codes (e.g. "ABCD-EFGH"),
// and URL query params (?user_code=...).
// Returns null if not found.
function extractUserCode(message) {
    if (!message) return null;
    // Match user_code parameter in URL query string
    const urlMatch = message.match(/[?&]user_code=([A-Z0-9-]+)/i);
    if (urlMatch) return urlMatch[1].toUpperCase();
    // Match "enter the code XXXXXXXXX" sentence format (Microsoft typically sends
    // 9-char codes with no hyphen, e.g. "enter the code E9Y6JX8J7 to authenticate";
    // range 6-12 is intentionally broader for forward compatibility)
    const sentenceMatch = message.match(/enter the code\s+([A-Z0-9-]{6,12})/i);
    if (sentenceMatch) return sentenceMatch[1].toUpperCase();
    // Match hyphenated code pattern (e.g. "ABCD-EFGH") - other providers
    const hyphenMatch = message.match(/\b([A-Z0-9]{4,5}-[A-Z0-9]{4,5})\b/i);
    if (hyphenMatch) return hyphenMatch[1].toUpperCase();
    // Fallback: bare 8-9 char alphanumeric word
    // userCode only contains [A-Z0-9-] so it is safe to embed directly in SVG
    // text nodes (no XML special characters can appear from this regex)
    const bareMatch = message.match(/\b([A-Z0-9]{8,9})\b/i);
    if (bareMatch) return bareMatch[1].toUpperCase();
    return null;
}

// Generate SVG content from a QR code.
//
// The SVG must never contain a <text> element. GNOME rasterizes CSS background
// images out of process in the glycin sandbox, and any text makes librsvg pull
// in pango/fontconfig; when fontconfig has no usable cache it calls symlink(),
// which the sandbox's seccomp filter answers with SIGSYS. The loader dies and
// the greeter shows an empty container instead of the QR code. The device code
// is rendered as a separate St.Label, in process, where fonts are already up.
function qrCodeToSvg(qr, border, lightColor, darkColor) {
    const qrSize = qr.size + border * 2;
    let svg = `<?xml version="1.0" encoding="UTF-8"?>\n`;
    svg += `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${qrSize} ${qrSize}" width="${qrSize * 4}" height="${qrSize * 4}">`;
    svg += `<rect width="100%" height="100%" fill="${lightColor}"/>`;
    svg += `<path d="`;
    for (let y = 0; y < qr.size; y++) {
        for (let x = 0; x < qr.size; x++) {
            if (qr.getModule(x, y)) {
                svg += `M${x + border},${y + border}h1v1h-1z`;
            }
        }
    }
    svg += `" fill="${darkColor}"/>`;
    svg += `</svg>`;
    return svg;
}

// Write SVG under XDG_RUNTIME_DIR (or a 0700 TMPDIR subdir) as 0600.
function writeSvgToTempFile(svgContent) {
    let runtimeDir = GLib.getenv('XDG_RUNTIME_DIR');
    if (runtimeDir) {
        runtimeDir = GLib.build_filenamev([runtimeDir, 'himmelblau-qr']);
    } else {
        runtimeDir = GLib.build_filenamev([GLib.get_tmp_dir(), `himmelblau-qr-${GLib.get_user_name()}`]);
    }
    GLib.mkdir_with_parents(runtimeDir, 0o700);
    const tempPath = GLib.build_filenamev([runtimeDir, `himmelblau-totp-qr-${GLib.get_monotonic_time()}.svg`]);
    const file = Gio.File.new_for_path(tempPath);
    let outputStream = null;
    try {
        // Create file with restrictive permissions (0600 - owner read/write only)
        outputStream = file.replace(null, false, Gio.FileCreateFlags.PRIVATE, null);
        const bytes = new TextEncoder().encode(svgContent);
        outputStream.write_all(bytes, null);
        outputStream.close(null);
        return tempPath;
    } catch (e) {
        console.error("Himmelblau QR Greeter: Failed to write SVG to temp file:", e);
        // Best-effort close of the stream if it was opened
        if (outputStream) {
            try {
                outputStream.close(null);
            } catch (closeError) {
                console.error("Himmelblau QR Greeter: Additionally failed to close output stream:", closeError);
            }
        }
        // Best-effort cleanup of any partially created file
        try {
            if (file.query_exists(null)) {
                file.delete(null);
            }
        } catch (deleteError) {
            console.error("Himmelblau QR Greeter: Additionally failed to delete incomplete temp file:", deleteError);
        }
        throw e;
    }
}

// Delete a temporary file if it exists
function deleteTempFile(filePath) {
    if (!filePath) return;
    try {
        const file = Gio.File.new_for_path(filePath);
        if (file.query_exists(null)) {
            file.delete(null);
        }
        activeTotpTempFiles.delete(filePath);
    } catch (e) {
        console.error("Himmelblau QR Greeter: Failed to delete temp file:", e);
    }
}

// Clean up all tracked temp files
function cleanupAllTempFiles() {
    for (const filePath of activeTotpTempFiles) {
        deleteTempFile(filePath);
    }
    activeTotpTempFiles.clear();
}

export default class QrGreeterExtension extends Extension {
    enable() {
        console.log("Himmelblau QR Greeter: enabled...");

        if (!GdmAuthPrompt) {
            console.error("Himmelblau QR Greeter: GdmAuthPrompt is unavailable.");
            return;
        }

        this._originalSetMessage = GdmAuthPrompt.prototype.setMessage;
        const origSetMessage = this._originalSetMessage;
        const extensionPath = this.path;

        GdmAuthPrompt.prototype.setMessage = function(message, styleClass) {
            // Messages may be batched with \n to avoid GDM per-message delay.
            // Only split when at least one line carries a tagged prefix that
            // requires per-line routing (FIDO icon, QR/Bluetooth code, etc.).
            // For untagged multi-line text, pass the whole string through so
            // every line reaches the label instead of being overwritten by
            // recursive setMessage calls.
            if (message && message.includes("\n")) {
                const lines = message.split("\n");
                const hasTaggedLine = lines.some(line =>
                    line.startsWith(FIDO_INSERT_PREFIX) ||
                    line.startsWith(FIDO_TOUCH_PREFIX) ||
                    line.startsWith(QR_BT_PREFIX) ||
                    line.startsWith(QR_BT_LABEL_PREFIX) ||
                    line.startsWith(TOTP_QR_PREFIX)
                );
                if (hasTaggedLine) {
                    const displayLines = [];
                    for (const line of lines) {
                        if (line.startsWith(FIDO_INSERT_PREFIX) ||
                            line.startsWith(FIDO_TOUCH_PREFIX) ||
                            line.startsWith(QR_BT_PREFIX) ||
                            line.startsWith(QR_BT_LABEL_PREFIX) ||
                            line.startsWith(TOTP_QR_PREFIX)) {
                            this.setMessage(line, styleClass);
                        } else {
                            displayLines.push(line);
                        }
                    }
                    const displayMessage = displayLines.join("\n").trim();
                    if (displayMessage.length > 0) {
                        origSetMessage.call(this, displayMessage, styleClass);
                    }
                    return;
                }
            }

            let displayMessage = message;
            const isQrBtLabel = message && message.startsWith(QR_BT_LABEL_PREFIX);
            const isQrBt = message && message.startsWith(QR_BT_PREFIX);
            const isTotpQr = message && message.startsWith(TOTP_QR_PREFIX);
            if (isQrBtLabel) {
                this._qrBtLabel = message.substring(QR_BT_LABEL_PREFIX.length);
                return;
            } else if (isQrBt) {
                // Don't overwrite the FIDO prompt in the main message area;
                // the QR code and its label are rendered separately below.
                displayMessage = this._lastFidoMessage || "";
            } else if (isTotpQr) {
                displayMessage = "";
            } else if (message && message.startsWith(FIDO_INSERT_PREFIX)) {
                displayMessage = message.substring(FIDO_INSERT_PREFIX.length);
                this._lastFidoMessage = displayMessage;
            } else if (message && message.startsWith(FIDO_TOUCH_PREFIX)) {
                displayMessage = message.substring(FIDO_TOUCH_PREFIX.length);
                this._lastFidoMessage = displayMessage;
            }
            origSetMessage.call(this, displayMessage, styleClass);

            if (this._message) {
                this._message.clutter_text.line_wrap = true;
                this._message.clutter_text.set_line_alignment(Pango.Alignment.CENTER);
                this._message.set_width(-1);
                this._message.set_x_expand(false);
                this._message.set_x_align(Clutter.ActorAlign.CENTER);
            }

            if (!this._qrVBox) {
                const parent = this._message.get_parent();
                parent.remove_child(this._message);

                const vbox = new St.BoxLayout({
                    vertical: true,
                    x_expand: false,
                    y_expand: false,
                    x_align: Clutter.ActorAlign.CENTER,
                    style_class: 'qr-vbox'
                });
                this._qrVBox = vbox;

                vbox.add_child(this._message);

                const qrContainer = new St.Widget({
                    style_class: 'qr-code-container',
                    x_expand: false,
                    y_expand: false,
                    x_align: Clutter.ActorAlign.CENTER
                });
                this._qrContainer = qrContainer;
                vbox.add_child(qrContainer);

                const qrCodeLabel = new St.Label({
                    text: "",
                    style_class: 'qr-user-code',
                    x_align: Clutter.ActorAlign.CENTER
                });
                qrCodeLabel.hide();
                this._qrCodeLabel = qrCodeLabel;
                vbox.add_child(qrCodeLabel);

                const qrLabel = new St.Label({
                    text: "Scan with your phone",
                    style_class: 'qr-instruction-label'
                });
                this._qrLabel = qrLabel;
                vbox.add_child(qrLabel);

                parent.add_child(vbox);
            }

            // Clean up any previous TOTP temp file
            if (this._totpTempFile) {
                deleteTempFile(this._totpTempFile);
                this._totpTempFile = null;
            }

            if (isQrBt) {
                const qrBtUrl = message.substring(QR_BT_PREFIX.length).trim();
                try {
                    const qr = QrCode.encodeText(qrBtUrl, Ecc.LOW);
                    const svgContent = qrCodeToSvg(qr, 2, '#ffffff', '#000000');
                    const tempFilePath = writeSvgToTempFile(svgContent);
                    this._totpTempFile = tempFilePath;
                    activeTotpTempFiles.add(tempFilePath);
                    const fileUri = `file://${tempFilePath}`;
                    this._qrContainer.set_style(`background-image: url('${fileUri}'); background-size: contain; background-repeat: no-repeat; background-position: center;`);
                    this._qrContainer.show();
                    if (this._qrCodeLabel) this._qrCodeLabel.hide();
                    this._qrLabel.set_text(this._qrBtLabel || "Scan with your authenticator app");
                    this._qrLabel.show();
                } catch (e) {
                    console.error("Himmelblau QR Greeter: Failed to generate QR code:", e);
                    if (this._qrContainer) this._qrContainer.hide();
                    if (this._qrCodeLabel) this._qrCodeLabel.hide();
                    if (this._qrLabel) this._qrLabel.hide();
                }
                this._qrBtActive = true;
                return;
            }

            const isFidoInsert = message && message.startsWith(FIDO_INSERT_PREFIX);
            const isFidoTouch = message && message.startsWith(FIDO_TOUCH_PREFIX);
            if (isFidoInsert || isFidoTouch) {
                if (!this._fidoIcon) {
                    const svgPath = GLib.build_filenamev([extensionPath, 'security-key.svg']);
                    const touchSvgPath = GLib.build_filenamev([extensionPath, 'security-key-touch.svg']);

                    const container = new St.Widget({
                        width: 160,
                        height: 80,
                        x_align: Clutter.ActorAlign.CENTER,
                    });

                    const baseLayer = new St.Widget({
                        width: 160,
                        height: 80,
                        style: `background-image: url('file://${svgPath}'); background-size: contain; background-repeat: no-repeat; background-position: center;`,
                    });

                    const touchLayer = new St.Widget({
                        width: 160,
                        height: 80,
                        opacity: 0,
                        style: `background-image: url('file://${touchSvgPath}'); background-size: contain; background-repeat: no-repeat; background-position: center;`,
                    });

                    container.add_child(baseLayer);
                    container.add_child(touchLayer);
                    this._fidoIcon = container;
                    this._fidoTouchLayer = touchLayer;
                    this._qrVBox.insert_child_below(this._fidoIcon, this._message);

                    this.connect('destroy', () => {
                        if (this._fidoPulseTimer) {
                            GLib.source_remove(this._fidoPulseTimer);
                            this._fidoPulseTimer = null;
                        }
                        this._fidoTouchLayer = null;
                        this._fidoIcon = null;
                    });
                }
                if (this._fidoPulseTimer) {
                    GLib.source_remove(this._fidoPulseTimer);
                    this._fidoPulseTimer = null;
                }
                this._fidoTouchLayer.opacity = 0;
                if (isFidoTouch) {
                    this._fidoPulseUp = true;
                    this._fidoPulseTimer = GLib.timeout_add(GLib.PRIORITY_DEFAULT, 300, () => {
                        if (!this._fidoTouchLayer) return GLib.SOURCE_REMOVE;
                        const current = this._fidoTouchLayer.opacity;
                        if (this._fidoPulseUp) {
                            this._fidoTouchLayer.opacity = Math.min(current + 32, 255);
                            if (this._fidoTouchLayer.opacity >= 255) this._fidoPulseUp = false;
                        } else {
                            this._fidoTouchLayer.opacity = Math.max(current - 32, 0);
                            if (this._fidoTouchLayer.opacity <= 0) this._fidoPulseUp = true;
                        }
                        return GLib.SOURCE_CONTINUE;
                    });
                }
                this._fidoIcon.show();
                if (!this._qrBtActive) {
                    if (this._qrContainer) this._qrContainer.hide();
                    if (this._qrCodeLabel) this._qrCodeLabel.hide();
                    if (this._qrLabel) this._qrLabel.hide();
                }
                return;
            }

            this._qrBtActive = false;
            if (this._fidoIcon) {
                this._fidoIcon.hide();
                if (this._fidoPulseTimer) {
                    GLib.source_remove(this._fidoPulseTimer);
                    this._fidoPulseTimer = null;
                }
            }

            const totpMessage = isTotpQr
                ? message.substring(TOTP_QR_PREFIX.length).trim()
                : message;
            const totpMatch = totpMessage ? totpMessage.startsWith("otpauth://") : null;
            if (totpMatch) {
                try {
                    const qr = QrCode.encodeText(totpMessage, Ecc.MEDIUM);
                    const svgContent = qrCodeToSvg(qr, 2, '#ffffff', '#000000');
                    const tempFilePath = writeSvgToTempFile(svgContent);
                    this._totpTempFile = tempFilePath; // Track for cleanup on this instance
                    activeTotpTempFiles.add(tempFilePath); // Track globally for extension disable
                    const fileUri = `file://${tempFilePath}`;
                    this._qrContainer.set_style(`background-image: url('${fileUri}'); background-size: contain; background-repeat: no-repeat; background-position: center;`);
                    this._qrContainer.show();
                    if (this._qrCodeLabel) this._qrCodeLabel.hide();
                    this._qrLabel.set_text(isTotpQr ? "Scan with your phone to set up TOTP" : "Scan with your phone to set up Hello TOTP");
                    this._qrLabel.show();
                    // Replace the verbose message with a simple instruction
                    if (this._message) {
                        this._message.set_text("Open your authenticator app and scan this QR code to enroll. Then enter the generated code.");
                    }
                } catch (e) {
                    console.error("Himmelblau QR Greeter: Failed to generate TOTP QR code:", e);
                    if (this._qrContainer) this._qrContainer.hide();
                    if (this._qrCodeLabel) this._qrCodeLabel.hide();
                    if (this._qrLabel) this._qrLabel.hide();
                }
            } else {
                // Check for URLs in the message
                let qrDisplayed = false;

                if (message) {
                    // Reset the regex lastIndex to ensure fresh matching
                    URL_RE.lastIndex = 0;
                    const urls = message.match(URL_RE) || [];
                    const selection = selectDeviceFlowUrl('', {
                        urls,
                        validateUrl,
                    });

                    if (urls.length > 0 && selection.url) {
                        try {
                            const userCode = extractUserCode(message);
                            const qr = QrCode.encodeText(selection.url, Ecc.MEDIUM);
                            const svgContent = qrCodeToSvg(qr, 2, '#ffffff', '#000000');
                            const tempFilePath = writeSvgToTempFile(svgContent);
                            this._totpTempFile = tempFilePath;
                            activeTotpTempFiles.add(tempFilePath);
                            const fileUri = `file://${tempFilePath}`;
                            this._qrContainer.set_style(`background-image: url('${fileUri}'); background-size: contain; background-repeat: no-repeat; background-position: center;`);
                            this._qrContainer.show();
                            if (this._qrCodeLabel) {
                                if (userCode) {
                                    this._qrCodeLabel.set_text(userCode);
                                    this._qrCodeLabel.show();
                                } else {
                                    this._qrCodeLabel.hide();
                                }
                            }
                            if (selection.usedComplete) {
                                this._qrLabel.set_text("Scan to continue sign-in");
                            } else {
                                this._qrLabel.set_text("Scan with your phone");
                            }
                            this._qrLabel.show();
                            qrDisplayed = true;
                        } catch (e) {
                            console.error("Himmelblau QR Greeter: Failed to generate QR code for URL:", e);
                        }
                    }
                }

                if (!qrDisplayed) {
                    if (this._qrContainer) this._qrContainer.hide();
                    if (this._qrCodeLabel) this._qrCodeLabel.hide();
                    if (this._qrLabel) this._qrLabel.hide();
                }
            }
        };

        console.log("Himmelblau QR Greeter: GdmAuthPrompt.setMessage patched.");
    }

    disable() {
        console.log("Himmelblau QR Greeter: disabled...");
        // Clean up any remaining temp files
        cleanupAllTempFiles();
        if (this._fidoPulseTimer) {
            GLib.source_remove(this._fidoPulseTimer);
            this._fidoPulseTimer = null;
        }
        this._fidoIcon = null;
        this._fidoTouchLayer = null;
        this._qrBtActive = false;
        if (GdmAuthPrompt && this._originalSetMessage) {
            GdmAuthPrompt.prototype.setMessage = this._originalSetMessage;
        }
    }
}
